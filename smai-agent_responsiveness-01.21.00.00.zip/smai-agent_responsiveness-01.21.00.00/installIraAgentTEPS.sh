#!/bin/sh
# ----------------------------------------------------------------
# Monitoring Agent for Agent Responsiveness
# Version 121
# Unix TEPS Installation Script
#
# IBM
#
# This file was created by IBM Agent Builder
# Version 6.3.5
#	Agent Builder Common.v6.3.5 201707241506
#	IBM Tivoli Monitoring Agent Generator.v6.3.5 201707241506
#	IBM Agent Builder UI.v6.3.5 201707241506
#	IBM Tivoli Monitoring OSLC Plugin.v6.3.5 201707241506
#	Agent Builder CIM Data Provider.v6.3.5 201707241506
#	Agent Builder Custom Data Provider.v6.3.5 201707241506
#	Agent Builder HTTP Data Provider.v6.3.5 201707241506
#	Agent Builder ICMP Data Provider.v6.3.5 201707241506
#	IBM Tivoli Monitoring JDBC Data Provider.v6.3.5 201707241506
#	IBM Tivoli Monitoring JMX Data Provider.v6.3.5 201707241506
#	Agent Builder Log Data Provider.v6.3.5 201707241506
#	Agent Builder SNMP Data Provider.v6.3.5 201707241506
#	Agent Builder WMI Data Provider.v6.3.5 201707241506
#	IBM Tivoli Monitoring TMS DLA Plugin.v6.3.5 201707241506
#	Agent Builder Dashboard Support.v6.3.5 201707241506
#	IBM Tivoli Monitoring Remote Deploy.v6.3.5 201707241506
#	IBM Tivoli Omnibus.v6.3.5 201707241506
# ----------------------------------------------------------------
fail()
{
    echo "Installation failed.  Please see the log in ${CANDLE_HOME}/logs/k${PRODUCT_LOWER}_TEPSInstall.log"
    exit 1
}

usage()
{
    echo "usage installIraAgentTEPS <ITM home> [-r]"
    echo "Where -r indicates that the TEPS should be restarted after install"
    exit 1
}

prodarch()
{
    ARCHLINE=`${CANDLE_HOME}/bin/cinfo -p $1 | grep "($1)"`
    if [ $? -ne 0 ]; then
        echo "Can not determine installed architecture for product $1"
        exit 2
    fi
    echo $ARCHLINE | awk '{print $1}'
}

makedir()
{
    if [ ! -d "$1" ]; then
        mkdir -p "$1"
    fi
}

loadsupport()
{
    ${CANDLE_HOME}/bin/itmcmd execute cq "runscript.sh loadSupport K${PRODUCT_UPPER}" 1>&2 || fail
    STOPPED_TEPS=0
}

installpresentation() {
    $CANDLE_HOME/bin/itmcmd execute cq InstallPresentation.sh || fail
    STOPPED_TEPS=1
}

addInstallDateToVerFile()
{
    VERARCH=`uname -a | grep "SunOS"`
    if [ $? -eq 0 ]; then
        epochTime=`nawk 'BEGIN{print srand()}'`
    else
        epochTime=`date +%s`
    fi
    echo "installDate = root|${epochTime}000|" >> $1
}

set +x
CANDLE_HOME=$1
export CANDLE_HOME
RESTART_TEPS=0
while [ -n "$1" ]
do
    shift
    case "$1" in
        "-r") RESTART_TEPS=1
        ;;
    esac
done
PRODUCT_CODE=55
PRODUCT_LOWER=`echo $PRODUCT_CODE | (LC_ALL=C tr '[:upper:]' '[:lower:]')`
PRODUCT_UPPER=`echo $PRODUCT_CODE | (LC_ALL=C tr '[:lower:]' '[:upper:]')`
if [ -z "$CANDLE_HOME"  ]; then
    usage
fi
if [ ! -d "${CANDLE_HOME}/logs" ]; then
    mkdir -p "${CANDLE_HOME}/logs"
fi
exec 2> "${CANDLE_HOME}/logs/k${PRODUCT_LOWER}_TEPSInstall.log"
set -x
$CANDLE_HOME/bin/cinfo -p cj > /dev/null 2>&1
if [ $? -eq 0 ]; then
    HAS_TEPD=1
    TEPD_ARCH=`prodarch cj`
else
    HAS_TEPD=0
fi
$CANDLE_HOME/bin/cinfo -p cq > /dev/null 2>&1
if [ $? -eq 0 ]; then
    HAS_TEPS=1
    TEPS_ARCH=`prodarch cq`
else
    HAS_TEPS=0
fi
$CANDLE_HOME/bin/cinfo -p kf > /dev/null 2>&1
if [ $? -eq 0 ]; then
    HAS_HELP=1
    HELP_ARCH=`prodarch kf`
else
    HAS_HELP=0
fi
if [ $HAS_TEPD -eq 0 -a $HAS_TEPS -eq 0 -a $HAS_HELP -eq 0 ]; then
    echo The ITM installation directory passed in does not contain a
    echo TEPS, TEPD, or Help Server installation
    exit 1
fi

if [ $HAS_TEPS -eq 1 ]; then
    if [ $RESTART_TEPS -eq 0 ]; then
        if [ -f "${CANDLE_HOME}/${TEPS_ARCH}/cq/bin/loadSupport.sh" ]; then
            if [ -f "${CANDLE_HOME}/${TEPS_ARCH}/cq/bin/KfwStatusClient" ]; then
                # Attempting to install support via loadSupport and KfwStatusClient exists
                # Call it to determine if the TEPS is up and connected to the TEMS
                ${CANDLE_HOME}/bin/itmcmd execute cq KfwStatusClient 1>&2
                RC=$?
                if [ ${RC} -ne 0 -a ${RC} -ne 99 ]; then
                    echo The TEPS does not have a connection to the TEMS
                    echo The TEPS must be connected to the TEMS in order to install application support
                    fail
                fi
            fi
        fi
    fi
fi
echo Installing k$PRODUCT_CODE .....
# If there's already an entry for this PC, comment it out if it's wrong
egrep "^${PRODUCT_LOWER}" "$CANDLE_HOME/registry/proddsc.tbl" > /dev/null 2>&1
if [ $? -eq 0 ]; then
    # There's already an entry for this product code-- 
    # If it differs from ours, comment it out and add our new one
    awk -F\| '{if ($1 == "55" && $2 != "Monitoring Agent for Agent Responsiveness") 
                { printf("#%s\n",$0) }
               else
                { print $0} }' "$CANDLE_HOME/registry/proddsc.tbl" > "$CANDLE_HOME/registry/proddsc.tbl.$$" || fail
    mv -f "$CANDLE_HOME/registry/proddsc.tbl.$$" "$CANDLE_HOME/registry/proddsc.tbl" || fail
fi
# We may have commented some out, but one might have been right, so only add if we need to
egrep "^${PRODUCT_LOWER}" "$CANDLE_HOME/registry/proddsc.tbl" > /dev/null 2>&1
if [ $? -ne 0 ]; then
    cat ./ira/agent/common/proddsc.tbl >> $CANDLE_HOME/registry/proddsc.tbl  || fail
fi
if [ "$HAS_TEPD" -eq "1" ]; then
if [ -f "${CANDLE_HOME}/registry/cj${TEPD_ARCH}.ver" ]; then
    CJVER="${CANDLE_HOME}/registry/cj${TEPD_ARCH}.ver"
else
    CJVER=`ls -1 "${CANDLE_HOME}"/registry/cj*.ver | head -1`
fi
if [ -z "${CJVER}" ]; then
    echo No CJ version file found, can not install.
    exit 1
fi
CJVRMF=`egrep "^VRMF[ ]*=" "${CJVER}" | awk -F= '{print $2}' | sed 's/ //g'`
if [ "${CJVRMF}" -lt "06210000" ]; then
    echo This agent requires ITM version 06210000 \(6.2.1\) or higher to work correctly.
    echo The ITM installation in "${CANDLE_HOME}" is version ${CJVRMF},
    echo thus the agent can not install.
    exit 1
fi

    cp ./ira/agent/common/odi2rb/package/k${PRODUCT_LOWER}_resources.jar ${CANDLE_HOME}/${TEPD_ARCH}/cj/lib/ || fail
    cp ./ira/agent/common/odi2rb/k${PRODUCT_LOWER}.inf ${CANDLE_HOME}/${TEPD_ARCH}/cj/ || fail
    # Add our resources jar to the cnp classpath
    cp "${CANDLE_HOME}/${TEPD_ARCH}/cj/bin/cnp.sh" "${CANDLE_HOME}/${TEPD_ARCH}/cj/bin/cnp.sh.SAVE" || fail
    sed 's%export CLASSPATH=%export CLASSPATH=${KCJ_LIB}/k55_resources.jar:%g' "${CANDLE_HOME}/${TEPD_ARCH}/cj/bin/cnp.sh.SAVE" > "${CANDLE_HOME}/${TEPD_ARCH}/cj/bin/cnp.sh" || fail

    cp ./ira/agent/common/${PRODUCT_LOWER}tpd.ver ${CANDLE_HOME}/registry/ || fail
    addInstallDateToVerFile $CANDLE_HOME/registry/${PRODUCT_LOWER}tpd.ver
fi

if [ "$HAS_TEPS" -eq "1" ]; then
if [ -f "${CANDLE_HOME}/registry/cq${TEPS_ARCH}.ver" ]; then
    CQVER="${CANDLE_HOME}/registry/cq${TEPS_ARCH}.ver"
else
    CQVER=`ls -1 "${CANDLE_HOME}"/registry/cq*.ver | head -1`
fi
if [ -z "${CQVER}" ]; then
    echo No CQ version file found, can not install.
    exit 1
fi
CQVRMF=`egrep "^VRMF[ ]*=" "${CQVER}" | awk -F= '{print $2}' | sed 's/ //g'`
if [ "${CQVRMF}" -lt "06210000" ]; then
    echo This agent requires ITM version 06210000 \(6.2.1\) or higher to work correctly.
    echo The ITM installation in "${CANDLE_HOME}" is version ${CQVRMF},
    echo thus the agent can not install.
    exit 1
fi

    cp ./ira/agent/common/*.odi ${CANDLE_HOME}/${TEPS_ARCH}/cq/data/dock${PRODUCT_LOWER} || fail
    cp ./ira/agent/common/k${PRODUCT_LOWER}.his ${CANDLE_HOME}/${TEPS_ARCH}/cq/sqllib/k${PRODUCT_LOWER}.his || fail
    cp ./ira/agent/common/odi2rb/K${PRODUCT_LOWER}Package.xml ${CANDLE_HOME}/${TEPS_ARCH}/cq/sqllib/k${PRODUCT_LOWER}package.xml || fail
    if [ -f "./ira/agent/common/K${PRODUCT_UPPER}_pres.sql" ]; then
        cp ./ira/agent/common/K${PRODUCT_UPPER}_pres.sql ${CANDLE_HOME}/${TEPS_ARCH}/cq/sqllib/k${PRODUCT_LOWER}_pres.sql || fail
    fi
    if [ -f "./ira/agent/common/K${PRODUCT_UPPER}_links.sql" ]; then
        cp ./ira/agent/common/K${PRODUCT_UPPER}_links.sql ${CANDLE_HOME}/${TEPS_ARCH}/cq/sqllib/k${PRODUCT_LOWER}_links.sql || fail
    fi
    cp ./ira/agent/common/ira-k${PRODUCT_LOWER}_kcj.sql ${CANDLE_HOME}/${TEPS_ARCH}/cq/sqllib/k${PRODUCT_LOWER}_kcj.sql || fail
    makedir ${CANDLE_HOME}/${TEPS_ARCH}/cw/k${PRODUCT_LOWER} || fail
    cp ./ira/agent/common/odi2rb/k${PRODUCT_LOWER}.inf ${CANDLE_HOME}/${TEPS_ARCH}/cw/ || fail
    makedir ${CANDLE_HOME}/${TEPS_ARCH}/cw/candle/k${PRODUCT_LOWER}/resources/config || fail
    cp ./ira/agent/common/odi2rb/package/k${PRODUCT_LOWER}_resources.jar ${CANDLE_HOME}/${TEPS_ARCH}/cw/classes || fail
    makedir ${CANDLE_HOME}/${TEPS_ARCH}/cw/classes/candle/k${PRODUCT_LOWER}/resources/help || fail
    makedir ${CANDLE_HOME}/${TEPS_ARCH}/cw/classes/candle/k${PRODUCT_LOWER}/resources/config || fail
    makedir ${CANDLE_HOME}/${TEPS_ARCH}/cw/classes/candle/k${PRODUCT_LOWER}/resources/advice/en_US || fail
    if [ -d ./ira/agent/common/src/k${PRODUCT_LOWER}/Advice ]; then
        cp ./ira/agent/common/src/k${PRODUCT_LOWER}/Advice/* ${CANDLE_HOME}/${TEPS_ARCH}/cw/classes/candle/k${PRODUCT_LOWER}/resources/advice/en_US/ || fail
    fi
    cp ./ira/agent/common/agentConfig/*.properties ${CANDLE_HOME}/${TEPS_ARCH}/cw/ || fail
    cp ./ira/agent/common/agentConfig/*.xml ${CANDLE_HOME}/${TEPS_ARCH}/cw/ || fail
    cp ./ira/agent/common/agentConfig/*.properties ${CANDLE_HOME}/${TEPS_ARCH}/cw/candle/k${PRODUCT_LOWER}/resources/config/ || fail
    cp ./ira/agent/common/agentConfig/*.xml ${CANDLE_HOME}/${TEPS_ARCH}/cw/candle/k${PRODUCT_LOWER}/resources/config/ || fail
    cp ./ira/agent/common/agentConfig/*.properties ${CANDLE_HOME}/${TEPS_ARCH}/cw/classes/candle/k${PRODUCT_LOWER}/resources/config || fail
    cp ./ira/agent/common/agentConfig/*.xml ${CANDLE_HOME}/${TEPS_ARCH}/cw/classes/candle/k${PRODUCT_LOWER}/resources/config || fail
    cp -r help/* ${CANDLE_HOME}/${TEPS_ARCH}/cw/classes/candle/k${PRODUCT_LOWER}/resources/help || fail
    cp "${CANDLE_HOME}/${TEPS_ARCH}/cw/applet.html" "${CANDLE_HOME}/${TEPS_ARCH}/cw/applet.html.SAVE" || fail
    sed 's/CACHE_ARCHIVE VALUE="/CACHE_ARCHIVE VALUE="k55_resources.jar, /g' "${CANDLE_HOME}/${TEPS_ARCH}/cw/applet.html.SAVE" | sed 's/CACHE_VERSION VALUE="/CACHE_VERSION VALUE="701.2100.0019.071, /g' > "${CANDLE_HOME}/${TEPS_ARCH}/cw/applet.html" || fail
    if [ "$RESTART_TEPS" -eq "1" ] ; then
        installpresentation
    else
        if [ -f "${CANDLE_HOME}/${TEPS_ARCH}/cq/bin/loadSupport.sh" ]; then
            loadsupport
        else
            installpresentation
        fi
    fi
    cp ./ira/agent/common/${PRODUCT_LOWER}tps.ver ${CANDLE_HOME}/registry/ || fail
    addInstallDateToVerFile $CANDLE_HOME/registry/${PRODUCT_LOWER}tps.ver
    cp ./ira/agent/common/${PRODUCT_LOWER}tpw.ver ${CANDLE_HOME}/registry/ || fail
    addInstallDateToVerFile $CANDLE_HOME/registry/${PRODUCT_LOWER}tpw.ver
fi

# Now check for 6.2.3 and install Java Web Start support if possible.
if [ -f "${CANDLE_HOME}/registry/cq${TEPS_ARCH}.ver" ]; then
    CQVER="${CANDLE_HOME}/registry/cq${TEPS_ARCH}.ver"
else
    CQVER=`ls -1 "${CANDLE_HOME}"/registry/cq*.ver | head -1`
fi
if [ -z "${CQVER}" ]; then
    echo No CQ version file found, can not install.
    exit 1
fi
CQVRMF=`egrep "^VRMF[ ]*=" "${CQVER}" | awk -F= '{print $2}' | sed 's/ //g'`
if [ "${CQVRMF}" -lt "06230000" ]; then
        echo Automatic installation of Java Web Start support requires ITM 6.2.3.
        echo For Java Web Start to work you will need to reconfigure the TEPS.
        echo The ITM installation in "${CANDLE_HOME}" is version ${CQVRMF},
else
        echo Creating Java Web Start support files.
        ${CANDLE_HOME}/bin/itmcmd config -A cw
fi

if [ "$HAS_HELP" -eq "1" ]; then
if [ -f "${CANDLE_HOME}/registry/kf${HELP_ARCH}.ver" ]; then
    KFVER="${CANDLE_HOME}/registry/kf${HELP_ARCH}.ver"
else
    KFVER=`ls -1 "${CANDLE_HOME}"/registry/kf*.ver | head -1`
fi
if [ -z "${KFVER}" ]; then
    echo No KF version file found, can not install.
    exit 1
fi
KFVRMF=`egrep "^VRMF[ ]*=" "${KFVER}" | awk -F= '{print $2}' | sed 's/ //g'`
if [ "${KFVRMF}" -lt "06210000" ]; then
    echo This agent requires ITM version 06210000 \(6.2.1\) or higher to work correctly.
    echo The ITM installation in "${CANDLE_HOME}" is version ${KFVRMF},
    echo thus the agent can not install.
    exit 1
fi

    makedir ${CANDLE_HOME}/${HELP_ARCH}/kf/eclipse/plugins/com.ibm.k${PRODUCT_LOWER}.doc || fail
    for file in help/*
    do
        if [ -f "$file" ]; then
            cp $file ${CANDLE_HOME}/${HELP_ARCH}/kf/eclipse/plugins/com.ibm.k${PRODUCT_LOWER}.doc/ || fail
        fi
    done
    if [ "$STOPPED_TEPS" -eq "1" ]; then
        ${CANDLE_HOME}/bin/itmcmd agent stop kf
        sleep 15
        cd /
        ${CANDLE_HOME}/bin/itmcmd agent start kf || fail
    else
        echo Online help for this agent will not be available until the Help Server is restarted, which also requires restarting the TEPS.
    fi
fi

if [ "$HAS_TEPS" -eq "1" -a "$STOPPED_TEPS" -eq "1" ]; then
    cd /
    ${CANDLE_HOME}/bin/itmcmd agent start cq || fail
fi


echo "Install of K${PRODUCT_CODE} TEPS support successful." 
