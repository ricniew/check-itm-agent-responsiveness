/*
 COPYRIGHT_COMMENT_TAG_BEGIN
 IBM Confidential
 OCO Source Materials
 5724-C04
 
 Copyright IBM Corp. 2005, 2011
 The source code for this program is not published or otherwise
 divested of its trade secrets, irrespective of what has
 been deposited with the U.S. Copyright Office.
 COPYRIGHT_COMMENT_TAG_END
 */
//***************************************************************************
//                                                                          *
// Unpublished Copyright (c) 1998, 2004 Candle Corporation.                 *
//                                                                          *
// All rights reserved.  International copyright secured.                   *
// USE PERMISSIBLE UNDER LICENSE ONLY.  This software may be                *
// protected by one or more United States and/or international              *
// patents or pending patent applications.                                  *
//                                                                          *
//***************************************************************************

/**
 * Resources
 * NLS_MESSAGEFORMAT_NONE (CHKPII flag indicating that the text is not 
 *                         processed by Java MessageFormat class)
 */

//***************************************************************************
//                >>>>  M A I N T E N A N C E    L O G  <<<<                *
//***************************************************************************
//  $Date: March 12, 2019 1:39:08 PM CET $
//  $Revision: 1.0 $
//
//***************************************************************************

// NLS_ENCODING=UTF-8
package candle.k55.resources;

import candle.kjr.resource.*;
import candle.kjr.util.*;
import java.util.*;
import java.lang.reflect.Method;

/**
 * <code>DocK55Bundle</code> contains K55 ODI definitions for NLS.
 *
 */

public class DocK55Bundle extends ResourceBundle implements Versioned
{
  private static final long serialVersionUID = 1L;

  private static final String BUNDLE_ID       = "dock55";
  private static final String BUNDLE_NAME     = "candle.k55.resources.DocK55Bundle";

  private static final IntegerVersion version = new IntegerVersion(100);

  // public Object[][] getContents() - needed for CHKPII tool
  
public Object[][] _oM1()
{
Object[][] contents = 
{
        {"%IBM.K55",                                      "Agent Responsiveness"},
};
return contents;
}

public Object[][] _oM2()
{
Object[][] contents = 
{
        {"%IBM.K55RSP",                                   "Responsiveness"},
};
return contents;
}

public Object[][] _oM3()
{
Object[][] contents = 
{
        {"TABLE.K55RSPDS.OBJECT",                         "K55 RESPONSIVENESS NODES"},
        {"K55RSPDS.ORIGINNODE",                           "Node"},

        {"K55RSPDS.TIMESTAMP",                            "Timestamp"},

        {"K55RSPDS.SN_MSN",                               "Subnode MSN"},

        {"K55RSPDS.SN_AFFIN",                             "Subnode Affinity"},

        {"K55RSPDS.SN_TYPE",                              "Subnode Type"},

        {"K55RSPDS.SN_RES",                               "Subnode Resource Name"},

        {"K55RSPDS.SN_VER",                               "Subnode Version"},

};
return contents;
}

public Object[][] _oM4()
{
Object[][] contents = 
{
        {"TABLE.K55POBJST.OBJECT",                        "K55 PERFORMANCE OBJECT STATUS"},
        {"K55POBJST.ORIGINNODE",                          "Node"},

        {"K55POBJST.TIMESTAMP",                           "Timestamp"},

        {"K55POBJST.ATTRGRP",                             "Query Name"},

        {"K55POBJST.OBJNAME",                             "Object Name"},

        {"K55POBJST.OBJTYPE",                             "Object Type"},
        {"K55POBJST.OBJTYPE.ENUM.0",                      "WMI"},
        {"K55POBJST.OBJTYPE.ENUM.1",                      "PERFMON"},
        {"K55POBJST.OBJTYPE.ENUM.10",                     "WMI REMOTE DATA"},
        {"K55POBJST.OBJTYPE.ENUM.11",                     "LOG FILE"},
        {"K55POBJST.OBJTYPE.ENUM.12",                     "JDBC"},
        {"K55POBJST.OBJTYPE.ENUM.13",                     "CONFIG DISCOVERY"},
        {"K55POBJST.OBJTYPE.ENUM.14",                     "NT EVENT LOG"},
        {"K55POBJST.OBJTYPE.ENUM.15",                     "FILTER"},
        {"K55POBJST.OBJTYPE.ENUM.16",                     "SNMP EVENT"},
        {"K55POBJST.OBJTYPE.ENUM.17",                     "PING"},
        {"K55POBJST.OBJTYPE.ENUM.18",                     "DIRECTOR DATA"},
        {"K55POBJST.OBJTYPE.ENUM.19",                     "DIRECTOR EVENT"},
        {"K55POBJST.OBJTYPE.ENUM.2",                      "WMI ASSOCIATION GROUP"},
        {"K55POBJST.OBJTYPE.ENUM.20",                     "SSH REMOTE SHELL COMMAND"},
        {"K55POBJST.OBJTYPE.ENUM.3",                      "JMX"},
        {"K55POBJST.OBJTYPE.ENUM.4",                      "SNMP"},
        {"K55POBJST.OBJTYPE.ENUM.5",                      "SHELL COMMAND"},
        {"K55POBJST.OBJTYPE.ENUM.6",                      "JOINED GROUPS"},
        {"K55POBJST.OBJTYPE.ENUM.7",                      "CIMOM"},
        {"K55POBJST.OBJTYPE.ENUM.8",                      "CUSTOM"},
        {"K55POBJST.OBJTYPE.ENUM.9",                      "ROLLUP DATA"},

        {"K55POBJST.OBJSTTS",                             "Object Status"},
        {"K55POBJST.OBJSTTS.ENUM.0",                      "ACTIVE"},
        {"K55POBJST.OBJSTTS.ENUM.1",                      "INACTIVE"},

        {"K55POBJST.ERRCODE",                             "Error Code"},
        {"K55POBJST.ERRCODE.ENUM.0",                      "NO ERROR"},
        {"K55POBJST.ERRCODE.ENUM.1",                      "GENERAL ERROR"},
        {"K55POBJST.ERRCODE.ENUM.10",                     "NO INSTANCES RETURNED"},
        {"K55POBJST.ERRCODE.ENUM.11",                     "ASSOCIATOR QUERY FAILED"},
        {"K55POBJST.ERRCODE.ENUM.12",                     "REFERENCE QUERY FAILED"},
        {"K55POBJST.ERRCODE.ENUM.13",                     "NO RESPONSE RECEIVED"},
        {"K55POBJST.ERRCODE.ENUM.14",                     "CANNOT FIND JOINED QUERY"},
        {"K55POBJST.ERRCODE.ENUM.15",                     "CANNOT FIND JOIN ATTRIBUTE IN QUERY 1 RESULTS"},
        {"K55POBJST.ERRCODE.ENUM.16",                     "CANNOT FIND JOIN ATTRIBUTE IN QUERY 2 RESULTS"},
        {"K55POBJST.ERRCODE.ENUM.17",                     "QUERY 1 NOT A SINGLETON"},
        {"K55POBJST.ERRCODE.ENUM.18",                     "QUERY 2 NOT A SINGLETON"},
        {"K55POBJST.ERRCODE.ENUM.19",                     "NO INSTANCES RETURNED IN QUERY 1"},
        {"K55POBJST.ERRCODE.ENUM.2",                      "OBJECT NOT FOUND"},
        {"K55POBJST.ERRCODE.ENUM.20",                     "NO INSTANCES RETURNED IN QUERY 2"},
        {"K55POBJST.ERRCODE.ENUM.21",                     "CANNOT FIND ROLLUP QUERY"},
        {"K55POBJST.ERRCODE.ENUM.22",                     "CANNOT FIND ROLLUP ATTRIBUTE"},
        {"K55POBJST.ERRCODE.ENUM.23",                     "FILE OFFLINE"},
        {"K55POBJST.ERRCODE.ENUM.24",                     "NO HOSTNAME"},
        {"K55POBJST.ERRCODE.ENUM.25",                     "MISSING LIBRARY"},
        {"K55POBJST.ERRCODE.ENUM.26",                     "ATTRIBUTE COUNT MISMATCH"},
        {"K55POBJST.ERRCODE.ENUM.27",                     "ATTRIBUTE NAME MISMATCH"},
        {"K55POBJST.ERRCODE.ENUM.28",                     "COMMON DATA PROVIDER NOT STARTED"},
        {"K55POBJST.ERRCODE.ENUM.29",                     "CALLBACK REGISTRATION ERROR"},
        {"K55POBJST.ERRCODE.ENUM.3",                      "COUNTER NOT FOUND"},
        {"K55POBJST.ERRCODE.ENUM.30",                     "MDL LOAD ERROR"},
        {"K55POBJST.ERRCODE.ENUM.31",                     "AUTHENTICATION FAILED"},
        {"K55POBJST.ERRCODE.ENUM.32",                     "CANNOT RESOLVE HOST NAME"},
        {"K55POBJST.ERRCODE.ENUM.33",                     "SUBNODE UNAVAILABLE"},
        {"K55POBJST.ERRCODE.ENUM.34",                     "SUBNODE NOT FOUND IN CONFIG"},
        {"K55POBJST.ERRCODE.ENUM.35",                     "ATTRIBUTE ERROR"},
        {"K55POBJST.ERRCODE.ENUM.36",                     "CLASSPATH ERROR"},
        {"K55POBJST.ERRCODE.ENUM.37",                     "CONNECTION FAILURE"},
        {"K55POBJST.ERRCODE.ENUM.38",                     "FILTER SYNTAX ERROR"},
        {"K55POBJST.ERRCODE.ENUM.39",                     "FILE NAME MISSING"},
        {"K55POBJST.ERRCODE.ENUM.4",                      "NAMESPACE ERROR"},
        {"K55POBJST.ERRCODE.ENUM.40",                     "SQL QUERY ERROR"},
        {"K55POBJST.ERRCODE.ENUM.41",                     "SQL FILTER QUERY ERROR"},
        {"K55POBJST.ERRCODE.ENUM.42",                     "SQL DB QUERY ERROR"},
        {"K55POBJST.ERRCODE.ENUM.43",                     "SQL DB FILTER QUERY ERROR"},
        {"K55POBJST.ERRCODE.ENUM.44",                     "PORT OPEN FAILED"},
        {"K55POBJST.ERRCODE.ENUM.45",                     "ACCESS DENIED"},
        {"K55POBJST.ERRCODE.ENUM.46",                     "TIMEOUT"},
        {"K55POBJST.ERRCODE.ENUM.47",                     "NOT IMPLEMENTED"},
        {"K55POBJST.ERRCODE.ENUM.48",                     "REQUESTED A BAD VALUE"},
        {"K55POBJST.ERRCODE.ENUM.49",                     "RESPONSE TOO BIG"},
        {"K55POBJST.ERRCODE.ENUM.5",                      "OBJECT CURRENTLY UNAVAILABLE"},
        {"K55POBJST.ERRCODE.ENUM.50",                     "GENERAL RESPONSE ERROR"},
        {"K55POBJST.ERRCODE.ENUM.51",                     "SCRIPT NONZERO RETURN"},
        {"K55POBJST.ERRCODE.ENUM.52",                     "SCRIPT NOT FOUND"},
        {"K55POBJST.ERRCODE.ENUM.53",                     "SCRIPT LAUNCH ERROR"},
        {"K55POBJST.ERRCODE.ENUM.54",                     "CONF FILE DOES NOT EXIST"},
        {"K55POBJST.ERRCODE.ENUM.55",                     "CONF FILE ACCESS DENIED"},
        {"K55POBJST.ERRCODE.ENUM.56",                     "INVALID CONF FILE"},
        {"K55POBJST.ERRCODE.ENUM.57",                     "EIF INITIALIZATION FAILED"},
        {"K55POBJST.ERRCODE.ENUM.58",                     "CANNOT OPEN FORMAT FILE"},
        {"K55POBJST.ERRCODE.ENUM.59",                     "FORMAT FILE SYNTAX ERROR"},
        {"K55POBJST.ERRCODE.ENUM.6",                      "COM LIBRARY INIT FAILURE"},
        {"K55POBJST.ERRCODE.ENUM.60",                     "REMOTE HOST UNAVAILABLE"},
        {"K55POBJST.ERRCODE.ENUM.61",                     "EVENT LOG DOES NOT EXIST"},
        {"K55POBJST.ERRCODE.ENUM.62",                     "PING FILE DOES NOT EXIST"},
        {"K55POBJST.ERRCODE.ENUM.63",                     "NO PING DEVICE FILES"},
        {"K55POBJST.ERRCODE.ENUM.64",                     "PING DEVICE LIST FILE MISSING"},
        {"K55POBJST.ERRCODE.ENUM.65",                     "SNMP MISSING PASSWORD"},
        {"K55POBJST.ERRCODE.ENUM.66",                     "DISABLED"},
        {"K55POBJST.ERRCODE.ENUM.67",                     "URLS FILE NOT FOUND"},
        {"K55POBJST.ERRCODE.ENUM.68",                     "XML PARSE ERROR"},
        {"K55POBJST.ERRCODE.ENUM.69",                     "NOT INITIALIZED"},
        {"K55POBJST.ERRCODE.ENUM.7",                      "SECURITY INIT FAILURE"},
        {"K55POBJST.ERRCODE.ENUM.70",                     "ICMP SOCKETS FAILED"},
        {"K55POBJST.ERRCODE.ENUM.71",                     "DUPLICATE CONF FILE"},
        {"K55POBJST.ERRCODE.ENUM.72",                     "DELETED CONFIGURATION"},
        {"K55POBJST.ERRCODE.ENUM.9",                      "PROXY SECURITY FAILURE"},

        {"K55POBJST.COLSTRT",                             "Last Collection Start"},
        {"K55POBJST.COLSTRT.ENUM.0000000000000001",       "NOT COLLECTED"},
        {"K55POBJST.COLSTRT.ENUM.0691231190000000",       "NOT COLLECTED"},

        {"K55POBJST.COLFINI",                             "Last Collection Finished"},
        {"K55POBJST.COLFINI.ENUM.0000000000000001",       "NOT COLLECTED"},
        {"K55POBJST.COLFINI.ENUM.0691231190000000",       "NOT COLLECTED"},

        {"K55POBJST.COLDURA",                             "Last Collection Duration"},

        {"K55POBJST.COLAVGD",                             "Average Collection Duration"},
        {"K55POBJST.COLAVGD.ENUM.-100",                   "NO DATA"},

        {"K55POBJST.REFRINT",                             "Refresh Interval"},

        {"K55POBJST.NUMCOLL",                             "Number of Collections"},

        {"K55POBJST.CACHEHT",                             "Cache Hits"},

        {"K55POBJST.CACHEMS",                             "Cache Misses"},

        {"K55POBJST.CACHPCT",                             "Cache Hit Percent"},

        {"K55POBJST.INTSKIP",                             "Intervals Skipped"},

};
return contents;
}

public Object[][] _oM5()
{
Object[][] contents = 
{
        {"TABLE.K55THPLST.OBJECT",                        "K55 THREAD POOL STATUS"},
        {"K55THPLST.ORIGINNODE",                          "Node"},

        {"K55THPLST.TIMESTAMP",                           "Timestamp"},

        {"K55THPLST.THPSIZE",                             "Thread Pool Size"},
        {"K55THPLST.THPSIZE.ENUM.-1",                     "NO DATA"},
        {"K55THPLST.THPSIZE.ENUM.-100",                   "NO DATA"},

        {"K55THPLST.TPMAXSZ",                             "Thread Pool Max Size"},
        {"K55THPLST.TPMAXSZ.ENUM.-1",                     "NO DATA"},
        {"K55THPLST.TPMAXSZ.ENUM.-100",                   "NO DATA"},

        {"K55THPLST.TPACTTH",                             "Thread Pool Active Threads"},
        {"K55THPLST.TPACTTH.ENUM.-1",                     "NO DATA"},
        {"K55THPLST.TPACTTH.ENUM.-100",                   "NO DATA"},

        {"K55THPLST.TPAVGAT",                             "Thread Pool Avg Active Threads"},
        {"K55THPLST.TPAVGAT.ENUM.-1",                     "NO DATA"},
        {"K55THPLST.TPAVGAT.ENUM.-100",                   "NO DATA"},

        {"K55THPLST.TPMINAT",                             "Thread Pool Min Active Threads"},
        {"K55THPLST.TPMINAT.ENUM.-1",                     "NO DATA"},
        {"K55THPLST.TPMINAT.ENUM.-100",                   "NO DATA"},

        {"K55THPLST.TPMAXAT",                             "Thread Pool Max Active Threads"},
        {"K55THPLST.TPMAXAT.ENUM.-1",                     "NO DATA"},
        {"K55THPLST.TPMAXAT.ENUM.-100",                   "NO DATA"},

        {"K55THPLST.TPQLGTH",                             "Thread Pool Queue Length"},
        {"K55THPLST.TPQLGTH.ENUM.-1",                     "NO DATA"},
        {"K55THPLST.TPQLGTH.ENUM.-100",                   "NO DATA"},

        {"K55THPLST.TPAVGQL",                             "Thread Pool Avg Queue Length"},
        {"K55THPLST.TPAVGQL.ENUM.-1",                     "NO DATA"},
        {"K55THPLST.TPAVGQL.ENUM.-100",                   "NO DATA"},

        {"K55THPLST.TPMINQL",                             "Thread Pool Min Queue Length"},
        {"K55THPLST.TPMINQL.ENUM.-1",                     "NO DATA"},
        {"K55THPLST.TPMINQL.ENUM.-100",                   "NO DATA"},

        {"K55THPLST.TPMAXQL",                             "Thread Pool Max Queue Length"},
        {"K55THPLST.TPMAXQL.ENUM.-1",                     "NO DATA"},
        {"K55THPLST.TPMAXQL.ENUM.-100",                   "NO DATA"},

        {"K55THPLST.TPAVJBW",                             "Thread Pool Avg Job Wait"},
        {"K55THPLST.TPAVJBW.ENUM.-1",                     "NO DATA"},
        {"K55THPLST.TPAVJBW.ENUM.-100",                   "NO DATA"},

        {"K55THPLST.TPTJOBS",                             "Thread Pool Total Jobs"},
        {"K55THPLST.TPTJOBS.ENUM.-1",                     "NO DATA"},
        {"K55THPLST.TPTJOBS.ENUM.-100",                   "NO DATA"},

};
return contents;
}

public Object[][] _oM6()
{
Object[][] contents = 
{
        {"TABLE.K55LOGFRX.OBJECT",                        "K55 LOG FILE REGEX STATISTICS"},
        {"K55LOGFRX.ORIGINNODE",                          "Node"},

        {"K55LOGFRX.TIMESTAMP",                           "Timestamp"},

        {"K55LOGFRX.TBLNAME",                             "Table Name"},

        {"K55LOGFRX.ATRNAME",                             "Attrib Name"},

        {"K55LOGFRX.FLTRNUM",                             "Filter Number"},

        {"K55LOGFRX.CPUTAVG",                             "Average Processor Time"},
        {"K55LOGFRX.CPUTAVG.ENUM.-1",                     "N/A"},
        {"K55LOGFRX.CPUTAVG.ENUM.-100",                   "N/A"},

        {"K55LOGFRX.CPUTIME",                             "Total Processor Time"},
        {"K55LOGFRX.CPUTIME.ENUM.-1",                     "N/A"},
        {"K55LOGFRX.CPUTIME.ENUM.-100",                   "N/A"},

        {"K55LOGFRX.CPUTMAX",                             "Max Processor Time"},
        {"K55LOGFRX.CPUTMAX.ENUM.-1",                     "N/A"},
        {"K55LOGFRX.CPUTMAX.ENUM.-100",                   "N/A"},

        {"K55LOGFRX.CPUTMIN",                             "Min Processor Time"},
        {"K55LOGFRX.CPUTMIN.ENUM.-1",                     "N/A"},
        {"K55LOGFRX.CPUTMIN.ENUM.-100",                   "N/A"},

        {"K55LOGFRX.COUNT",                               "Filter Count"},

        {"K55LOGFRX.COUNTMA",                             "Filter Count Matched"},

        {"K55LOGFRX.COUNTUN",                             "Filter Count Unmatched"},

        {"K55LOGFRX.REGXPAT",                             "RegEx Pattern"},

        {"K55LOGFRX.LASTMAT",                             "Last Matched Time"},
        {"K55LOGFRX.LASTMAT.ENUM.0000000000000001",       "N/A"},

        {"K55LOGFRX.LASTUMA",                             "Last Unmatched Time"},
        {"K55LOGFRX.LASTUMA.ENUM.0000000000000001",       "N/A"},

        {"K55LOGFRX.RSTTYPE",                             "Result Type"},
        {"K55LOGFRX.RSTTYPE.ENUM.0",                      "UNKNOWN"},
        {"K55LOGFRX.RSTTYPE.ENUM.1",                      "INCLUDE"},
        {"K55LOGFRX.RSTTYPE.ENUM.2",                      "EXCLUDE"},
        {"K55LOGFRX.RSTTYPE.ENUM.3",                      "BEGIN"},
        {"K55LOGFRX.RSTTYPE.ENUM.4",                      "END"},

};
return contents;
}

public Object[][] _oM7()
{
Object[][] contents = 
{
        {"TABLE.K55LOGFST.OBJECT",                        "K55 LOG FILE STATUS"},
        {"K55LOGFST.ORIGINNODE",                          "Node"},

        {"K55LOGFST.TIMESTAMP",                           "Timestamp"},

        {"K55LOGFST.TBLNAME",                             "Table Name"},

        {"K55LOGFST.FILNAME",                             "File Name"},

        {"K55LOGFST.REPATRN",                             "RegEx Pattern"},

        {"K55LOGFST.FILTYPE",                             "File Type"},
        {"K55LOGFST.FILTYPE.ENUM.0",                      "UNKNOWN"},
        {"K55LOGFST.FILTYPE.ENUM.1",                      "REGULAR FILE"},
        {"K55LOGFST.FILTYPE.ENUM.2",                      "PIPE"},
        {"K55LOGFST.FILTYPE.ENUM.3",                      "DIRECTORY"},

        {"K55LOGFST.FILSTAT",                             "File Status"},
        {"K55LOGFST.FILSTAT.ENUM.-1",                     "N/A"},
        {"K55LOGFST.FILSTAT.ENUM.0",                      "OK"},
        {"K55LOGFST.FILSTAT.ENUM.1",                      "PERMISSION DENIED"},
        {"K55LOGFST.FILSTAT.ENUM.12",                     "OUT OF MEMORY"},
        {"K55LOGFST.FILSTAT.ENUM.126",                    "KEY FILE ACCESS ERROR"},
        {"K55LOGFST.FILSTAT.ENUM.13",                     "ACCESS DENIED"},
        {"K55LOGFST.FILSTAT.ENUM.16",                     "RESOURCE BUSY"},
        {"K55LOGFST.FILSTAT.ENUM.17",                     "NO LISTENER"},
        {"K55LOGFST.FILSTAT.ENUM.18",                     "CANNOT CONNECT TO REMOTE"},
        {"K55LOGFST.FILSTAT.ENUM.19",                     "HOSTNAME UNRESOLVED"},
        {"K55LOGFST.FILSTAT.ENUM.2",                      "FILE DOES NOT EXIST"},
        {"K55LOGFST.FILSTAT.ENUM.20",                     "NOT A DIRECTORY"},
        {"K55LOGFST.FILSTAT.ENUM.21",                     "IS A DIRECTORY"},
        {"K55LOGFST.FILSTAT.ENUM.22",                     "INVALID ARGUMENT"},
        {"K55LOGFST.FILSTAT.ENUM.23",                     "FILE TABLE OVERFLOW"},
        {"K55LOGFST.FILSTAT.ENUM.24",                     "TOO MANY OPEN FILES"},
        {"K55LOGFST.FILSTAT.ENUM.26",                     "TEXT FILE BUSY"},
        {"K55LOGFST.FILSTAT.ENUM.27",                     "FILE TOO LARGE"},
        {"K55LOGFST.FILSTAT.ENUM.28",                     "NO SPACE LEFT ON DEVICE"},
        {"K55LOGFST.FILSTAT.ENUM.29",                     "ILLEGAL SEEK ON PIPE"},
        {"K55LOGFST.FILSTAT.ENUM.3",                      "PATH DOES NOT EXIST"},
        {"K55LOGFST.FILSTAT.ENUM.30",                     "READ-ONLY FILE SYSTEM"},
        {"K55LOGFST.FILSTAT.ENUM.31",                     "TOO MANY LINKS"},
        {"K55LOGFST.FILSTAT.ENUM.32",                     "BROKEN PIPE"},
        {"K55LOGFST.FILSTAT.ENUM.33",                     "FAMILY UNSUPPORTED"},
        {"K55LOGFST.FILSTAT.ENUM.4",                      "INTERRUPTED SYSTEM CALL"},
        {"K55LOGFST.FILSTAT.ENUM.5",                      "I/O ERROR"},
        {"K55LOGFST.FILSTAT.ENUM.50",                     "PASSWORD EXPIRED"},
        {"K55LOGFST.FILSTAT.ENUM.51",                     "PUBLIC KEY UNVERIFIED"},
        {"K55LOGFST.FILSTAT.ENUM.52",                     "PUBLIC KEY UNRECOGNIZED"},
        {"K55LOGFST.FILSTAT.ENUM.53",                     "NO SUPPORTED DESCR"},
        {"K55LOGFST.FILSTAT.ENUM.54",                     "SOCKET TIMEOUT"},
        {"K55LOGFST.FILSTAT.ENUM.6",                      "NO SUCH DEVICE"},
        {"K55LOGFST.FILSTAT.ENUM.9",                      "BAD FILE NUMBER"},
        {"K55LOGFST.FILSTAT.ENUM.95",                     "NOT SUPPORTED"},

        {"K55LOGFST.RECMTCH",                             "Num Records Matched"},

        {"K55LOGFST.RECUNMT",                             "Num Records Not Matched"},
        {"K55LOGFST.RECUNMT.ENUM.-1",                     "UNMATCH LOG NOT ENABLED"},

        {"K55LOGFST.RECPROC",                             "Num Records Processed"},

        {"K55LOGFST.OFFSET",                              "Current File Position"},
        {"K55LOGFST.OFFSET.ENUM.-1",                      "N/A"},

        {"K55LOGFST.FILSIZE",                             "Current File Size"},
        {"K55LOGFST.FILSIZE.ENUM.-1",                     "N/A"},

        {"K55LOGFST.LASTMOD",                             "Last Modification Time"},
        {"K55LOGFST.LASTMOD.ENUM.0",                      "NOT INITIALIZED"},

        {"K55LOGFST.CODEPG",                              "Codepage"},

        {"K55LOGFST.REMHOST",                             "Remote Host"},

};
return contents;
}

public Object[][] _oM8()
{
Object[][] contents = 
{
        {"TABLE.K55TACTST.OBJECT",                        "K55 TAKE ACTION STATUS"},
        {"K55TACTST.ORIGINNODE",                          "Node"},

        {"K55TACTST.TIMESTAMP",                           "Timestamp"},

        {"K55TACTST.TSKNAME",                             "Action Name"},

        {"K55TACTST.TSKSTAT",                             "Action Status"},
        {"K55TACTST.TSKSTAT.ENUM.0",                      "OK"},
        {"K55TACTST.TSKSTAT.ENUM.1",                      "NOT APPLICABLE"},
        {"K55TACTST.TSKSTAT.ENUM.10",                     "UNKNOWN"},
        {"K55TACTST.TSKSTAT.ENUM.11",                     "DEPENDENT STILL RUNNING"},
        {"K55TACTST.TSKSTAT.ENUM.12",                     "INSUFFICIENT USER AUTHORITY"},
        {"K55TACTST.TSKSTAT.ENUM.2",                      "GENERAL ERROR"},
        {"K55TACTST.TSKSTAT.ENUM.3",                      "WARNING"},
        {"K55TACTST.TSKSTAT.ENUM.4",                      "NOT RUNNING"},
        {"K55TACTST.TSKSTAT.ENUM.5",                      "DEPENDENT NOT RUNNING"},
        {"K55TACTST.TSKSTAT.ENUM.6",                      "ALREADY RUNNING"},
        {"K55TACTST.TSKSTAT.ENUM.7",                      "PREREQ NOT RUNNING"},
        {"K55TACTST.TSKSTAT.ENUM.8",                      "TIMED OUT"},
        {"K55TACTST.TSKSTAT.ENUM.9",                      "DOESNT EXIST"},

        {"K55TACTST.TSKAPRC",                             "Action App Return Code"},

        {"K55TACTST.TSKMSGE",                             "Action Message"},

        {"K55TACTST.TSKINST",                             "Action Instance"},

        {"K55TACTST.TSKOUTP",                             "Action Results"},

        {"K55TACTST.TSKCMND",                             "Action Command"},

        {"K55TACTST.TSKORGN",                             "Action Node"},

        {"K55TACTST.TSKSBND",                             "Action Subnode"},

        {"K55TACTST.TSKID",                               "Action ID"},

        {"K55TACTST.TSKTYPE",                             "Action Type"},
        {"K55TACTST.TSKTYPE.ENUM.0",                      "UNKNOWN"},
        {"K55TACTST.TSKTYPE.ENUM.1",                      "AUTOMATION"},

        {"K55TACTST.TSKOWNR",                             "Action Owner"},

};
return contents;
}

public Object[][] _oM9()
{
Object[][] contents = 
{
        {"TABLE.K55RESPONS.OBJECT",                       "K55 RESPONSIVENESS"},
        {"K55RESPONS.ORIGINNODE",                         "Node"},

        {"K55RESPONS.TIMESTAMP",                          "Timestamp"},

        {"K55RESPONS.MANAGEDSYS",                         "ManagedSystemName"},

        {"K55RESPONS.PRODUCTCOD",                         "ProductCode"},

        {"K55RESPONS.STATUSB",                            "StatusB"},

        {"K55RESPONS.RESPONSEST",                         "ResponseStatus"},

        {"K55RESPONS.STATUSA",                            "StatusA"},

        {"K55RESPONS.MANAGINGSY",                         "ManagingSystem"},

        {"K55RESPONS.HOSTNAME",                           "Hostname"},

};
return contents;
}

public Object[][] _oM10()
{
Object[][] contents = 
{
        {"TABLE.K55SUMMARY.OBJECT",                       "K55 SUMMARY"},
        {"K55SUMMARY.ORIGINNODE",                         "Node"},

        {"K55SUMMARY.TIMESTAMP",                          "Timestamp"},

        {"K55SUMMARY.TEMSNODE0",                          "TemsNode"},

        {"K55SUMMARY.NOTRESPONS",                         "NotResponsive"},
        {"K55SUMMARY.NOTRESPONS.ENUM.-2147483648",        "Value Exceeds Minimum"},
        {"K55SUMMARY.NOTRESPONS.ENUM.2147483647",         "Value Exceeds Maximum"},

        {"K55SUMMARY.OFFLINE",                            "Offline"},
        {"K55SUMMARY.OFFLINE.ENUM.-2147483648",           "Value Exceeds Minimum"},
        {"K55SUMMARY.OFFLINE.ENUM.2147483647",            "Value Exceeds Maximum"},

        {"K55SUMMARY.RESPONSIVE",                         "Responsive"},
        {"K55SUMMARY.RESPONSIVE.ENUM.-2147483648",        "Value Exceeds Minimum"},
        {"K55SUMMARY.RESPONSIVE.ENUM.2147483647",         "Value Exceeds Maximum"},

};
return contents;
}

public Object[][] _oM11()
{
Object[][] contents = 
{
        {"TABLE.K55RSPPOS.OBJECT",                        "K55 RSP PERFORMANCE OBJECT STATUS"},
        {"K55RSPPOS.ORIGINNODE",                          "Node"},

        {"K55RSPPOS.TIMESTAMP",                           "Timestamp"},

        {"K55RSPPOS.ATTRGRP",                             "Query Name"},

        {"K55RSPPOS.OBJNAME",                             "Object Name"},

        {"K55RSPPOS.OBJTYPE",                             "Object Type"},
        {"K55RSPPOS.OBJTYPE.ENUM.0",                      "WMI"},
        {"K55RSPPOS.OBJTYPE.ENUM.1",                      "PERFMON"},
        {"K55RSPPOS.OBJTYPE.ENUM.10",                     "WMI REMOTE DATA"},
        {"K55RSPPOS.OBJTYPE.ENUM.11",                     "LOG FILE"},
        {"K55RSPPOS.OBJTYPE.ENUM.12",                     "JDBC"},
        {"K55RSPPOS.OBJTYPE.ENUM.13",                     "CONFIG DISCOVERY"},
        {"K55RSPPOS.OBJTYPE.ENUM.14",                     "NT EVENT LOG"},
        {"K55RSPPOS.OBJTYPE.ENUM.15",                     "FILTER"},
        {"K55RSPPOS.OBJTYPE.ENUM.16",                     "SNMP EVENT"},
        {"K55RSPPOS.OBJTYPE.ENUM.17",                     "PING"},
        {"K55RSPPOS.OBJTYPE.ENUM.18",                     "DIRECTOR DATA"},
        {"K55RSPPOS.OBJTYPE.ENUM.19",                     "DIRECTOR EVENT"},
        {"K55RSPPOS.OBJTYPE.ENUM.2",                      "WMI ASSOCIATION GROUP"},
        {"K55RSPPOS.OBJTYPE.ENUM.20",                     "SSH REMOTE SHELL COMMAND"},
        {"K55RSPPOS.OBJTYPE.ENUM.3",                      "JMX"},
        {"K55RSPPOS.OBJTYPE.ENUM.4",                      "SNMP"},
        {"K55RSPPOS.OBJTYPE.ENUM.5",                      "SHELL COMMAND"},
        {"K55RSPPOS.OBJTYPE.ENUM.6",                      "JOINED GROUPS"},
        {"K55RSPPOS.OBJTYPE.ENUM.7",                      "CIMOM"},
        {"K55RSPPOS.OBJTYPE.ENUM.8",                      "CUSTOM"},
        {"K55RSPPOS.OBJTYPE.ENUM.9",                      "ROLLUP DATA"},

        {"K55RSPPOS.OBJSTTS",                             "Object Status"},
        {"K55RSPPOS.OBJSTTS.ENUM.0",                      "ACTIVE"},
        {"K55RSPPOS.OBJSTTS.ENUM.1",                      "INACTIVE"},

        {"K55RSPPOS.ERRCODE",                             "Error Code"},
        {"K55RSPPOS.ERRCODE.ENUM.0",                      "NO ERROR"},
        {"K55RSPPOS.ERRCODE.ENUM.1",                      "GENERAL ERROR"},
        {"K55RSPPOS.ERRCODE.ENUM.10",                     "NO INSTANCES RETURNED"},
        {"K55RSPPOS.ERRCODE.ENUM.11",                     "ASSOCIATOR QUERY FAILED"},
        {"K55RSPPOS.ERRCODE.ENUM.12",                     "REFERENCE QUERY FAILED"},
        {"K55RSPPOS.ERRCODE.ENUM.13",                     "NO RESPONSE RECEIVED"},
        {"K55RSPPOS.ERRCODE.ENUM.14",                     "CANNOT FIND JOINED QUERY"},
        {"K55RSPPOS.ERRCODE.ENUM.15",                     "CANNOT FIND JOIN ATTRIBUTE IN QUERY 1 RESULTS"},
        {"K55RSPPOS.ERRCODE.ENUM.16",                     "CANNOT FIND JOIN ATTRIBUTE IN QUERY 2 RESULTS"},
        {"K55RSPPOS.ERRCODE.ENUM.17",                     "QUERY 1 NOT A SINGLETON"},
        {"K55RSPPOS.ERRCODE.ENUM.18",                     "QUERY 2 NOT A SINGLETON"},
        {"K55RSPPOS.ERRCODE.ENUM.19",                     "NO INSTANCES RETURNED IN QUERY 1"},
        {"K55RSPPOS.ERRCODE.ENUM.2",                      "OBJECT NOT FOUND"},
        {"K55RSPPOS.ERRCODE.ENUM.20",                     "NO INSTANCES RETURNED IN QUERY 2"},
        {"K55RSPPOS.ERRCODE.ENUM.21",                     "CANNOT FIND ROLLUP QUERY"},
        {"K55RSPPOS.ERRCODE.ENUM.22",                     "CANNOT FIND ROLLUP ATTRIBUTE"},
        {"K55RSPPOS.ERRCODE.ENUM.23",                     "FILE OFFLINE"},
        {"K55RSPPOS.ERRCODE.ENUM.24",                     "NO HOSTNAME"},
        {"K55RSPPOS.ERRCODE.ENUM.25",                     "MISSING LIBRARY"},
        {"K55RSPPOS.ERRCODE.ENUM.26",                     "ATTRIBUTE COUNT MISMATCH"},
        {"K55RSPPOS.ERRCODE.ENUM.27",                     "ATTRIBUTE NAME MISMATCH"},
        {"K55RSPPOS.ERRCODE.ENUM.28",                     "COMMON DATA PROVIDER NOT STARTED"},
        {"K55RSPPOS.ERRCODE.ENUM.29",                     "CALLBACK REGISTRATION ERROR"},
        {"K55RSPPOS.ERRCODE.ENUM.3",                      "COUNTER NOT FOUND"},
        {"K55RSPPOS.ERRCODE.ENUM.30",                     "MDL LOAD ERROR"},
        {"K55RSPPOS.ERRCODE.ENUM.31",                     "AUTHENTICATION FAILED"},
        {"K55RSPPOS.ERRCODE.ENUM.32",                     "CANNOT RESOLVE HOST NAME"},
        {"K55RSPPOS.ERRCODE.ENUM.33",                     "SUBNODE UNAVAILABLE"},
        {"K55RSPPOS.ERRCODE.ENUM.34",                     "SUBNODE NOT FOUND IN CONFIG"},
        {"K55RSPPOS.ERRCODE.ENUM.35",                     "ATTRIBUTE ERROR"},
        {"K55RSPPOS.ERRCODE.ENUM.36",                     "CLASSPATH ERROR"},
        {"K55RSPPOS.ERRCODE.ENUM.37",                     "CONNECTION FAILURE"},
        {"K55RSPPOS.ERRCODE.ENUM.38",                     "FILTER SYNTAX ERROR"},
        {"K55RSPPOS.ERRCODE.ENUM.39",                     "FILE NAME MISSING"},
        {"K55RSPPOS.ERRCODE.ENUM.4",                      "NAMESPACE ERROR"},
        {"K55RSPPOS.ERRCODE.ENUM.40",                     "SQL QUERY ERROR"},
        {"K55RSPPOS.ERRCODE.ENUM.41",                     "SQL FILTER QUERY ERROR"},
        {"K55RSPPOS.ERRCODE.ENUM.42",                     "SQL DB QUERY ERROR"},
        {"K55RSPPOS.ERRCODE.ENUM.43",                     "SQL DB FILTER QUERY ERROR"},
        {"K55RSPPOS.ERRCODE.ENUM.44",                     "PORT OPEN FAILED"},
        {"K55RSPPOS.ERRCODE.ENUM.45",                     "ACCESS DENIED"},
        {"K55RSPPOS.ERRCODE.ENUM.46",                     "TIMEOUT"},
        {"K55RSPPOS.ERRCODE.ENUM.47",                     "NOT IMPLEMENTED"},
        {"K55RSPPOS.ERRCODE.ENUM.48",                     "REQUESTED A BAD VALUE"},
        {"K55RSPPOS.ERRCODE.ENUM.49",                     "RESPONSE TOO BIG"},
        {"K55RSPPOS.ERRCODE.ENUM.5",                      "OBJECT CURRENTLY UNAVAILABLE"},
        {"K55RSPPOS.ERRCODE.ENUM.50",                     "GENERAL RESPONSE ERROR"},
        {"K55RSPPOS.ERRCODE.ENUM.51",                     "SCRIPT NONZERO RETURN"},
        {"K55RSPPOS.ERRCODE.ENUM.52",                     "SCRIPT NOT FOUND"},
        {"K55RSPPOS.ERRCODE.ENUM.53",                     "SCRIPT LAUNCH ERROR"},
        {"K55RSPPOS.ERRCODE.ENUM.54",                     "CONF FILE DOES NOT EXIST"},
        {"K55RSPPOS.ERRCODE.ENUM.55",                     "CONF FILE ACCESS DENIED"},
        {"K55RSPPOS.ERRCODE.ENUM.56",                     "INVALID CONF FILE"},
        {"K55RSPPOS.ERRCODE.ENUM.57",                     "EIF INITIALIZATION FAILED"},
        {"K55RSPPOS.ERRCODE.ENUM.58",                     "CANNOT OPEN FORMAT FILE"},
        {"K55RSPPOS.ERRCODE.ENUM.59",                     "FORMAT FILE SYNTAX ERROR"},
        {"K55RSPPOS.ERRCODE.ENUM.6",                      "COM LIBRARY INIT FAILURE"},
        {"K55RSPPOS.ERRCODE.ENUM.60",                     "REMOTE HOST UNAVAILABLE"},
        {"K55RSPPOS.ERRCODE.ENUM.61",                     "EVENT LOG DOES NOT EXIST"},
        {"K55RSPPOS.ERRCODE.ENUM.62",                     "PING FILE DOES NOT EXIST"},
        {"K55RSPPOS.ERRCODE.ENUM.63",                     "NO PING DEVICE FILES"},
        {"K55RSPPOS.ERRCODE.ENUM.64",                     "PING DEVICE LIST FILE MISSING"},
        {"K55RSPPOS.ERRCODE.ENUM.65",                     "SNMP MISSING PASSWORD"},
        {"K55RSPPOS.ERRCODE.ENUM.66",                     "DISABLED"},
        {"K55RSPPOS.ERRCODE.ENUM.67",                     "URLS FILE NOT FOUND"},
        {"K55RSPPOS.ERRCODE.ENUM.68",                     "XML PARSE ERROR"},
        {"K55RSPPOS.ERRCODE.ENUM.69",                     "NOT INITIALIZED"},
        {"K55RSPPOS.ERRCODE.ENUM.7",                      "SECURITY INIT FAILURE"},
        {"K55RSPPOS.ERRCODE.ENUM.70",                     "ICMP SOCKETS FAILED"},
        {"K55RSPPOS.ERRCODE.ENUM.71",                     "DUPLICATE CONF FILE"},
        {"K55RSPPOS.ERRCODE.ENUM.72",                     "DELETED CONFIGURATION"},
        {"K55RSPPOS.ERRCODE.ENUM.9",                      "PROXY SECURITY FAILURE"},

        {"K55RSPPOS.COLSTRT",                             "Last Collection Start"},
        {"K55RSPPOS.COLSTRT.ENUM.0000000000000001",       "NOT COLLECTED"},
        {"K55RSPPOS.COLSTRT.ENUM.0691231190000000",       "NOT COLLECTED"},

        {"K55RSPPOS.COLFINI",                             "Last Collection Finished"},
        {"K55RSPPOS.COLFINI.ENUM.0000000000000001",       "NOT COLLECTED"},
        {"K55RSPPOS.COLFINI.ENUM.0691231190000000",       "NOT COLLECTED"},

        {"K55RSPPOS.COLDURA",                             "Last Collection Duration"},

        {"K55RSPPOS.COLAVGD",                             "Average Collection Duration"},
        {"K55RSPPOS.COLAVGD.ENUM.-100",                   "NO DATA"},

        {"K55RSPPOS.REFRINT",                             "Refresh Interval"},

        {"K55RSPPOS.NUMCOLL",                             "Number of Collections"},

        {"K55RSPPOS.CACHEHT",                             "Cache Hits"},

        {"K55RSPPOS.CACHEMS",                             "Cache Misses"},

        {"K55RSPPOS.CACHPCT",                             "Cache Hit Percent"},

        {"K55RSPPOS.INTSKIP",                             "Intervals Skipped"},

};
return contents;
}

 
  /**
   * Provide access to singleton Bundle wrapper for this resource bundle.
   *
   * @return reference to Bundle wrapper for this resource bundle
   */
//  Begin do not translate block
  public static final Bundle getBundle()
  {
    // if singleton bundle not yet created ...
    if (bundle == null)
    {
      // ... create it now
      bundle = new Bundle(BUNDLE_ID, BUNDLE_NAME, BundleManager.getCurrentLocale());
      BundleManager.addBundle(bundle);

      // make long-lived reference to singleton instance
      SingletonManager.add(bundle);
    }

    // return result
    return bundle;
  }

  /**
   * Implements Versioned interface
   */
  public Object getVersion()
  {
    return version.getVersion();
  }

  /**
   * Implements Versioned interface
   */
  public int compareVersion(Object targetVersion)
  {
    return version.compareVersion(targetVersion);
  }

  /**
   * Implementation of ResourceBundle.getKeys.
   */
  public Enumeration getKeys()
  {
    if (map.isEmpty())
      loadMap();

    return new Enumeration()
    {
      private Iterator mi = map.keySet().iterator();

      public boolean hasMoreElements()
      {
        return mi.hasNext();
      }

      public Object nextElement()
      {
        return mi.next();
      }
    };
  }

  /**
   * Gets an object for the given key from this resource bundle.
   * Returns null if this resource bundle does not contain an
   * object for the given key.
   *
   * @param key the key for the desired object
   * @exception NullPointerException if <code>key</code> is <code>null</code>
   * @return the object for the given key, or null
   */
  public Object handleGetObject(String key)
  {
    if (key == null)
      throw new NullPointerException();

    if (map.isEmpty())
      loadMap();

    return map.get(key); 
  }

  // load the resource map
  private void loadMap() 
  {
    Method[] methods = getClass().getDeclaredMethods();

    try
    {
      for (int i=0; i < methods.length; i++)
      {
        Method method = methods[i];

        if (method.getName().startsWith("_oM")) // one of the resource methods
        {
          Object[][] contents = (Object[][])method.invoke(this, (Object[]) null);

          for (int j = 0; j < contents.length; ++j)
          {
            map.put((String)contents[j][0], contents[j][1]);
          }
        }
      }
    }
    catch (Exception e)
    {
      e.printStackTrace();
    }
  }

  private static Bundle bundle;
  private static HashMap map = new HashMap(43);
//End do not translate block
}
