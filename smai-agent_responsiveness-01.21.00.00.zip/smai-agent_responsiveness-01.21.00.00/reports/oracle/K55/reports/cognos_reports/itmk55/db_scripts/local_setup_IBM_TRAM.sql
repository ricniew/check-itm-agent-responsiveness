----------------------------------------
--Build Date 11/03/28 17:21:39
----------------------------------------

CLEAR SCREEN;
set echo off
set autoprint off
set showmode off
rem set term off
set ver off
SET COLSEP '| '
set sqlterminator ';'
spool tcr_install.log
PROMPT ;
PROMPT                    IBM TRAM INSTALLATION SCRIPT                       ;

PROMPT ;
PROMPT The script will add new user (IBM_TRAM) with all objects needed by TCR;
PROMPT ;
PROMPT The parameters: 
PROMPT  - system user and password (needed priviliges to add new user)
PROMPT  - password for new user
PROMPT  - ITMUSER user (needed for granting priviliges)
PROMPT  - default tablespace name for new user
PROMPT  - default temporary tablespace name for new user
PROMPT  - Information about TDW datastores (y/n) 
PROMPT ;
PROMPT Press Enter to continue or CTRL+C to exit without changes;
ACCEPT CONFIRM_VAR;
ACCEPT SYS_USER PROMPT 'Enter SYS USERNAME: '
ACCEPT SYS_PASS PROMPT 'Enter SYS PASS:     ' HIDE

 
PROMPT ;
PROMPT Checking connection ... 
conn &SYS_USER/&SYS_PASS as sysdba;
PROMPT ;
PROMPT Press Enter to continue or CTRL+C if connection error;
ACCEPT CONFIRM_VAR;

PROMPT ;
ACCEPT TCR_PASS PROMPT 'Enter PASS for new user IBM_TRAM: ' HIDE
PROMPT ;
ACCEPT ITM_USER PROMPT 'Enter ITMUSER USERNAME: '

PROMPT In order to create new user we need to provide proper tablespaces;
PROMPT List of avaiable tablespaces:

select TABLESPACE_NAME, STATUS from DBA_TABLESPACES
/
PROMPT Press Enter to continue or CTRL+C if non of them is working for you or select return error;
ACCEPT CONFIRM_VAR;


PROMPT ;
ACCEPT DEFAULT_TBSPC PROMPT 'Enter default tablespace name for IBM_TRAM: '
select decode(count (TABLESPACE_NAME), 1, 'OK <&DEFAULT_TBSPC> - exists', 'ERROR - <&DEFAULT_TBSPC> does not exist! Press CTRL+C to break!') as  "Checking ... :"
  from DBA_TABLESPACES where STATUS = 'ONLINE' and upper(TABLESPACE_NAME) = upper('&DEFAULT_TBSPC');

PROMPT Press Enter to continue or CTRL+C if select returned error;
ACCEPT CONFIRM_VAR;

PROMPT ;
ACCEPT TEMPORARY_TBSPC PROMPT 'Enter temporary tablespace name for IBM_TRAM: '
select decode(count (TABLESPACE_NAME), 1, 'OK <&TEMPORARY_TBSPC> - exists', 'ERROR - <&TEMPORARY_TBSPC> does not exist! Press CTRL+C to break!') as  "Checking ... :"
  from DBA_TABLESPACES where STATUS = 'ONLINE' and upper(TABLESPACE_NAME) = upper('&TEMPORARY_TBSPC');

PROMPT Press Enter to continue or CTRL+C if select returned error;
ACCEPT CONFIRM_VAR;

PROMPT ;
@@create_IBM_TRAM.sql &TCR_PASS &DEFAULT_TBSPC &TEMPORARY_TBSPC

PROMPT Press Enter to continue or CTRL+C if command(s) returned error;
ACCEPT CONFIRM_VAR;

PROMPT ;
PROMPT Connecting to new user IBM_TRAM;
connect IBM_TRAM/&TCR_PASS;

PROMPT Press Enter to continue or CTRL+C if connection error;
ACCEPT CONFIRM_VAR;
PROMPT ;

PROMPT Creating IBM_TRAM objects;
@@create_schema.sql &DEFAULT_TBSPC

PROMPT Grant IBM_TRAM objects;
@@grant_IBM_TRAM.sql &ITM_USER
 
PROMPT Creating procedure: CREATE_TIME_DIMENSION;
@@gen_time_dim_granularity_hr.sql

PROMPT Press Enter to continue or CTRL+C if select returned error;
ACCEPT CONFIRM_VAR;

PROMPT Loading IBM_TRAM data ;
@@populateLookup.sql

PROMPT ENTER data range for TIME_DIMENSION. PROPER FORMAT IS 'YYYY-MM-DD 00:00';
ACCEPT START_DATE PROMPT 'Enter START DATE (e.g 2007-12-31 00:00): '
ACCEPT END_DATE PROMPT   'Enter END   DATE (e.g 2011-12-31 00:00): '
ACCEPT GRANULARITY PROMPT   'Enter GRANULARITY (e.g 60): '

@@populateTimeDimension.sql '&START_DATE' '&END_DATE' '&GRANULARITY'





spool off
 
PROMPT Press Enter to exit IBM TCR SCHEMA INSTALLATION SCRIPT;
ACCEPT CONFIRM_VAR;




