----------------------------------------
--Build Date 11/03/28 17:21:39
----------------------------------------

define ITM_USER =&1

grant select on TIME_DIMENSION to &ITM_USER ;
grant select on MONTH_LOOKUP to &ITM_USER ;
grant select on WEEKDAY_LOOKUP to &ITM_USER ;
grant select on "ComputerSystem" to &ITM_USER ;
