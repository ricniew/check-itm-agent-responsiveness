/*--------------------------------------------------------------
  IBM Tivoli Monitoring Agent Builder
 
  (C) Copyright IBM Corporation 2011. All rights reserved. 

  Oracle Script to populate ManagedSystem

  This procedure populates the ManagedSystem table with the 
  list of unique managed systems for a specified agent type. 
  It obtains the list of managed systems by reading the 
  following tables in the Tivoli Data Warehouse if they 
  exist: 
  * the agent's performance object status table
  * discovery tables if the agent has subnodes
  * availability if the agent collects process or service
    data

  Historical collection must be started on all these
  attribute groups so that the managed system names can
  be determined.
 
  This procedure does NOT delete entries from the ManagedSystem 
  table. It only adds managed systems that do not already exist 
  in the table. Therefore values such as FullyQualifiedHostName 
  can be updated later by the end user and the changes will not
  be lost when the procedure is executed again.

  This procedure should be executed periodically in order to 
  process any new managed systems. Otherwise Cognos reports may
  not include new managed systems that came online since the
  populate_msn procedure was last run.

  Prior to running this script, change all occurrences of
  itmuser to your Tivoli Data Warehouse (TDW) user id.

  To run the script using SQL*Plus:
  sqlplus <TDW user id>/<password>@<Oracle SID> @./create_procedure.sql

  To see the debugging output, prior to running the procedure 
  from SQL*Plus, issue the command:
  SET SERVEROUTPUT ON SIZE <buffer_size>

  Where <buffer size> is the size of the output buffer in 
  bytes.

  To execute the procedure:
  execute kqz_populate_msn('<three letter product code for the agent>');

  Parameters:
  pv_productcode:  The agent's three letter product code
  ------------------------------------------------------------*/

CREATE OR REPLACE PROCEDURE itmuser.kqz_populate_msn(pv_productcode IN varchar2) IS
  TYPE table_cur_type IS REF CURSOR;
  c_tables table_cur_type;
  c_msn table_cur_type;
  v_sql varchar2(1024);
  v_table_name user_tables.table_name%TYPE;
  v_msn ManagedSystem.ManagedSystemName%TYPE;
  v_parent_msn ManagedSystem.ManagedSystemName%TYPE := NULL;

  -- total number of new rows inserted into the ManagedSystem
  -- table
  v_rows_inserted NUMBER := 0;

  v_product_code varchar2(3);
  v_subnode_resource_name varchar2(32);

  -- CHANGE TO YOUR Tivoli Data Warehouse schema!
  v_schema_name varchar(128) := 'itmuser';

  /* FullyQualifiedHostname is defined as NOT NULL in the 
     ManagedSystem table, so we have to provide a non blank
     value.  Oracle will insert NULL if a blank string '' is
     used.
   */
  v_hostname ManagedSystem.FullyQualifiedHostname%TYPE := 'N/A';

  v_table_count NUMBER := 0;
BEGIN 

  /* make sure the product code is in upper case */
  v_product_code := upper(pv_productcode);

  /* We need to see if the agent's performance object status 
     table exists. It may not exist if:
     - an invalid product code was specified
     - historical collection was not enabled on the performance
       object status attribute group
     - historical collection was enabled on the performance 
       object status attribute group, but no data has been 
       exported to the Tivoli Data Warehouse
     - The agent only monitors processes or services
   */

  v_table_name :=  v_product_code || 
    '_PERFORMANCE_OBJECT_STATUS';

  /* querying from all_tables rather than user_tables 
     so that the caller doesn't have to be the TDW user */
  SELECT COUNT(*) 
  INTO v_table_count
  FROM all_tables 
  WHERE Table_Name = v_table_name
  AND owner = upper(v_schema_name);

  /* The Performance Object Status table exists */
  IF (v_table_count <> 0) THEN

    /* Get the list of MSNs from the Performance Object 
       Status table that do not already exist in the
       ManagedSystem table*/
    v_sql := 'SELECT DISTINCT "Node" FROM ' 
     || v_schema_name || '.' || v_table_name
     || ' T1 WHERE NOT EXISTS (SELECT * FROM '
     || v_schema_name 
     || '.ManagedSystem T2 WHERE T1."Node" = ' 
     || 'T2.ManagedSystemName)';

    dbms_output.put_line('Performance Object Status sql: ' || v_sql);

    OPEN c_msn FOR v_sql;

    /* Process each of the managed systems */
    LOOP
      FETCH c_msn INTO v_msn;

      EXIT WHEN c_msn%NOTFOUND;

      dbms_output.put_line('  Inserting msn: ' || v_msn);

      /* insert the new row into the ManagedSystem table */
      INSERT INTO itmuser.ManagedSystem 
        (ManagedSystemName,FullyQualifiedHostname,DisplayName,
         AgentType,ParentMSN)
      VALUES 
        (v_msn,v_hostname,'N/A',v_product_code,NULL);

      v_rows_inserted := v_rows_inserted + 1;
    END LOOP;

    CLOSE c_msn;

    COMMIT;

  /* there was no performance object status table, so look for
     the availability table */
  ELSE

    /* We need to see if the agent's availability table
       exists. It may not exist if:
       - an invalid product code was specified
       - historical collection was not enabled on the 
         availability attribute group
       - historical collection was enabled on the availability 
         attribute group, but no data has been exported to the
         Tivoli Data Warehouse
       - The agent doesn't monitor processes or services
     */
    v_table_name :=  v_product_code || 
      '_AVAILABILITY';

    /* querying from all_tables rather than user_tables 
       so that the caller doesn't have to be the TDW user */
    SELECT COUNT(*) 
    INTO v_table_count
    FROM all_tables 
    WHERE Table_Name = v_table_name
    AND owner = upper(v_schema_name);

    /* The availability table exists */
    IF (v_table_count <> 0) THEN

      /* Get the list of MSNs from the availability table
        that do not already exist in the ManagedSystem table */
      v_sql := 'SELECT DISTINCT "Node" FROM ' 
       || v_schema_name || '.' || v_table_name
       || ' T1 WHERE NOT EXISTS (SELECT * FROM '
       || v_schema_name || '.ManagedSystem T2 '
       || 'WHERE T1."Node" = T2.ManagedSystemName)';

      dbms_output.put_line('Availability sql: ' || v_sql);

      OPEN c_msn FOR v_sql;

      /* process each of the managed systems */
      LOOP
        FETCH c_msn INTO v_msn;

        EXIT WHEN c_msn%NOTFOUND;

        dbms_output.put_line('  Inserting msn: ' || v_msn);

        /* insert the new row into the ManagedSystem table */
        INSERT INTO itmuser.ManagedSystem 
          (ManagedSystemName,FullyQualifiedHostname,DisplayName,
           AgentType,ParentMSN)
        VALUES 
          (v_msn,v_hostname,'N/A',v_product_code,NULL);

        v_rows_inserted := v_rows_inserted + 1;
      END LOOP;

      CLOSE c_msn;

      COMMIT;

    END IF;
  END IF;

  /* 
     Find all of the agent's discovery tables. There will be
     discovery tables if the agent has subnodes.  This is not 
     easy to do since the names of the tables do not follow a
     consistent naming convention. Therefore we have to look 
     for tables that have ALL of the following columns:
     Subnode_Affinity, Subnode_MSN, Subnode_Type, 
     Subnode_Resource_Name, Subnode_Version
   */
  v_sql := 'SELECT table_name FROM all_tab_columns ' || 
   'WHERE table_name LIKE ''' || v_product_code || 
   '%'' AND column_name IN (' ||
   '''Subnode_Affinity'', ''Subnode_MSN'',' ||
   '''Subnode_Type'',''Subnode_Resource_Name'',' ||
   '''Subnode_Version'')' ||
   ' AND OWNER = UPPER(''' || v_schema_name || ''')' ||
   ' GROUP BY table_name' ||
   ' HAVING COUNT(*) = 5';

  dbms_output.put_line('Discovery table query sql: ' || v_sql);

  OPEN c_tables FOR v_sql;

  /* process each of the discovery tables */
  LOOP
    FETCH c_tables INTO v_table_name;

    EXIT WHEN c_tables%NOTFOUND;

    dbms_output.put_line('  Discovery table found: ' || 
       v_table_name);

    /* now query the table for list of managed systems that don't 
       already exist in the ManagedSystem table */
    v_sql := 'SELECT DISTINCT "Node","Subnode_MSN","Subnode_Resource_Name" ' 
     || 'FROM ' || v_schema_name || '.' || v_table_name 
     || ' T1 WHERE NOT EXISTS (SELECT * FROM '
     || v_schema_name || '.ManagedSystem T2 '
     || 'WHERE T1."Subnode_MSN" = T2.ManagedSystemName)';

    dbms_output.put_line('  sql: ' || v_sql);

    OPEN c_msn FOR v_sql;

    /* process each of the managed systems */
    LOOP
      FETCH c_msn INTO v_parent_msn,v_msn,v_subnode_resource_name;

      EXIT WHEN c_msn%NOTFOUND;

      dbms_output.put_line('  Inserting msn: ' || v_msn 
        || ' Parent MSN: ' || v_parent_msn ||
        ' Resource Name: ' || v_subnode_resource_name);

      /* insert the new row into the ManagedSystem table */
      INSERT INTO itmuser.ManagedSystem 
      (ManagedSystemName,FullyQualifiedHostname,DisplayName,
       AgentType,ParentMSN)
      VALUES 
      (v_msn,v_hostname,v_subnode_resource_name,
       v_product_code,v_parent_msn);

      v_rows_inserted := v_rows_inserted + 1;
    END LOOP;

    CLOSE c_msn;

    COMMIT;

  END LOOP;

  CLOSE c_tables;

  dbms_output.put_line('Number of rows inserted: ' || v_rows_inserted);

END;

/
