/**************************************************************
  IBM Tivoli Monitoring Agent Builder

  (C) Copyright IBM Corporation 2011. All rights reserved.

  Script that alters the ManagedSystem table if it already 
  exists and adds an additional index.  An additional column is
  added that correlates subnode managed system names to the
  agent's managed system name. This information can then be 
  used in Cognos reports to group together data for a given
  subnode agent.

  Change "ITMUSER" to your Tivoli Data Warehouse user id.

  To run the script using SQL*Plus:
  sqlplus <user>/<password>@<oracle SID> @./alter_table.sql
 **************************************************************/
WHENEVER SQLERROR CONTINUE;

ALTER TABLE "ITMUSER".ManagedSystem 
  ADD ParentMSN VARCHAR2(64);

CREATE UNIQUE INDEX "ITMUSER".IXManagedSystem ON ManagedSystem
(ManagedSystemName)    
 PCTFREE 20;
 
CREATE INDEX "ITMUSER".IXParentMSN ON ManagedSystem
(ParentMSN)
PCTFREE 20; 
