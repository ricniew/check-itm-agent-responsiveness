----------------------------------------
--Build Date 11/03/28 17:21:39
----------------------------------------

define def_START_DATE =&1
define def_END_DATE =&2
define def_GRANULARITY =&3

set serveroutput on
PROMPT Generating TIME_DIMENSION;
begin
  CREATE_TIME_DIMENSION('&def_START_DATE','&def_END_DATE','&def_GRANULARITY'); 
end;
/
