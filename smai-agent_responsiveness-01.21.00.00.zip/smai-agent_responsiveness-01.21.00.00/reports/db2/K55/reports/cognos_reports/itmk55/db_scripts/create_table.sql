-------------------------------------------------------------------------
--  IBM Tivoli Monitoring Agent Builder
--
--  (C) Copyright IBM Corporation 2011. All rights reserved.
--
--  Script that creates the ManagedSystem table and indexes. The 
--  ManagedSystem table is used for the ManagedSystem dimension in
--  Cognos reports.
--
--  Change "ITMUSER" to your Tivoli Data Warehouse user id.
--
--  To run the script:
--  db2 connect to <TDW warehouse alias> user <TDW user> using <password>
--  db2 -tvf create_table.sql
-------------------------------------------------------------------------

CREATE TABLE "ITMUSER".ManagedSystem (
  ManagedSystemName VARCHAR (64) NOT NULL,
  FullyQualifiedHostname VARCHAR (384),
  DisplayName VARCHAR (64) NOT NULL,
  AgentType  VARCHAR (32)  NOT NULL,
  ParentMSN VARCHAR(64)
) ;

CREATE UNIQUE INDEX "ITMUSER".IXManagedSystem ON ManagedSystem
(ManagedSystemName)    
 PCTFREE 20; 

CREATE INDEX "ITMUSER".IXParentMSN ON ManagedSystem
(ParentMSN)    
PCTFREE 20; 
