--------------------------------------------------------------
--  IBM Tivoli Monitoring Agent Builder
-- 
--  (C) Copyright IBM Corporation 2011. All rights reserved. 
--
--
--  DB2 Script to populate ManagedSystem
--
--  This procedure populates the ManagedSystem table with the 
--  list of unique managed systems for a specified agent type. 
--  It obtains the list of managed systems by reading the 
--  following tables in the Tivoli Data Warehouse if they 
--  exist: 
--  * the agent's performance object status table
--  * discovery tables if the agent has subnodes
--  * availability if the agent collects process or service
--    data
--
--  Historical collection must be started on all these
--  attribute groups so that the managed system names can
--  be determined.
-- 
--  This procedure does NOT delete entries from the 
--  ManagedSystem table. It only adds managed systems that 
--  do not already exist in the table. Therefore values 
--  such as FullyQualifiedHostName can be updated later by 
--  the end user and the changes will not be lost when the 
--  procedure is executed again.
--
--  This procedure should be executed periodically in order to 
--  process any new managed systems. Otherwise Cognos reports may
--  not include new managed systems that came online since the
--  populate_msn procedure was last run.
--
--  Prior to running this script, change all occurrences of
--  itmuser to your Tivoli Data Warehouse user id.
--
--  To run the script from the DB2 command line:
--  db2 connect to <TDW database alias> user <TDW user id> using <password>
--  db2 -td@ -f create_procedure.sql
--
--  To invoke the procedure from the DB2 command line:
--  db2 connect to <TDW database alias> user <TDW user id> using <password>
--  db2 "call <TDW schema>.kqz_populate_msn('<three letter product code for the agent>')"
--
--  Parameters:
--  pv_productcode:  The agent's three letter product code
-- 
--------------------------------------------------------------
DROP procedure itmuser.kqz_populate_msn@

CREATE procedure itmuser.kqz_populate_msn(pv_productcode varchar(3))
LANGUAGE SQL
MODIFIES SQL DATA
BEGIN
  DECLARE SQLCODE INTEGER DEFAULT 0;
  DECLARE v_sql varchar(1024);
  DECLARE v_table_name varchar(128);
  DECLARE v_short_name varchar(10);
  DECLARE v_msn varchar(64);
  DECLARE v_parent_msn varchar(64);
  DECLARE v_rows_inserted INTEGER DEFAULT 0;
  DECLARE v_product_code varchar(3);
  DECLARE v_subnode_resource_name varchar(32);

  -- CHANGE to your TDW schema:
  DECLARE v_schema varchar(128) DEFAULT 'itmuser';

  -- FullyQualifiedHostname is defined as NOT NULL in the 
  -- ManagedSystem table
  DECLARE v_hostname varchar(384) DEFAULT 'N/A';
  DECLARE v_table_count INTEGER DEFAULT 0;

  -- flags to indicate if we've read all of the rows from a 
  -- cursor
  DECLARE v_at_end INTEGER DEFAULT 0;
  DECLARE v_at_end_inner INTEGER DEFAULT 0;

  DECLARE stmt1 STATEMENT;
  DECLARE stmt2 STATEMENT;
  DECLARE stmt3 STATEMENT;
  DECLARE stmt4 STATEMENT;

  DECLARE c1 CURSOR WITH HOLD FOR stmt1;
  DECLARE c2 CURSOR WITH HOLD FOR stmt2;
  DECLARE c3 CURSOR WITH HOLD FOR stmt3;
  DECLARE c4 CURSOR WITH HOLD FOR stmt4;

  -- make sure the product code is in upper case 
  SET v_product_code = upper(pv_productcode);

  -- We need to see if the agent's performance object status 
  -- table exists. It may not exist if:
  --   * an invalid product code was specified
  --   * historical collection was not enabled on the performance
  --     object status attribute group
  --   * historical collection was enabled on the performance 
  --     object status attribute group, but no data has been 
  --     exported to the Tivoli Data Warehouse
  --   * The agent only monitors processes or services
  SET v_table_name = v_product_code ||
     '_PERFORMANCE_OBJECT_STATUS';
  SET v_short_name = v_product_code || 'POBJST';

  -- There could be multiple copies of the table if the database
  -- has several schemas that contain Tivoli Data Warehouse 
  -- tables. Therefore, look for tables created by the specified
  -- user.
  SELECT COUNT(*) 
  INTO v_table_count
  FROM sysibm.systables
  WHERE Name = v_table_name
  OR Name = v_short_name
  AND creator = upper(v_schema);

  -- The Performance Object Status table exists
  IF (v_table_count <> 0) THEN
    -- Get the list of MSNs from the Performance Object 
    -- Status table that do not already exist in the
    -- ManagedSystem table.
    SET v_sql = 'SELECT DISTINCT "Node" FROM ' 
     || v_schema  || '.' || v_table_name
     || ' T1 WHERE NOT EXISTS (SELECT * FROM '
     || v_schema  || '.ManagedSystem T2 '
     || ' WHERE T1."Node" = T2.ManagedSystemName)';

    PREPARE stmt1 FROM v_sql;

    OPEN c1;

    SET v_at_end = 0;

    -- Process each of the managed system names
    WHILE (v_at_end = 0) DO
      FETCH c1 INTO v_msn;

      IF SQLCODE <> 0 THEN 
        SET v_at_end = 1;
      ELSE 
        -- insert the new row into the ManagedSystem table 
        INSERT INTO itmuser.ManagedSystem 
        (ManagedSystemName,FullyQualifiedHostname,DisplayName,
         AgentType,ParentMSN)
         VALUES 
        (v_msn,v_hostname,'N/A',v_product_code,NULL);

        SET v_rows_inserted = v_rows_inserted + 1;
      END IF;
    END WHILE;

    CLOSE c1;

    -- commit any inserts we have peformed
    IF (v_rows_inserted <> 0) THEN
      COMMIT WORK;
      SET v_rows_inserted = 0;
    END IF;

  -- there was no performance object status table, so look for
  -- the availability table 
  ELSE
    -- We need to see if the agent's availabilty table  
    -- exists. Agents that monitor processes or services
    -- will have an availability table. The availability 
    -- table may not exist if:
    --   * an invalid product code was specified
    --   * historical collection was not enabled on the
    --     availability attribute group
    --   * historical collection was enabled on the 
    --     availability attribute group, but no data has
    --     been exported to the Tivoli Data Warehouse
    --   * The agent does not monitor processes or services
    SET v_table_name = v_product_code ||
       '_AVAILABILITY';
    SET v_short_name = v_product_code || 'AVAIL';

    -- There could be multiple copies of the table if the 
    -- database has several schemas that contain Tivoli Data
    -- Warehouse tables. Therefore, look for tables created by 
    -- the specified user.
    SELECT COUNT(*) 
    INTO v_table_count
    FROM sysibm.systables
    WHERE Name = v_table_name
    OR Name = v_short_name
    AND creator = upper(v_schema);

    -- the availability table exists
    IF (v_table_count <> 0) THEN

      -- Get the list of MSNs from the availability table
      -- that do not already exist in the ManagedSystem table
      SET v_sql = 'SELECT DISTINCT "Node" FROM ' 
       || v_schema  || '.' || v_table_name
       || ' T1 WHERE NOT EXISTS (SELECT * FROM '
       || v_schema || '.ManagedSystem T2 '
       || ' WHERE T1."Node" = T2.ManagedSystemName)';

      PREPARE stmt4 FROM v_sql;

      OPEN c4;

      SET v_at_end = 0;

      -- Process each of the managed systems
      WHILE (v_at_end = 0) DO
        FETCH c4 INTO v_msn;

        IF SQLCODE <> 0 THEN 
          SET v_at_end = 1;
        ELSE 
          -- insert the new row into the ManagedSystem table 
          INSERT INTO itmuser.ManagedSystem 
          (ManagedSystemName,FullyQualifiedHostname,DisplayName,
           AgentType,ParentMSN)
           VALUES 
          (v_msn,v_hostname,'N/A',v_product_code,NULL);

          SET v_rows_inserted = v_rows_inserted + 1;
        END IF;
      END WHILE;

      CLOSE c4;

      -- commit any inserts we have peformed
      IF (v_rows_inserted <> 0) THEN
        COMMIT WORK;
        SET v_rows_inserted = 0;
      END IF;
    END IF;

  END IF;

  --   Find all of the agent's discovery tables. There will be
  --   discovery tables if the agent has subnodes.  This is not 
  --   easy to do since the names of the tables do not follow a
  --   consistent naming convention. Therefore we have to look 
  --   for tables that have ALL of the following columns:
  --   Subnode_Affinity, Subnode_MSN, Subnode_Type, 
  --   Subnode_Resource_Name, Subnode_Version
  SET v_sql = 'SELECT tbname FROM sysibm.syscolumns ' || 
   'WHERE tbname LIKE ''' || v_product_code || 
   '%'' AND name IN (' ||
   '''Subnode_Affinity'', ''Subnode_MSN'',' ||
   '''Subnode_Type'',''Subnode_Resource_Name'',' ||
   '''Subnode_Version'')' ||
   ' AND tbcreator = upper(''' || v_schema  || ''') ' ||
   ' GROUP BY tbname' ||
   ' HAVING COUNT(*) = 5';

  PREPARE stmt2 FROM v_sql;
  OPEN c2;

  -- process each of the discovery tables 
  SET v_at_end = 0;

  WHILE (v_at_end = 0) DO
    FETCH c2 INTO v_table_name;

    IF SQLCODE <> 0 THEN 
      SET v_at_end = 1;
    ELSE 
      -- now query the table for list of managed systems that 
      -- don't already exist in the ManagedSystem table 
      SET v_sql = 'SELECT DISTINCT "Node","Subnode_MSN",' ||
        '"Subnode_Resource_Name" ' || 
        'FROM ' || v_schema  || '.' || v_table_name || 
        ' T1 WHERE NOT EXISTS (SELECT * FROM ' || 
        v_schema  || '.ManagedSystem T2 ' ||
        'WHERE T1."Subnode_MSN" = T2.ManagedSystemName)';

      PREPARE stmt3 FROM v_sql;
      OPEN c3;

      SET v_at_end_inner = 0;

      -- process each of the managed systems 
      WHILE (v_at_end_inner = 0) DO
        FETCH c3 INTO v_parent_msn,v_msn,v_subnode_resource_name;

        IF SQLCODE <> 0 THEN 
          SET v_at_end_inner = 1;
        ELSE
          -- insert the new row into the ManagedSystem table
          INSERT INTO itmuser.ManagedSystem 
          (ManagedSystemName,FullyQualifiedHostname,DisplayName,
           AgentType,ParentMSN)
          VALUES 
          (v_msn,v_hostname,v_subnode_resource_name,
           v_product_code,v_parent_msn);

          SET v_rows_inserted = v_rows_inserted + 1;
        END IF;
      END WHILE;

      CLOSE c3;

      -- commit any inserts we have peformed
      IF (v_rows_inserted <> 0) THEN
        COMMIT WORK;
        SET v_rows_inserted = 0;
      END IF;

    END IF;
  END WHILE;

  CLOSE c2;

END
@
