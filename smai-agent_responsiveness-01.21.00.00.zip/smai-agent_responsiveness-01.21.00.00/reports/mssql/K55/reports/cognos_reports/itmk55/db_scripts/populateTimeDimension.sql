----------------------------------------
--Build Date 11/03/28 17:21:38
----------------------------------------

/*
  
  Modify parameters. 
  Pay attention on the last paramerter weekday. 
  Default for this is 7 - it means that Monday = 2 day of the week, 
  sweatching into 1 will cause Europan counting - Monday = 1 day of the week
    
*/

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET NOCOUNT ON
USE IBM_TRAM
GO

EXEC IBM_TRAM.CREATE_TIME_DIMENSION
	@startDate    = '2009-08-01 00:00:00', 
  @endDate      = '2010-07-08 00:00:00', 
  @granularity  = 60
GO

/*
EXEC IBM_TRAM.CREATE_TIME_DIMENSION
	@startDate    = '2010-02-28 12:55:16', 
  @endDate      = '2010-03-04 18:59:00', 
  @granularity  = 60,
  @weekday      = 7
GO

EXEC IBM_TRAM.CREATE_TIME_DIMENSION
	@startDate    = '2010-02-28 12:55:16', 
  @endDate      = '2010-03-04 18:59:00', 
  @granularity  = 60,
  @weekday      = 1
GO

*/
