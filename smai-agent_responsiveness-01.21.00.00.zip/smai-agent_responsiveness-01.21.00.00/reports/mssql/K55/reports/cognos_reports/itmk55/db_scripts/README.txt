Installation how-to

1. Customize script
  a)	createSchema.sql
    !)  Modify default database name in use statment ('USE IBM_TRAM') if it is different from the default

  b)  createProcedure.sql
    !)  Modify default database name in use statment ('USE IBM_TRAM') if it is different from the default
  
  c)	populateTimeDimension.sql

    !)  Modify default database name in use statment ('USE IBM_TRAM') if it is different from the default
		!!) Modify parameters: boundary for the time dimension and granularity. 
		If the Monday has to be the first day of the week, please add the fourth parameter equal 1.  
		In other case release three parameters.
	
  d) clean.sql
  !)  Modify default database name in use statment ('USE IBM_TRAM') if it is different from the default

2.Run scripts in following order using MS SQL command line (sqlcmd -i <inputFile> [-U <user> -P <password>] [-H <host>])

	a)	createSchema.sql
	c)	createProcedure.sql
	d)	populateTimeDimension.sql




*
To clean-up database start clean.sql
