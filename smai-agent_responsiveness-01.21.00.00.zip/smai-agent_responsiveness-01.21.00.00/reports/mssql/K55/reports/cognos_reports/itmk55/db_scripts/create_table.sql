-----------------------------------------------------------------
--  IBM Tivoli Monitoring Agent Builder
--
--  (C) Copyright IBM Corporation 2011. All rights reserved.
--
--  Script that creates the ManagedSystem table and indexes. The 
--  ManagedSystem table is used for the ManagedSystem dimension
--  in Cognos reports.
--
--  Change "ITMUSER" to your Tivoli Data Warehouse user id.
--
--  To run the script:
--  osql -S <Server> -U <TDW User id> -P <TDW password> -d <TDW database> -n -I -i create_table.sql
-----------------------------------------------------------------

CREATE TABLE "ITMUSER".ManagedSystem (
  ManagedSystemName VARCHAR (64) NOT NULL,
  FullyQualifiedHostname VARCHAR (384),
  DisplayName VARCHAR (64) NOT NULL,
  AgentType  VARCHAR (32)  NOT NULL,
  ParentMSN VARCHAR(64)
) 

GO

CREATE UNIQUE INDEX IXManagedSystem ON ManagedSystem
(ManagedSystemName)    

GO

CREATE INDEX IXParentMSN ON ManagedSystem
(ParentMSN)    

GO
