----------------------------------------
--Build Date 11/03/28 17:21:39
----------------------------------------

define TCR_PASS =&1
define DEFAULT_TBSPC =&2
define TEMPORARY_TBSPC =&3


PROMPT Creating user: IBM_TRAM;

create user          IBM_TRAM
identified by        &TCR_PASS
default   tablespace &DEFAULT_TBSPC
temporary tablespace &TEMPORARY_TBSPC;

grant CONNECT, CREATE TABLE, CREATE SYNONYM, CREATE VIEW, CREATE SEQUENCE, CREATE PROCEDURE, create any trigger to IBM_TRAM;
GRANT UNLIMITED TABLESPACE TO IBM_TRAM;
