Installation how-to
---------------------------------------------------------------------------
MANUAL INSTALLATION
---------------------------------------------------------------------------
Before you are starting make sure that you can access remotely as sys user. 
If �yes� perform steps from (a) if �no� perform steps from (b)


a) REMOTE CONNECTION
	1)	start sqlplus
	2)	start script @<your_path>\setup_IBM_TRAM.sql and provide all information which script requires


b) LOCAL CONNECTION
	1)	start sqlplus
	2)	start script @<your_path>\local_setup_IBM_TRAM.sql and provide all information which script requires


---------------------------------------------------------------------------
BATCH INSTALLATION
---------------------------------------------------------------------------

The scripts are interactive - it asks user about installation details and then calls proper scripts.

If you would like install in "batch mode" inside your installer you need to call following scripts in order as bellow. 

!! Pay attention on parameters and proper connection (the scripts go from different users)

1) Create user IBM_TRAM. The script has to be called by user with system rights (e.g. SYS/SYSTEM)

create_IBM_TRAM.sql <TCR_PASS> <USER_TBSPC> <TEMPORARY_TBSPC>
parameters:
<TCR_PASS>        - password for new user IBM_TRAM 
<USER_TBSPC>      - default user tablespaces name (has to exist)
<TEMPORARY_TBSPC> - default temporary tablespaces name (has to exist)

2) Create IBM_TRAM tables. The script has to be called by IBM_TRAM user (created in previous step)

create_schema.sql <USER_TBSPC> 
parameter:
<USER_TBSPC>      - default user tablespaces name (has to exist)

3) Grant privileges to your user (e.g. ITMUSER). The script has to be called by IBM_TRAM user.

grant_IBM_TRAM.sql <YOUR_USER>
parameter:
<YOUR _USER>      - user name which has to receive grants

4) Create procedure (the script has to be called by IBM_TRAM user).

gen_time_dim_granularity_hr.sql

5) Load lookup data (the script has to be called by IBM_TRAM user).

   populateLookup.sql

6) Generate time dimension. Start script as bellow. User: IBM_TRAM, pass parameters in format as in example bellow.

populateTimeDimension.sql <StartDate> <EndDate> <Granularity>

Parameters (varchar): 
StartDate                - varchar in format 'yyyy-mm-dd HH:MM'  
EndDate                  - varchar in format 'yyyy-mm-dd HH:MM'  
Granularity (in minutes) - varchar 

populateTimeDimension.sql '2007-12-31 00:00' '2011-12-31 00:00' '60' 



*
To clean-up database start clean.sql (user system, noone can be logged as IBM_TRAM user)
