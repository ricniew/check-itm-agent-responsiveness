----------------------------------------
--Build Date 11/03/28 17:21:38
----------------------------------------

SET NOCOUNT ON
USE IBM_TRAM
GO

CREATE SCHEMA IBM_TRAM; 
GO

PRINT N'Create table TIME_DIMENSION';
CREATE TABLE IBM_TRAM.TIME_DIMENSION (
	TIME_RANGE_START datetime NOT NULL,
	TIME_RANGE_END datetime NOT NULL,
	HOUR_KEY datetime NOT NULL,
	DAY_KEY datetime NOT NULL,
	WEEK_KEY datetime NOT NULL,
	MONTH_KEY datetime NOT NULL,
	QUARTER_KEY datetime NOT NULL,
	YEAR_KEY datetime NOT NULL,
	[CURRENT_DATE] datetime NOT NULL,
	CURRENT_MINUTE SMALLINT,	
	CURRENT_HOUR SMALLINT,
	CURRENT_DAY SMALLINT,
	CURRENT_WEEK SMALLINT,
	CURRENT_MONTH SMALLINT,
	CURRENT_QUARTER SMALLINT,
	CURRENT_YEAR SMALLINT,
	DAY_OF_WEEK SMALLINT,
	DAYS_IN_MONTH SMALLINT,
	DAY_OF_YEAR SMALLINT,
	WEEK_OF_MONTH SMALLINT,
	WEEK_OF_QUARTER SMALLINT,
	CANDLETIMESTAMP CHAR(16) NOT NULL,
	END_CANDLETIMESTAMP CHAR(16) NOT NULL,
		CONSTRAINT TIME_DIMENSION_PK PRIMARY KEY CLUSTERED (TIME_RANGE_START, TIME_RANGE_END)
	) ON [DEFAULT]
GO


CREATE UNIQUE NONCLUSTERED INDEX TIME_DIMENSION_MINUTE_KEY_IDX ON IBM_TRAM.TIME_DIMENSION (
	TIME_RANGE_START desc, TIME_RANGE_END asc
	) ON [DEFAULT]
GO

CREATE  NONCLUSTERED  INDEX IXCANDLE     ON IBM_TRAM.TIME_DIMENSION       
(CANDLETIMESTAMP, END_CANDLETIMESTAMP
	) ON [DEFAULT]
GO

CREATE NONCLUSTERED INDEX IXCURRYRMODAY     ON IBM_TRAM.TIME_DIMENSION      
 (CURRENT_YEAR, CURRENT_MONTH, CURRENT_DAY
  	) ON [DEFAULT]
GO

CREATE NONCLUSTERED INDEX IXCURRMODAY     ON IBM_TRAM.TIME_DIMENSION       
(CURRENT_MONTH, CURRENT_DAY	) ON [DEFAULT]
GO

CREATE NONCLUSTERED INDEX IXCURRMOWK     ON IBM_TRAM.TIME_DIMENSION       
(CURRENT_MONTH, CURRENT_WEEK	) ON [DEFAULT]
GO
	
CREATE NONCLUSTERED   INDEX IXCURRDAYHR     ON IBM_TRAM.TIME_DIMENSION      
 (CURRENT_DAY, CURRENT_HOUR	) ON [DEFAULT]
GO
 

PRINT N'Create table MONTH_LOOKUP';
CREATE TABLE IBM_TRAM.MONTH_LOOKUP	(
	MONTH_NUMBER SMALLINT,
	MONTH_EN VARCHAR(12),
	MONTH_FR VARCHAR(25),
	MONTH_PT_BR VARCHAR(25),
	MONTH_JA VARCHAR(25),
	MONTH_DE VARCHAR(25),
	MONTH_IT VARCHAR(25),
	MONTH_KO VARCHAR(25),
	MONTH_CS VARCHAR(25),
	MONTH_HU VARCHAR(25),
	MONTH_PL VARCHAR(25),
	MONTH_RU VARCHAR(25),
	MONTH_ZH_CN VARCHAR(25),
	MONTH_ZH_TW VARCHAR(25),
	MONTH_ES VARCHAR(25),
		CONSTRAINT MONTH_LOOKUP_PK PRIMARY KEY CLUSTERED (MONTH_NUMBER)
  ) ON [DEFAULT]
GO

PRINT N'Create table WEEKDAY_LOOKUP';
CREATE TABLE IBM_TRAM.WEEKDAY_LOOKUP	(
	WEEKDAY_NUMBER SMALLINT,
	WEEKDAY_EN VARCHAR(12),
	WEEKDAY_FR VARCHAR(25),
	WEEKDAY_PT_BR VARCHAR(25),
	WEEKDAY_JA VARCHAR(25),
	WEEKDAY_DE VARCHAR(25),
	WEEKDAY_IT VARCHAR(25),
	WEEKDAY_KO VARCHAR(25),
	WEEKDAY_CS VARCHAR(25),
	WEEKDAY_HU VARCHAR(25),
	WEEKDAY_PL VARCHAR(25),
	WEEKDAY_RU VARCHAR(25),
	WEEKDAY_ZH_CN VARCHAR(25),
	WEEKDAY_ZH_TW VARCHAR(25),
	WEEKDAY_ES VARCHAR(25),
		CONSTRAINT WEEKDAY_LOOKUP_PK PRIMARY KEY CLUSTERED (WEEKDAY_NUMBER)
  ) ON [DEFAULT]
GO


PRINT N'Create table TIMEZONE_DIMENSION';
CREATE TABLE IBM_TRAM.TIMEZONE_DIMENSION (
  TZOFF SMALLINT NOT NULL,
  DLS_START datetime,
  DLS_END datetime,
  DSLOFF SMALLINT,
  NAME_EN  VARCHAR(32) NOT NULL,
  ["DESC"] VARCHAR(128)
) ON [DEFAULT]
GO


PRINT N'Create table ComputerSystem';
CREATE TABLE IBM_TRAM.["ComputerSystem"]  (
  ["CSID"] INTEGER IDENTITY(1,1) NOT NULL,
  ["FQDN"]  VARCHAR (64) ,
  ["Manufacturer"] VARCHAR (64)  ,
  ["Model"] VARCHAR (64)  ,
  ["SerialNumber"] VARCHAR (64)  ,
  ["VMID"] VARCHAR(128),
  ["PrimaryMACAddress"] VARCHAR(64),
  ["IpAddress"] VARCHAR(32),
  ["Signature"] VARCHAR(128),
  ["ManagedSystemName"] VARCHAR(64),
  ["Group"] VARCHAR(64),
  ["TIME_RANGE_START"] DATETIME,
  ["TIME_RANGE_END"] DATETIME
CONSTRAINT COMPUTER_SYSTEM_PK PRIMARY KEY (["CSID"])
  ) ON [DEFAULT]
GO


PRINT 'TCR Shema created'
GO

PRINT 'TCR Shema: MONTH_LOOKUP - import data'
INSERT into IBM_TRAM.MONTH_LOOKUP(	MONTH_NUMBER,	MONTH_EN,	MONTH_FR,	MONTH_PT_BR,	MONTH_JA,	MONTH_DE,	MONTH_IT,	MONTH_KO,	MONTH_CS,	MONTH_HU,	MONTH_PL,	MONTH_RU,	MONTH_ZH_CN,	MONTH_ZH_TW,	MONTH_ES            )
(select 1, 'January', 'January_FR', '', '', '', '', '', '', '', '', '', '','','' )
union 
(select 2, 'February', 'February_FR', '', '', '', '', '', '', '', '', '', '','','') 
union
(select 3, 'March', 'March_FR', '', '', '', '', '', '', '', '', '', '','','') 
union
(select 4, 'April', 'April_FR', '', '', '', '', '', '', '', '', '', '','','')
union
(select 5, 'May', 'May_FR', '', '', '', '', '', '', '', '', '', '','','') 
union
(select 6, 'June', 'June_FR', '', '', '', '', '', '', '', '', '', '','','') 
union
(select 7, 'July', 'July_FR', '', '', '', '', '', '', '', '', '', '','','')
union
(select 8, 'August', 'August_FR', '', '', '', '', '', '', '', '', '', '','','') 
union
(select 9, 'September', 'September_FR', '', '', '', '', '', '', '', '', '', '','','')
union
(select 10, 'October', 'October_FR', '', '', '', '', '', '', '', '', '', '','','')
union
(select 11, 'November', 'November_FR', '', '', '', '', '', '', '', '', '', '','','') 
union
(select 12, 'December', 'December_FR', '', '', '', '', '', '', '', '', '', '','','');
GO 

PRINT 'TCR Shema: WEEKDAY_LOOKUP - import data'
INSERT into IBM_TRAM.WEEKDAY_LOOKUP(	WEEKDAY_NUMBER,	WEEKDAY_EN,	WEEKDAY_FR,	WEEKDAY_PT_BR,	WEEKDAY_JA,	WEEKDAY_DE,	WEEKDAY_IT,	WEEKDAY_KO,	WEEKDAY_CS,	WEEKDAY_HU,	WEEKDAY_PL,	WEEKDAY_RU,	WEEKDAY_ZH_CN,	WEEKDAY_ZH_TW,	WEEKDAY_ES  )
(select 1, 'Sunday', 'Sunday_FR', '', '', '', '', '', '', '', '', '', '','','' )
union 
(select 2, 'Monday', 'Monday_FR', '', '', '', '', '', '', '', '', '', '','','')
union 
(select 3, 'Tuesday', 'Tuesday_FR', '', '', '', '', '', '', '', '', '', '','','')
union 
(select 4, 'Wednesday', 'Wednesday_FR', '', '', '', '', '', '', '', '', '', '','','')
union
(select 5, 'Thursday', 'Thursday_FR', '', '', '', '', '', '', '', '', '', '','','')
union 
(select 6, 'Friday', 'Friday_FR', '', '', '', '', '', '', '', '', '', '','','')
union 
(select 7, 'Saturday', 'Saturday_FR', '', '', '', '', '', '', '', '', '', '','','');
GO
