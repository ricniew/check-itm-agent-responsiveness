*   Only Delete Statements generated
*


DELETE FROM KFWQUERY   WHERE ID       =
 'zk55.RSPDS';
DELETE FROM KFWTMPLSIT WHERE 
 TEMPLATE = 'zk55.RSPDS' AND NAME = '*Critical';
DELETE FROM KFWTMPLSIT WHERE 
 TEMPLATE = 'zk55.RSPDS' AND NAME = '*Warning';
DELETE FROM KFWTMPLSIT WHERE 
 TEMPLATE = 'zk55.RSPDS' AND NAME = '*Informational';
DELETE FROM KFWTMPLSIT WHERE 
 TEMPLATE = 'zk55.RSPDS' AND NAME = '*STATUS_UNKNOWN';
DELETE FROM KFWTMPLSIT WHERE 
 TEMPLATE = 'zk55.RSPDS' AND NAME = '*Fatal';
DELETE FROM KFWTMPLSIT WHERE 
 TEMPLATE = 'zk55.RSPDS' AND NAME = '*Minor';
DELETE FROM KFWTMPLSIT WHERE 
 TEMPLATE = 'zk55.RSPDS' AND NAME = '*Harmless';
DELETE FROM KFWTMPLSIT WHERE 
 TEMPLATE = 'zk55.RSPDS' AND NAME = '*Unknown';
DELETE FROM KFWTMPLSTA WHERE 
 TEMPLATE = 'zk55.RSPDS' AND NAME = 'OK';
DELETE FROM KFWTMPLSTA WHERE 
 TEMPLATE = 'zk55.RSPDS' AND NAME = 'Critical';
DELETE FROM KFWTMPLSTA WHERE 
 TEMPLATE = 'zk55.RSPDS' AND NAME = 'Warning';
DELETE FROM KFWTMPLSTA WHERE 
 TEMPLATE = 'zk55.RSPDS' AND NAME = 'Informational';
DELETE FROM KFWTMPLSTA WHERE 
 TEMPLATE = 'zk55.RSPDS' AND NAME = 'Unavailable';
DELETE FROM KFWTMPLSTA WHERE 
 TEMPLATE = 'zk55.RSPDS' AND NAME = 'Fatal';
DELETE FROM KFWTMPLSTA WHERE 
 TEMPLATE = 'zk55.RSPDS' AND NAME = 'Minor';
DELETE FROM KFWTMPLSTA WHERE 
 TEMPLATE = 'zk55.RSPDS' AND NAME = 'Harmless';
DELETE FROM KFWTMPLSTA WHERE 
 TEMPLATE = 'zk55.RSPDS' AND NAME = 'Unknown';
DELETE FROM KFWTMPL WHERE NAME     =
 'zk55.RSPDS';


DELETE FROM KFWPARMA WHERE TABLENAME = 'K55.K55RSPDS';

*   Only Delete Statements generated
*


DELETE FROM KFWQUERY   WHERE ID       =
 'zk55.obj_status';
DELETE FROM KFWTMPLSIT WHERE 
 TEMPLATE = 'zk55.obj_status' AND NAME = '*Critical';
DELETE FROM KFWTMPLSIT WHERE 
 TEMPLATE = 'zk55.obj_status' AND NAME = '*Warning';
DELETE FROM KFWTMPLSIT WHERE 
 TEMPLATE = 'zk55.obj_status' AND NAME = '*Informational';
DELETE FROM KFWTMPLSIT WHERE 
 TEMPLATE = 'zk55.obj_status' AND NAME = '*STATUS_UNKNOWN';
DELETE FROM KFWTMPLSIT WHERE 
 TEMPLATE = 'zk55.obj_status' AND NAME = '*Fatal';
DELETE FROM KFWTMPLSIT WHERE 
 TEMPLATE = 'zk55.obj_status' AND NAME = '*Minor';
DELETE FROM KFWTMPLSIT WHERE 
 TEMPLATE = 'zk55.obj_status' AND NAME = '*Harmless';
DELETE FROM KFWTMPLSIT WHERE 
 TEMPLATE = 'zk55.obj_status' AND NAME = '*Unknown';
DELETE FROM KFWTMPLSTA WHERE 
 TEMPLATE = 'zk55.obj_status' AND NAME = 'OK';
DELETE FROM KFWTMPLSTA WHERE 
 TEMPLATE = 'zk55.obj_status' AND NAME = 'Critical';
DELETE FROM KFWTMPLSTA WHERE 
 TEMPLATE = 'zk55.obj_status' AND NAME = 'Warning';
DELETE FROM KFWTMPLSTA WHERE 
 TEMPLATE = 'zk55.obj_status' AND NAME = 'Informational';
DELETE FROM KFWTMPLSTA WHERE 
 TEMPLATE = 'zk55.obj_status' AND NAME = 'Unavailable';
DELETE FROM KFWTMPLSTA WHERE 
 TEMPLATE = 'zk55.obj_status' AND NAME = 'Fatal';
DELETE FROM KFWTMPLSTA WHERE 
 TEMPLATE = 'zk55.obj_status' AND NAME = 'Minor';
DELETE FROM KFWTMPLSTA WHERE 
 TEMPLATE = 'zk55.obj_status' AND NAME = 'Harmless';
DELETE FROM KFWTMPLSTA WHERE 
 TEMPLATE = 'zk55.obj_status' AND NAME = 'Unknown';
DELETE FROM KFWTMPL WHERE NAME     =
 'zk55.obj_status';


DELETE FROM KFWPARMA WHERE TABLENAME = 'K55.K55POBJST';

*   Only Delete Statements generated
*


DELETE FROM KFWQUERY   WHERE ID       =
 'zk55.tpl_status';


DELETE FROM KFWPARMA WHERE TABLENAME = 'K55.K55THPLST';

*   Only Delete Statements generated
*


DELETE FROM KFWQUERY   WHERE ID       =
 'zk55.rgx_status';


DELETE FROM KFWPARMA WHERE TABLENAME = 'K55.K55LOGFRX';

*   Only Delete Statements generated
*


DELETE FROM KFWQUERY   WHERE ID       =
 'zk55.log_status';


DELETE FROM KFWPARMA WHERE TABLENAME = 'K55.K55LOGFST';

*   Only Delete Statements generated
*


DELETE FROM KFWQUERY   WHERE ID       =
 'zk55.tac_status';


DELETE FROM KFWPARMA WHERE TABLENAME = 'K55.K55TACTST';

*   Only Delete Statements generated
*


DELETE FROM KFWQUERY   WHERE ID       =
 'zk55.RESPONS';
DELETE FROM KFWTMPLSIT WHERE 
 TEMPLATE = 'zk55.RESPONS' AND NAME = '*Critical';
DELETE FROM KFWTMPLSIT WHERE 
 TEMPLATE = 'zk55.RESPONS' AND NAME = '*Warning';
DELETE FROM KFWTMPLSIT WHERE 
 TEMPLATE = 'zk55.RESPONS' AND NAME = '*Informational';
DELETE FROM KFWTMPLSIT WHERE 
 TEMPLATE = 'zk55.RESPONS' AND NAME = '*STATUS_UNKNOWN';
DELETE FROM KFWTMPLSIT WHERE 
 TEMPLATE = 'zk55.RESPONS' AND NAME = '*Fatal';
DELETE FROM KFWTMPLSIT WHERE 
 TEMPLATE = 'zk55.RESPONS' AND NAME = '*Minor';
DELETE FROM KFWTMPLSIT WHERE 
 TEMPLATE = 'zk55.RESPONS' AND NAME = '*Harmless';
DELETE FROM KFWTMPLSIT WHERE 
 TEMPLATE = 'zk55.RESPONS' AND NAME = '*Unknown';
DELETE FROM KFWTMPLSTA WHERE 
 TEMPLATE = 'zk55.RESPONS' AND NAME = 'OK';
DELETE FROM KFWTMPLSTA WHERE 
 TEMPLATE = 'zk55.RESPONS' AND NAME = 'Critical';
DELETE FROM KFWTMPLSTA WHERE 
 TEMPLATE = 'zk55.RESPONS' AND NAME = 'Warning';
DELETE FROM KFWTMPLSTA WHERE 
 TEMPLATE = 'zk55.RESPONS' AND NAME = 'Informational';
DELETE FROM KFWTMPLSTA WHERE 
 TEMPLATE = 'zk55.RESPONS' AND NAME = 'Unavailable';
DELETE FROM KFWTMPLSTA WHERE 
 TEMPLATE = 'zk55.RESPONS' AND NAME = 'Fatal';
DELETE FROM KFWTMPLSTA WHERE 
 TEMPLATE = 'zk55.RESPONS' AND NAME = 'Minor';
DELETE FROM KFWTMPLSTA WHERE 
 TEMPLATE = 'zk55.RESPONS' AND NAME = 'Harmless';
DELETE FROM KFWTMPLSTA WHERE 
 TEMPLATE = 'zk55.RESPONS' AND NAME = 'Unknown';
DELETE FROM KFWTMPL WHERE NAME     =
 'zk55.RESPONS';


DELETE FROM KFWPARMA WHERE TABLENAME = 'K55.K55RESPONS';

*   Only Delete Statements generated
*


DELETE FROM KFWQUERY   WHERE ID       =
 'zk55.SUMMARY';
DELETE FROM KFWTMPLSIT WHERE 
 TEMPLATE = 'zk55.SUMMARY' AND NAME = '*Critical';
DELETE FROM KFWTMPLSIT WHERE 
 TEMPLATE = 'zk55.SUMMARY' AND NAME = '*Warning';
DELETE FROM KFWTMPLSIT WHERE 
 TEMPLATE = 'zk55.SUMMARY' AND NAME = '*Informational';
DELETE FROM KFWTMPLSIT WHERE 
 TEMPLATE = 'zk55.SUMMARY' AND NAME = '*STATUS_UNKNOWN';
DELETE FROM KFWTMPLSIT WHERE 
 TEMPLATE = 'zk55.SUMMARY' AND NAME = '*Fatal';
DELETE FROM KFWTMPLSIT WHERE 
 TEMPLATE = 'zk55.SUMMARY' AND NAME = '*Minor';
DELETE FROM KFWTMPLSIT WHERE 
 TEMPLATE = 'zk55.SUMMARY' AND NAME = '*Harmless';
DELETE FROM KFWTMPLSIT WHERE 
 TEMPLATE = 'zk55.SUMMARY' AND NAME = '*Unknown';
DELETE FROM KFWTMPLSTA WHERE 
 TEMPLATE = 'zk55.SUMMARY' AND NAME = 'OK';
DELETE FROM KFWTMPLSTA WHERE 
 TEMPLATE = 'zk55.SUMMARY' AND NAME = 'Critical';
DELETE FROM KFWTMPLSTA WHERE 
 TEMPLATE = 'zk55.SUMMARY' AND NAME = 'Warning';
DELETE FROM KFWTMPLSTA WHERE 
 TEMPLATE = 'zk55.SUMMARY' AND NAME = 'Informational';
DELETE FROM KFWTMPLSTA WHERE 
 TEMPLATE = 'zk55.SUMMARY' AND NAME = 'Unavailable';
DELETE FROM KFWTMPLSTA WHERE 
 TEMPLATE = 'zk55.SUMMARY' AND NAME = 'Fatal';
DELETE FROM KFWTMPLSTA WHERE 
 TEMPLATE = 'zk55.SUMMARY' AND NAME = 'Minor';
DELETE FROM KFWTMPLSTA WHERE 
 TEMPLATE = 'zk55.SUMMARY' AND NAME = 'Harmless';
DELETE FROM KFWTMPLSTA WHERE 
 TEMPLATE = 'zk55.SUMMARY' AND NAME = 'Unknown';
DELETE FROM KFWTMPL WHERE NAME     =
 'zk55.SUMMARY';


DELETE FROM KFWPARMA WHERE TABLENAME = 'K55.K55SUMMARY';

*   Only Delete Statements generated
*


DELETE FROM KFWQUERY   WHERE ID       =
 'zk55.RSP_obj_status';
DELETE FROM KFWTMPLSIT WHERE 
 TEMPLATE = 'zk55.RSP_obj_status' AND NAME = '*Critical';
DELETE FROM KFWTMPLSIT WHERE 
 TEMPLATE = 'zk55.RSP_obj_status' AND NAME = '*Warning';
DELETE FROM KFWTMPLSIT WHERE 
 TEMPLATE = 'zk55.RSP_obj_status' AND NAME = '*Informational';
DELETE FROM KFWTMPLSIT WHERE 
 TEMPLATE = 'zk55.RSP_obj_status' AND NAME = '*STATUS_UNKNOWN';
DELETE FROM KFWTMPLSIT WHERE 
 TEMPLATE = 'zk55.RSP_obj_status' AND NAME = '*Fatal';
DELETE FROM KFWTMPLSIT WHERE 
 TEMPLATE = 'zk55.RSP_obj_status' AND NAME = '*Minor';
DELETE FROM KFWTMPLSIT WHERE 
 TEMPLATE = 'zk55.RSP_obj_status' AND NAME = '*Harmless';
DELETE FROM KFWTMPLSIT WHERE 
 TEMPLATE = 'zk55.RSP_obj_status' AND NAME = '*Unknown';
DELETE FROM KFWTMPLSTA WHERE 
 TEMPLATE = 'zk55.RSP_obj_status' AND NAME = 'OK';
DELETE FROM KFWTMPLSTA WHERE 
 TEMPLATE = 'zk55.RSP_obj_status' AND NAME = 'Critical';
DELETE FROM KFWTMPLSTA WHERE 
 TEMPLATE = 'zk55.RSP_obj_status' AND NAME = 'Warning';
DELETE FROM KFWTMPLSTA WHERE 
 TEMPLATE = 'zk55.RSP_obj_status' AND NAME = 'Informational';
DELETE FROM KFWTMPLSTA WHERE 
 TEMPLATE = 'zk55.RSP_obj_status' AND NAME = 'Unavailable';
DELETE FROM KFWTMPLSTA WHERE 
 TEMPLATE = 'zk55.RSP_obj_status' AND NAME = 'Fatal';
DELETE FROM KFWTMPLSTA WHERE 
 TEMPLATE = 'zk55.RSP_obj_status' AND NAME = 'Minor';
DELETE FROM KFWTMPLSTA WHERE 
 TEMPLATE = 'zk55.RSP_obj_status' AND NAME = 'Harmless';
DELETE FROM KFWTMPLSTA WHERE 
 TEMPLATE = 'zk55.RSP_obj_status' AND NAME = 'Unknown';
DELETE FROM KFWTMPL WHERE NAME     =
 'zk55.RSP_obj_status';


DELETE FROM KFWPARMA WHERE TABLENAME = 'K55.K55RSPPOS';



DELETE FROM KFWQUERY   WHERE ID       =
 'zk55.RSPDS';
DELETE FROM KFWTMPLSIT WHERE 
 TEMPLATE = 'zk55.RSPDS' AND NAME = '*Critical';
DELETE FROM KFWTMPLSIT WHERE 
 TEMPLATE = 'zk55.RSPDS' AND NAME = '*Warning';
DELETE FROM KFWTMPLSIT WHERE 
 TEMPLATE = 'zk55.RSPDS' AND NAME = '*Informational';
DELETE FROM KFWTMPLSIT WHERE 
 TEMPLATE = 'zk55.RSPDS' AND NAME = '*STATUS_UNKNOWN';
DELETE FROM KFWTMPLSIT WHERE 
 TEMPLATE = 'zk55.RSPDS' AND NAME = '*Fatal';
DELETE FROM KFWTMPLSIT WHERE 
 TEMPLATE = 'zk55.RSPDS' AND NAME = '*Minor';
DELETE FROM KFWTMPLSIT WHERE 
 TEMPLATE = 'zk55.RSPDS' AND NAME = '*Harmless';
DELETE FROM KFWTMPLSIT WHERE 
 TEMPLATE = 'zk55.RSPDS' AND NAME = '*Unknown';
DELETE FROM KFWTMPLSTA WHERE 
 TEMPLATE = 'zk55.RSPDS' AND NAME = 'OK';
DELETE FROM KFWTMPLSTA WHERE 
 TEMPLATE = 'zk55.RSPDS' AND NAME = 'Critical';
DELETE FROM KFWTMPLSTA WHERE 
 TEMPLATE = 'zk55.RSPDS' AND NAME = 'Warning';
DELETE FROM KFWTMPLSTA WHERE 
 TEMPLATE = 'zk55.RSPDS' AND NAME = 'Informational';
DELETE FROM KFWTMPLSTA WHERE 
 TEMPLATE = 'zk55.RSPDS' AND NAME = 'Unavailable';
DELETE FROM KFWTMPLSTA WHERE 
 TEMPLATE = 'zk55.RSPDS' AND NAME = 'Fatal';
DELETE FROM KFWTMPLSTA WHERE 
 TEMPLATE = 'zk55.RSPDS' AND NAME = 'Minor';
DELETE FROM KFWTMPLSTA WHERE 
 TEMPLATE = 'zk55.RSPDS' AND NAME = 'Harmless';
DELETE FROM KFWTMPLSTA WHERE 
 TEMPLATE = 'zk55.RSPDS' AND NAME = 'Unknown';
DELETE FROM KFWTMPL WHERE NAME     =
 'zk55.RSPDS';


INSERT INTO KFWQUERY
( ID,
  APPL,
  AFFINITIES,
  PROD_PROV,
  NAME,
  TEXT,
  LASTUSER,
  MODIFIED,
  QUERY
)
  VALUES 
( 'zk55.RSPDS',
  'K55',
  '%IBM.K55                0000000001000000000',
  'D',
  'K55:K551002',
  'K55:K551003',
  'SYSADMIN',
  '1190312133908000',
'at=$THRUNODE$@table1.name=K55RSPDS@table1.column1.name=ORIGINNODE@table1.column2.name=TIMESTAMP@table1.column3.name=SN_MSN@table1.column4.name=SN_AFFIN@table1.column5.name=SN_TYPE@table1.column6.name=SN_RES@table1.column7.name=SN_VER@table1.columnCount=7@tableCount=1@filter1.connector=AND@filter1.column=ORIGINNODE@filter1.operator=EQ@filter1.value=$NODE$@filterCount=1@parma1.value="TIMEOUT","600",3@parmaCount=1@readonly=T@property1.name=-1021A@property1.value=kfw.TableRow@propertyCount=1@history=F@');


DELETE FROM KFWPARMA WHERE TABLENAME = 'K55.K55RSPDS';

INSERT INTO KFWPARMA ( TABLENAME, PARMA) VALUES ('K55.K55RSPDS',
'SYSTEM.PARMA("TIMEOUT","600",3)');


INSERT INTO KFWTMPL
(  AFFINITIES ,
   AREA ,
   ATTRIBS ,
   LSTDATE ,
   LSTUSRPRF ,
   NAME ,
   TEXT
)
VALUES
(  '%IBM.K55                0000000001000000000',
   32,
   259,
   '1190312133908000',
   '_ KCJ',
   'zk55.RSPDS',
   'K55:K551002'
);

INSERT INTO KFWTMPLSTA
(  TEMPLATE ,
   NAME ,
   SEVERITY ,
   ATTRIBS ,
   TEXT
)
VALUES
(  'zk55.RSPDS',
   'OK',
   -1,
   65795,
   'Normal and Available State'
);

INSERT INTO KFWTMPLSTA
(  TEMPLATE ,
   NAME ,
   SEVERITY ,
   ATTRIBS ,
   TEXT
)
VALUES
(  'zk55.RSPDS',
   'Critical',
   90,
   259,
   'Critical State'
);

INSERT INTO KFWTMPLSTA
(  TEMPLATE ,
   NAME ,
   SEVERITY ,
   ATTRIBS ,
   TEXT
)
VALUES
(  'zk55.RSPDS',
   'Warning',
   30,
   259,
   'Warning State'
);

INSERT INTO KFWTMPLSTA
(  TEMPLATE ,
   NAME ,
   SEVERITY ,
   ATTRIBS ,
   TEXT
)
VALUES
(  'zk55.RSPDS',
   'Informational',
   25,
   259,
   'Informational State'
);

INSERT INTO KFWTMPLSTA
(  TEMPLATE ,
   NAME ,
   SEVERITY ,
   ATTRIBS ,
   TEXT
)
VALUES
(  'zk55.RSPDS',
   'Unavailable',
   95,
   259,
   'Unavailable State'
);

INSERT INTO KFWTMPLSTA
(  TEMPLATE ,
   NAME ,
   SEVERITY ,
   ATTRIBS ,
   TEXT
)
VALUES
(  'zk55.RSPDS',
   'Fatal',
   100,
   259,
   'Fatal State'
);

INSERT INTO KFWTMPLSTA
(  TEMPLATE ,
   NAME ,
   SEVERITY ,
   ATTRIBS ,
   TEXT
)
VALUES
(  'zk55.RSPDS',
   'Minor',
   40,
   259,
   'Minor State'
);

INSERT INTO KFWTMPLSTA
(  TEMPLATE ,
   NAME ,
   SEVERITY ,
   ATTRIBS ,
   TEXT
)
VALUES
(  'zk55.RSPDS',
   'Harmless',
   27,
   259,
   'Harmless State'
);

INSERT INTO KFWTMPLSTA
(  TEMPLATE ,
   NAME ,
   SEVERITY ,
   ATTRIBS ,
   TEXT
)
VALUES
(  'zk55.RSPDS',
   'Unknown',
   15,
   259,
   'Unknown State'
);

INSERT INTO KFWTMPLSIT
(  NAME ,
   STATE ,
   TEMPLATE ,
   TYPE
)
VALUES
(  '*Critical',
   'Critical',
   'zk55.RSPDS',
   256
);

INSERT INTO KFWTMPLSIT
(  NAME ,
   STATE ,
   TEMPLATE ,
   TYPE
)
VALUES
(  '*Warning',
   'Warning',
   'zk55.RSPDS',
   256
);

INSERT INTO KFWTMPLSIT
(  NAME ,
   STATE ,
   TEMPLATE ,
   TYPE
)
VALUES
(  '*Informational',
   'Informational',
   'zk55.RSPDS',
   256
);

INSERT INTO KFWTMPLSIT
(  NAME ,
   STATE ,
   TEMPLATE ,
   TYPE
)
VALUES
(  '*STATUS_UNKNOWN',
   'Unavailable',
   'zk55.RSPDS',
   256
);

INSERT INTO KFWTMPLSIT
(  NAME ,
   STATE ,
   TEMPLATE ,
   TYPE
)
VALUES
(  '*Fatal',
   'Fatal',
   'zk55.RSPDS',
   256
);

INSERT INTO KFWTMPLSIT
(  NAME ,
   STATE ,
   TEMPLATE ,
   TYPE
)
VALUES
(  '*Minor',
   'Minor',
   'zk55.RSPDS',
   256
);

INSERT INTO KFWTMPLSIT
(  NAME ,
   STATE ,
   TEMPLATE ,
   TYPE
)
VALUES
(  '*Harmless',
   'Harmless',
   'zk55.RSPDS',
   256
);

INSERT INTO KFWTMPLSIT
(  NAME ,
   STATE ,
   TEMPLATE ,
   TYPE
)
VALUES
(  '*Unknown',
   'Unknown',
   'zk55.RSPDS',
   256
);



DELETE FROM KFWQUERY   WHERE ID       =
 'zk55.obj_status';
DELETE FROM KFWTMPLSIT WHERE 
 TEMPLATE = 'zk55.obj_status' AND NAME = '*Critical';
DELETE FROM KFWTMPLSIT WHERE 
 TEMPLATE = 'zk55.obj_status' AND NAME = '*Warning';
DELETE FROM KFWTMPLSIT WHERE 
 TEMPLATE = 'zk55.obj_status' AND NAME = '*Informational';
DELETE FROM KFWTMPLSIT WHERE 
 TEMPLATE = 'zk55.obj_status' AND NAME = '*STATUS_UNKNOWN';
DELETE FROM KFWTMPLSIT WHERE 
 TEMPLATE = 'zk55.obj_status' AND NAME = '*Fatal';
DELETE FROM KFWTMPLSIT WHERE 
 TEMPLATE = 'zk55.obj_status' AND NAME = '*Minor';
DELETE FROM KFWTMPLSIT WHERE 
 TEMPLATE = 'zk55.obj_status' AND NAME = '*Harmless';
DELETE FROM KFWTMPLSIT WHERE 
 TEMPLATE = 'zk55.obj_status' AND NAME = '*Unknown';
DELETE FROM KFWTMPLSTA WHERE 
 TEMPLATE = 'zk55.obj_status' AND NAME = 'OK';
DELETE FROM KFWTMPLSTA WHERE 
 TEMPLATE = 'zk55.obj_status' AND NAME = 'Critical';
DELETE FROM KFWTMPLSTA WHERE 
 TEMPLATE = 'zk55.obj_status' AND NAME = 'Warning';
DELETE FROM KFWTMPLSTA WHERE 
 TEMPLATE = 'zk55.obj_status' AND NAME = 'Informational';
DELETE FROM KFWTMPLSTA WHERE 
 TEMPLATE = 'zk55.obj_status' AND NAME = 'Unavailable';
DELETE FROM KFWTMPLSTA WHERE 
 TEMPLATE = 'zk55.obj_status' AND NAME = 'Fatal';
DELETE FROM KFWTMPLSTA WHERE 
 TEMPLATE = 'zk55.obj_status' AND NAME = 'Minor';
DELETE FROM KFWTMPLSTA WHERE 
 TEMPLATE = 'zk55.obj_status' AND NAME = 'Harmless';
DELETE FROM KFWTMPLSTA WHERE 
 TEMPLATE = 'zk55.obj_status' AND NAME = 'Unknown';
DELETE FROM KFWTMPL WHERE NAME     =
 'zk55.obj_status';


INSERT INTO KFWQUERY
( ID,
  APPL,
  AFFINITIES,
  PROD_PROV,
  NAME,
  TEXT,
  LASTUSER,
  MODIFIED,
  QUERY
)
  VALUES 
( 'zk55.obj_status',
  'K55',
  '%IBM.K55                0000000001000000000',
  'D',
  'K55:K551004',
  'K55:K551005',
  'SYSADMIN',
  '1190312133908000',
'at=$THRUNODE$@table1.name=K55POBJST@table1.column1.name=ORIGINNODE@table1.column2.name=TIMESTAMP@table1.column3.name=ATTRGRP@table1.column4.name=OBJNAME@table1.column5.name=OBJTYPE@table1.column6.name=OBJSTTS@table1.column7.name=ERRCODE@table1.column8.name=COLSTRT@table1.column9.name=COLFINI@table1.column10.name=COLDURA@table1.column11.name=COLAVGD@table1.column12.name=REFRINT@table1.column13.name=NUMCOLL@table1.column14.name=CACHEHT@table1.column15.name=CACHEMS@table1.column16.name=CACHPCT@table1.column17.name=INTSKIP@table1.columnCount=17@tableCount=1@filter1.connector=AND@filter1.column=ORIGINNODE@filter1.operator=EQ@filter1.value=$NODE$@filterCount=1@parma1.value="TIMEOUT","600",3@parmaCount=1@readonly=T@property1.name=-1021A@property1.value=kfw.TableRow@propertyCount=1@history=F@');


DELETE FROM KFWPARMA WHERE TABLENAME = 'K55.K55POBJST';

INSERT INTO KFWPARMA ( TABLENAME, PARMA) VALUES ('K55.K55POBJST',
'SYSTEM.PARMA("TIMEOUT","600",3)');


INSERT INTO KFWTMPL
(  AFFINITIES ,
   AREA ,
   ATTRIBS ,
   LSTDATE ,
   LSTUSRPRF ,
   NAME ,
   TEXT
)
VALUES
(  '%IBM.K55                0000000001000000000',
   32,
   259,
   '1190312133908000',
   '_ KCJ',
   'zk55.obj_status',
   'K55:K551004'
);

INSERT INTO KFWTMPLSTA
(  TEMPLATE ,
   NAME ,
   SEVERITY ,
   ATTRIBS ,
   TEXT
)
VALUES
(  'zk55.obj_status',
   'OK',
   -1,
   65795,
   'Normal and Available State'
);

INSERT INTO KFWTMPLSTA
(  TEMPLATE ,
   NAME ,
   SEVERITY ,
   ATTRIBS ,
   TEXT
)
VALUES
(  'zk55.obj_status',
   'Critical',
   90,
   259,
   'Critical State'
);

INSERT INTO KFWTMPLSTA
(  TEMPLATE ,
   NAME ,
   SEVERITY ,
   ATTRIBS ,
   TEXT
)
VALUES
(  'zk55.obj_status',
   'Warning',
   30,
   259,
   'Warning State'
);

INSERT INTO KFWTMPLSTA
(  TEMPLATE ,
   NAME ,
   SEVERITY ,
   ATTRIBS ,
   TEXT
)
VALUES
(  'zk55.obj_status',
   'Informational',
   25,
   259,
   'Informational State'
);

INSERT INTO KFWTMPLSTA
(  TEMPLATE ,
   NAME ,
   SEVERITY ,
   ATTRIBS ,
   TEXT
)
VALUES
(  'zk55.obj_status',
   'Unavailable',
   95,
   259,
   'Unavailable State'
);

INSERT INTO KFWTMPLSTA
(  TEMPLATE ,
   NAME ,
   SEVERITY ,
   ATTRIBS ,
   TEXT
)
VALUES
(  'zk55.obj_status',
   'Fatal',
   100,
   259,
   'Fatal State'
);

INSERT INTO KFWTMPLSTA
(  TEMPLATE ,
   NAME ,
   SEVERITY ,
   ATTRIBS ,
   TEXT
)
VALUES
(  'zk55.obj_status',
   'Minor',
   40,
   259,
   'Minor State'
);

INSERT INTO KFWTMPLSTA
(  TEMPLATE ,
   NAME ,
   SEVERITY ,
   ATTRIBS ,
   TEXT
)
VALUES
(  'zk55.obj_status',
   'Harmless',
   27,
   259,
   'Harmless State'
);

INSERT INTO KFWTMPLSTA
(  TEMPLATE ,
   NAME ,
   SEVERITY ,
   ATTRIBS ,
   TEXT
)
VALUES
(  'zk55.obj_status',
   'Unknown',
   15,
   259,
   'Unknown State'
);

INSERT INTO KFWTMPLSIT
(  NAME ,
   STATE ,
   TEMPLATE ,
   TYPE
)
VALUES
(  '*Critical',
   'Critical',
   'zk55.obj_status',
   256
);

INSERT INTO KFWTMPLSIT
(  NAME ,
   STATE ,
   TEMPLATE ,
   TYPE
)
VALUES
(  '*Warning',
   'Warning',
   'zk55.obj_status',
   256
);

INSERT INTO KFWTMPLSIT
(  NAME ,
   STATE ,
   TEMPLATE ,
   TYPE
)
VALUES
(  '*Informational',
   'Informational',
   'zk55.obj_status',
   256
);

INSERT INTO KFWTMPLSIT
(  NAME ,
   STATE ,
   TEMPLATE ,
   TYPE
)
VALUES
(  '*STATUS_UNKNOWN',
   'Unavailable',
   'zk55.obj_status',
   256
);

INSERT INTO KFWTMPLSIT
(  NAME ,
   STATE ,
   TEMPLATE ,
   TYPE
)
VALUES
(  '*Fatal',
   'Fatal',
   'zk55.obj_status',
   256
);

INSERT INTO KFWTMPLSIT
(  NAME ,
   STATE ,
   TEMPLATE ,
   TYPE
)
VALUES
(  '*Minor',
   'Minor',
   'zk55.obj_status',
   256
);

INSERT INTO KFWTMPLSIT
(  NAME ,
   STATE ,
   TEMPLATE ,
   TYPE
)
VALUES
(  '*Harmless',
   'Harmless',
   'zk55.obj_status',
   256
);

INSERT INTO KFWTMPLSIT
(  NAME ,
   STATE ,
   TEMPLATE ,
   TYPE
)
VALUES
(  '*Unknown',
   'Unknown',
   'zk55.obj_status',
   256
);



DELETE FROM KFWQUERY   WHERE ID       =
 'zk55.tpl_status';


INSERT INTO KFWQUERY
( ID,
  APPL,
  AFFINITIES,
  PROD_PROV,
  NAME,
  TEXT,
  LASTUSER,
  MODIFIED,
  QUERY
)
  VALUES 
( 'zk55.tpl_status',
  'K55',
  '%IBM.K55                0000000001000000000',
  'P',
  'K55:K551006',
  'K55:K551007',
  'SYSADMIN',
  '1190312133908000',
'at=$THRUNODE$@table1.name=K55THPLST@table1.column1.name=ORIGINNODE@table1.column2.name=TIMESTAMP@table1.column3.name=THPSIZE@table1.column4.name=TPMAXSZ@table1.column5.name=TPACTTH@table1.column6.name=TPAVGAT@table1.column7.name=TPMINAT@table1.column8.name=TPMAXAT@table1.column9.name=TPQLGTH@table1.column10.name=TPAVGQL@table1.column11.name=TPMINQL@table1.column12.name=TPMAXQL@table1.column13.name=TPAVJBW@table1.column14.name=TPTJOBS@table1.columnCount=14@tableCount=1@filter1.connector=AND@filter1.column=ORIGINNODE@filter1.operator=EQ@filter1.value=$NODE$@filterCount=1@parma1.value="TIMEOUT","600",3@parmaCount=1@readonly=T@property1.name=-1021A@property1.value=kfw.TableRow@propertyCount=1@history=F@');


DELETE FROM KFWPARMA WHERE TABLENAME = 'K55.K55THPLST';

INSERT INTO KFWPARMA ( TABLENAME, PARMA) VALUES ('K55.K55THPLST',
'SYSTEM.PARMA("TIMEOUT","600",3)');




DELETE FROM KFWQUERY   WHERE ID       =
 'zk55.rgx_status';


INSERT INTO KFWQUERY
( ID,
  APPL,
  AFFINITIES,
  PROD_PROV,
  NAME,
  TEXT,
  LASTUSER,
  MODIFIED,
  QUERY
)
  VALUES 
( 'zk55.rgx_status',
  'K55',
  '%IBM.K55                0000000001000000000',
  'P',
  'K55:K551008',
  'K55:K551009',
  'SYSADMIN',
  '1190312133908000',
'at=$THRUNODE$@table1.name=K55LOGFRX@table1.column1.name=ORIGINNODE@table1.column2.name=TIMESTAMP@table1.column3.name=TBLNAME@table1.column4.name=ATRNAME@table1.column5.name=FLTRNUM@table1.column6.name=CPUTAVG@table1.column7.name=CPUTIME@table1.column8.name=CPUTMAX@table1.column9.name=CPUTMIN@table1.column10.name=COUNT@table1.column11.name=COUNTMA@table1.column12.name=COUNTUN@table1.column13.name=REGXPAT@table1.column14.name=LASTMAT@table1.column15.name=LASTUMA@table1.column16.name=RSTTYPE@table1.columnCount=16@tableCount=1@filter1.connector=AND@filter1.column=ORIGINNODE@filter1.operator=EQ@filter1.value=$NODE$@filterCount=1@parma1.value="TIMEOUT","600",3@parmaCount=1@readonly=T@property1.name=-1021A@property1.value=kfw.TableRow@propertyCount=1@history=F@');


DELETE FROM KFWPARMA WHERE TABLENAME = 'K55.K55LOGFRX';

INSERT INTO KFWPARMA ( TABLENAME, PARMA) VALUES ('K55.K55LOGFRX',
'SYSTEM.PARMA("TIMEOUT","600",3)');




DELETE FROM KFWQUERY   WHERE ID       =
 'zk55.log_status';


INSERT INTO KFWQUERY
( ID,
  APPL,
  AFFINITIES,
  PROD_PROV,
  NAME,
  TEXT,
  LASTUSER,
  MODIFIED,
  QUERY
)
  VALUES 
( 'zk55.log_status',
  'K55',
  '%IBM.K55                0000000001000000000',
  'P',
  'K55:K551010',
  'K55:K551011',
  'SYSADMIN',
  '1190312133908000',
'at=$THRUNODE$@table1.name=K55LOGFST@table1.column1.name=ORIGINNODE@table1.column2.name=TIMESTAMP@table1.column3.name=TBLNAME@table1.column4.name=FILNAME@table1.column5.name=REPATRN@table1.column6.name=FILTYPE@table1.column7.name=FILSTAT@table1.column8.name=RECMTCH@table1.column9.name=RECUNMT@table1.column10.name=RECPROC@table1.column11.name=OFFSET@table1.column12.name=FILSIZE@table1.column13.name=LASTMOD@table1.column14.name=CODEPG@table1.column15.name=REMHOST@table1.columnCount=15@tableCount=1@filter1.connector=AND@filter1.column=ORIGINNODE@filter1.operator=EQ@filter1.value=$NODE$@filterCount=1@parma1.value="TIMEOUT","600",3@parmaCount=1@readonly=T@property1.name=-1021A@property1.value=kfw.TableRow@propertyCount=1@history=F@');


DELETE FROM KFWPARMA WHERE TABLENAME = 'K55.K55LOGFST';

INSERT INTO KFWPARMA ( TABLENAME, PARMA) VALUES ('K55.K55LOGFST',
'SYSTEM.PARMA("TIMEOUT","600",3)');




DELETE FROM KFWQUERY   WHERE ID       =
 'zk55.tac_status';


INSERT INTO KFWQUERY
( ID,
  APPL,
  AFFINITIES,
  PROD_PROV,
  NAME,
  TEXT,
  LASTUSER,
  MODIFIED,
  QUERY
)
  VALUES 
( 'zk55.tac_status',
  'K55',
  '%IBM.K55                0000000001000000000',
  'P',
  'K55:K551012',
  'K55:K551013',
  'SYSADMIN',
  '1190312133908000',
'at=$THRUNODE$@table1.name=K55TACTST@table1.column1.name=ORIGINNODE@table1.column2.name=TIMESTAMP@table1.column3.name=TSKNAME@table1.column4.name=TSKSTAT@table1.column5.name=TSKAPRC@table1.column6.name=TSKMSGE@table1.column7.name=TSKINST@table1.column8.name=TSKOUTP@table1.column9.name=TSKCMND@table1.column10.name=TSKORGN@table1.column11.name=TSKSBND@table1.column12.name=TSKID@table1.column13.name=TSKTYPE@table1.column14.name=TSKOWNR@table1.columnCount=14@tableCount=1@filter1.connector=AND@filter1.column=ORIGINNODE@filter1.operator=EQ@filter1.value=$NODE$@filterCount=1@parma1.value="TIMEOUT","600",3@parmaCount=1@readonly=T@property1.name=-1021A@property1.value=kfw.TableRow@propertyCount=1@history=F@');


DELETE FROM KFWPARMA WHERE TABLENAME = 'K55.K55TACTST';

INSERT INTO KFWPARMA ( TABLENAME, PARMA) VALUES ('K55.K55TACTST',
'SYSTEM.PARMA("TIMEOUT","600",3)');




DELETE FROM KFWQUERY   WHERE ID       =
 'zk55.RESPONS';
DELETE FROM KFWTMPLSIT WHERE 
 TEMPLATE = 'zk55.RESPONS' AND NAME = '*Critical';
DELETE FROM KFWTMPLSIT WHERE 
 TEMPLATE = 'zk55.RESPONS' AND NAME = '*Warning';
DELETE FROM KFWTMPLSIT WHERE 
 TEMPLATE = 'zk55.RESPONS' AND NAME = '*Informational';
DELETE FROM KFWTMPLSIT WHERE 
 TEMPLATE = 'zk55.RESPONS' AND NAME = '*STATUS_UNKNOWN';
DELETE FROM KFWTMPLSIT WHERE 
 TEMPLATE = 'zk55.RESPONS' AND NAME = '*Fatal';
DELETE FROM KFWTMPLSIT WHERE 
 TEMPLATE = 'zk55.RESPONS' AND NAME = '*Minor';
DELETE FROM KFWTMPLSIT WHERE 
 TEMPLATE = 'zk55.RESPONS' AND NAME = '*Harmless';
DELETE FROM KFWTMPLSIT WHERE 
 TEMPLATE = 'zk55.RESPONS' AND NAME = '*Unknown';
DELETE FROM KFWTMPLSTA WHERE 
 TEMPLATE = 'zk55.RESPONS' AND NAME = 'OK';
DELETE FROM KFWTMPLSTA WHERE 
 TEMPLATE = 'zk55.RESPONS' AND NAME = 'Critical';
DELETE FROM KFWTMPLSTA WHERE 
 TEMPLATE = 'zk55.RESPONS' AND NAME = 'Warning';
DELETE FROM KFWTMPLSTA WHERE 
 TEMPLATE = 'zk55.RESPONS' AND NAME = 'Informational';
DELETE FROM KFWTMPLSTA WHERE 
 TEMPLATE = 'zk55.RESPONS' AND NAME = 'Unavailable';
DELETE FROM KFWTMPLSTA WHERE 
 TEMPLATE = 'zk55.RESPONS' AND NAME = 'Fatal';
DELETE FROM KFWTMPLSTA WHERE 
 TEMPLATE = 'zk55.RESPONS' AND NAME = 'Minor';
DELETE FROM KFWTMPLSTA WHERE 
 TEMPLATE = 'zk55.RESPONS' AND NAME = 'Harmless';
DELETE FROM KFWTMPLSTA WHERE 
 TEMPLATE = 'zk55.RESPONS' AND NAME = 'Unknown';
DELETE FROM KFWTMPL WHERE NAME     =
 'zk55.RESPONS';


INSERT INTO KFWQUERY
( ID,
  APPL,
  AFFINITIES,
  PROD_PROV,
  NAME,
  TEXT,
  LASTUSER,
  MODIFIED,
  QUERY
)
  VALUES 
( 'zk55.RESPONS',
  'K55',
  '%IBM.K55RSP             0000000001000000000',
  'D',
  'K55:K551001',
  'K55:K551014',
  'SYSADMIN',
  '1190312133908000',
'at=$THRUNODE$@table1.name=K55RESPONS@table1.column1.name=ORIGINNODE@table1.column2.name=TIMESTAMP@table1.column3.name=MANAGEDSYS@table1.column4.name=PRODUCTCOD@table1.column5.name=STATUSB@table1.column6.name=RESPONSEST@table1.column7.name=STATUSA@table1.column8.name=MANAGINGSY@table1.column9.name=HOSTNAME@table1.columnCount=9@tableCount=1@filter1.connector=AND@filter1.column=ORIGINNODE@filter1.operator=EQ@filter1.value=$NODE$@filterCount=1@parma1.value="TIMEOUT","600",3@parmaCount=1@readonly=T@property1.name=-1021A@property1.value=kfw.TableRow@propertyCount=1@history=F@');


DELETE FROM KFWPARMA WHERE TABLENAME = 'K55.K55RESPONS';

INSERT INTO KFWPARMA ( TABLENAME, PARMA) VALUES ('K55.K55RESPONS',
'SYSTEM.PARMA("TIMEOUT","600",3)');


INSERT INTO KFWTMPL
(  AFFINITIES ,
   AREA ,
   ATTRIBS ,
   LSTDATE ,
   LSTUSRPRF ,
   NAME ,
   TEXT
)
VALUES
(  '%IBM.K55RSP             0000000001000000000',
   32,
   259,
   '1190312133908000',
   '_ KCJ',
   'zk55.RESPONS',
   'K55:K551001'
);

INSERT INTO KFWTMPLSTA
(  TEMPLATE ,
   NAME ,
   SEVERITY ,
   ATTRIBS ,
   TEXT
)
VALUES
(  'zk55.RESPONS',
   'OK',
   -1,
   65795,
   'Normal and Available State'
);

INSERT INTO KFWTMPLSTA
(  TEMPLATE ,
   NAME ,
   SEVERITY ,
   ATTRIBS ,
   TEXT
)
VALUES
(  'zk55.RESPONS',
   'Critical',
   90,
   259,
   'Critical State'
);

INSERT INTO KFWTMPLSTA
(  TEMPLATE ,
   NAME ,
   SEVERITY ,
   ATTRIBS ,
   TEXT
)
VALUES
(  'zk55.RESPONS',
   'Warning',
   30,
   259,
   'Warning State'
);

INSERT INTO KFWTMPLSTA
(  TEMPLATE ,
   NAME ,
   SEVERITY ,
   ATTRIBS ,
   TEXT
)
VALUES
(  'zk55.RESPONS',
   'Informational',
   25,
   259,
   'Informational State'
);

INSERT INTO KFWTMPLSTA
(  TEMPLATE ,
   NAME ,
   SEVERITY ,
   ATTRIBS ,
   TEXT
)
VALUES
(  'zk55.RESPONS',
   'Unavailable',
   95,
   259,
   'Unavailable State'
);

INSERT INTO KFWTMPLSTA
(  TEMPLATE ,
   NAME ,
   SEVERITY ,
   ATTRIBS ,
   TEXT
)
VALUES
(  'zk55.RESPONS',
   'Fatal',
   100,
   259,
   'Fatal State'
);

INSERT INTO KFWTMPLSTA
(  TEMPLATE ,
   NAME ,
   SEVERITY ,
   ATTRIBS ,
   TEXT
)
VALUES
(  'zk55.RESPONS',
   'Minor',
   40,
   259,
   'Minor State'
);

INSERT INTO KFWTMPLSTA
(  TEMPLATE ,
   NAME ,
   SEVERITY ,
   ATTRIBS ,
   TEXT
)
VALUES
(  'zk55.RESPONS',
   'Harmless',
   27,
   259,
   'Harmless State'
);

INSERT INTO KFWTMPLSTA
(  TEMPLATE ,
   NAME ,
   SEVERITY ,
   ATTRIBS ,
   TEXT
)
VALUES
(  'zk55.RESPONS',
   'Unknown',
   15,
   259,
   'Unknown State'
);

INSERT INTO KFWTMPLSIT
(  NAME ,
   STATE ,
   TEMPLATE ,
   TYPE
)
VALUES
(  '*Critical',
   'Critical',
   'zk55.RESPONS',
   256
);

INSERT INTO KFWTMPLSIT
(  NAME ,
   STATE ,
   TEMPLATE ,
   TYPE
)
VALUES
(  '*Warning',
   'Warning',
   'zk55.RESPONS',
   256
);

INSERT INTO KFWTMPLSIT
(  NAME ,
   STATE ,
   TEMPLATE ,
   TYPE
)
VALUES
(  '*Informational',
   'Informational',
   'zk55.RESPONS',
   256
);

INSERT INTO KFWTMPLSIT
(  NAME ,
   STATE ,
   TEMPLATE ,
   TYPE
)
VALUES
(  '*STATUS_UNKNOWN',
   'Unavailable',
   'zk55.RESPONS',
   256
);

INSERT INTO KFWTMPLSIT
(  NAME ,
   STATE ,
   TEMPLATE ,
   TYPE
)
VALUES
(  '*Fatal',
   'Fatal',
   'zk55.RESPONS',
   256
);

INSERT INTO KFWTMPLSIT
(  NAME ,
   STATE ,
   TEMPLATE ,
   TYPE
)
VALUES
(  '*Minor',
   'Minor',
   'zk55.RESPONS',
   256
);

INSERT INTO KFWTMPLSIT
(  NAME ,
   STATE ,
   TEMPLATE ,
   TYPE
)
VALUES
(  '*Harmless',
   'Harmless',
   'zk55.RESPONS',
   256
);

INSERT INTO KFWTMPLSIT
(  NAME ,
   STATE ,
   TEMPLATE ,
   TYPE
)
VALUES
(  '*Unknown',
   'Unknown',
   'zk55.RESPONS',
   256
);



DELETE FROM KFWQUERY   WHERE ID       =
 'zk55.SUMMARY';
DELETE FROM KFWTMPLSIT WHERE 
 TEMPLATE = 'zk55.SUMMARY' AND NAME = '*Critical';
DELETE FROM KFWTMPLSIT WHERE 
 TEMPLATE = 'zk55.SUMMARY' AND NAME = '*Warning';
DELETE FROM KFWTMPLSIT WHERE 
 TEMPLATE = 'zk55.SUMMARY' AND NAME = '*Informational';
DELETE FROM KFWTMPLSIT WHERE 
 TEMPLATE = 'zk55.SUMMARY' AND NAME = '*STATUS_UNKNOWN';
DELETE FROM KFWTMPLSIT WHERE 
 TEMPLATE = 'zk55.SUMMARY' AND NAME = '*Fatal';
DELETE FROM KFWTMPLSIT WHERE 
 TEMPLATE = 'zk55.SUMMARY' AND NAME = '*Minor';
DELETE FROM KFWTMPLSIT WHERE 
 TEMPLATE = 'zk55.SUMMARY' AND NAME = '*Harmless';
DELETE FROM KFWTMPLSIT WHERE 
 TEMPLATE = 'zk55.SUMMARY' AND NAME = '*Unknown';
DELETE FROM KFWTMPLSTA WHERE 
 TEMPLATE = 'zk55.SUMMARY' AND NAME = 'OK';
DELETE FROM KFWTMPLSTA WHERE 
 TEMPLATE = 'zk55.SUMMARY' AND NAME = 'Critical';
DELETE FROM KFWTMPLSTA WHERE 
 TEMPLATE = 'zk55.SUMMARY' AND NAME = 'Warning';
DELETE FROM KFWTMPLSTA WHERE 
 TEMPLATE = 'zk55.SUMMARY' AND NAME = 'Informational';
DELETE FROM KFWTMPLSTA WHERE 
 TEMPLATE = 'zk55.SUMMARY' AND NAME = 'Unavailable';
DELETE FROM KFWTMPLSTA WHERE 
 TEMPLATE = 'zk55.SUMMARY' AND NAME = 'Fatal';
DELETE FROM KFWTMPLSTA WHERE 
 TEMPLATE = 'zk55.SUMMARY' AND NAME = 'Minor';
DELETE FROM KFWTMPLSTA WHERE 
 TEMPLATE = 'zk55.SUMMARY' AND NAME = 'Harmless';
DELETE FROM KFWTMPLSTA WHERE 
 TEMPLATE = 'zk55.SUMMARY' AND NAME = 'Unknown';
DELETE FROM KFWTMPL WHERE NAME     =
 'zk55.SUMMARY';


INSERT INTO KFWQUERY
( ID,
  APPL,
  AFFINITIES,
  PROD_PROV,
  NAME,
  TEXT,
  LASTUSER,
  MODIFIED,
  QUERY
)
  VALUES 
( 'zk55.SUMMARY',
  'K55',
  '%IBM.K55RSP             0000000001000000000',
  'D',
  'K55:K551015',
  'K55:K551016',
  'SYSADMIN',
  '1190312133908000',
'at=$THRUNODE$@table1.name=K55SUMMARY@table1.column1.name=ORIGINNODE@table1.column2.name=TIMESTAMP@table1.column3.name=TEMSNODE0@table1.column4.name=NOTRESPONS@table1.column5.name=OFFLINE@table1.column6.name=RESPONSIVE@table1.columnCount=6@tableCount=1@filter1.connector=AND@filter1.column=ORIGINNODE@filter1.operator=EQ@filter1.value=$NODE$@filterCount=1@parma1.value="TIMEOUT","600",3@parmaCount=1@readonly=T@property1.name=-1021A@property1.value=kfw.TableRow@propertyCount=1@history=F@');


DELETE FROM KFWPARMA WHERE TABLENAME = 'K55.K55SUMMARY';

INSERT INTO KFWPARMA ( TABLENAME, PARMA) VALUES ('K55.K55SUMMARY',
'SYSTEM.PARMA("TIMEOUT","600",3)');


INSERT INTO KFWTMPL
(  AFFINITIES ,
   AREA ,
   ATTRIBS ,
   LSTDATE ,
   LSTUSRPRF ,
   NAME ,
   TEXT
)
VALUES
(  '%IBM.K55RSP             0000000001000000000',
   32,
   259,
   '1190312133908000',
   '_ KCJ',
   'zk55.SUMMARY',
   'K55:K551015'
);

INSERT INTO KFWTMPLSTA
(  TEMPLATE ,
   NAME ,
   SEVERITY ,
   ATTRIBS ,
   TEXT
)
VALUES
(  'zk55.SUMMARY',
   'OK',
   -1,
   65795,
   'Normal and Available State'
);

INSERT INTO KFWTMPLSTA
(  TEMPLATE ,
   NAME ,
   SEVERITY ,
   ATTRIBS ,
   TEXT
)
VALUES
(  'zk55.SUMMARY',
   'Critical',
   90,
   259,
   'Critical State'
);

INSERT INTO KFWTMPLSTA
(  TEMPLATE ,
   NAME ,
   SEVERITY ,
   ATTRIBS ,
   TEXT
)
VALUES
(  'zk55.SUMMARY',
   'Warning',
   30,
   259,
   'Warning State'
);

INSERT INTO KFWTMPLSTA
(  TEMPLATE ,
   NAME ,
   SEVERITY ,
   ATTRIBS ,
   TEXT
)
VALUES
(  'zk55.SUMMARY',
   'Informational',
   25,
   259,
   'Informational State'
);

INSERT INTO KFWTMPLSTA
(  TEMPLATE ,
   NAME ,
   SEVERITY ,
   ATTRIBS ,
   TEXT
)
VALUES
(  'zk55.SUMMARY',
   'Unavailable',
   95,
   259,
   'Unavailable State'
);

INSERT INTO KFWTMPLSTA
(  TEMPLATE ,
   NAME ,
   SEVERITY ,
   ATTRIBS ,
   TEXT
)
VALUES
(  'zk55.SUMMARY',
   'Fatal',
   100,
   259,
   'Fatal State'
);

INSERT INTO KFWTMPLSTA
(  TEMPLATE ,
   NAME ,
   SEVERITY ,
   ATTRIBS ,
   TEXT
)
VALUES
(  'zk55.SUMMARY',
   'Minor',
   40,
   259,
   'Minor State'
);

INSERT INTO KFWTMPLSTA
(  TEMPLATE ,
   NAME ,
   SEVERITY ,
   ATTRIBS ,
   TEXT
)
VALUES
(  'zk55.SUMMARY',
   'Harmless',
   27,
   259,
   'Harmless State'
);

INSERT INTO KFWTMPLSTA
(  TEMPLATE ,
   NAME ,
   SEVERITY ,
   ATTRIBS ,
   TEXT
)
VALUES
(  'zk55.SUMMARY',
   'Unknown',
   15,
   259,
   'Unknown State'
);

INSERT INTO KFWTMPLSIT
(  NAME ,
   STATE ,
   TEMPLATE ,
   TYPE
)
VALUES
(  '*Critical',
   'Critical',
   'zk55.SUMMARY',
   256
);

INSERT INTO KFWTMPLSIT
(  NAME ,
   STATE ,
   TEMPLATE ,
   TYPE
)
VALUES
(  '*Warning',
   'Warning',
   'zk55.SUMMARY',
   256
);

INSERT INTO KFWTMPLSIT
(  NAME ,
   STATE ,
   TEMPLATE ,
   TYPE
)
VALUES
(  '*Informational',
   'Informational',
   'zk55.SUMMARY',
   256
);

INSERT INTO KFWTMPLSIT
(  NAME ,
   STATE ,
   TEMPLATE ,
   TYPE
)
VALUES
(  '*STATUS_UNKNOWN',
   'Unavailable',
   'zk55.SUMMARY',
   256
);

INSERT INTO KFWTMPLSIT
(  NAME ,
   STATE ,
   TEMPLATE ,
   TYPE
)
VALUES
(  '*Fatal',
   'Fatal',
   'zk55.SUMMARY',
   256
);

INSERT INTO KFWTMPLSIT
(  NAME ,
   STATE ,
   TEMPLATE ,
   TYPE
)
VALUES
(  '*Minor',
   'Minor',
   'zk55.SUMMARY',
   256
);

INSERT INTO KFWTMPLSIT
(  NAME ,
   STATE ,
   TEMPLATE ,
   TYPE
)
VALUES
(  '*Harmless',
   'Harmless',
   'zk55.SUMMARY',
   256
);

INSERT INTO KFWTMPLSIT
(  NAME ,
   STATE ,
   TEMPLATE ,
   TYPE
)
VALUES
(  '*Unknown',
   'Unknown',
   'zk55.SUMMARY',
   256
);



DELETE FROM KFWQUERY   WHERE ID       =
 'zk55.RSP_obj_status';
DELETE FROM KFWTMPLSIT WHERE 
 TEMPLATE = 'zk55.RSP_obj_status' AND NAME = '*Critical';
DELETE FROM KFWTMPLSIT WHERE 
 TEMPLATE = 'zk55.RSP_obj_status' AND NAME = '*Warning';
DELETE FROM KFWTMPLSIT WHERE 
 TEMPLATE = 'zk55.RSP_obj_status' AND NAME = '*Informational';
DELETE FROM KFWTMPLSIT WHERE 
 TEMPLATE = 'zk55.RSP_obj_status' AND NAME = '*STATUS_UNKNOWN';
DELETE FROM KFWTMPLSIT WHERE 
 TEMPLATE = 'zk55.RSP_obj_status' AND NAME = '*Fatal';
DELETE FROM KFWTMPLSIT WHERE 
 TEMPLATE = 'zk55.RSP_obj_status' AND NAME = '*Minor';
DELETE FROM KFWTMPLSIT WHERE 
 TEMPLATE = 'zk55.RSP_obj_status' AND NAME = '*Harmless';
DELETE FROM KFWTMPLSIT WHERE 
 TEMPLATE = 'zk55.RSP_obj_status' AND NAME = '*Unknown';
DELETE FROM KFWTMPLSTA WHERE 
 TEMPLATE = 'zk55.RSP_obj_status' AND NAME = 'OK';
DELETE FROM KFWTMPLSTA WHERE 
 TEMPLATE = 'zk55.RSP_obj_status' AND NAME = 'Critical';
DELETE FROM KFWTMPLSTA WHERE 
 TEMPLATE = 'zk55.RSP_obj_status' AND NAME = 'Warning';
DELETE FROM KFWTMPLSTA WHERE 
 TEMPLATE = 'zk55.RSP_obj_status' AND NAME = 'Informational';
DELETE FROM KFWTMPLSTA WHERE 
 TEMPLATE = 'zk55.RSP_obj_status' AND NAME = 'Unavailable';
DELETE FROM KFWTMPLSTA WHERE 
 TEMPLATE = 'zk55.RSP_obj_status' AND NAME = 'Fatal';
DELETE FROM KFWTMPLSTA WHERE 
 TEMPLATE = 'zk55.RSP_obj_status' AND NAME = 'Minor';
DELETE FROM KFWTMPLSTA WHERE 
 TEMPLATE = 'zk55.RSP_obj_status' AND NAME = 'Harmless';
DELETE FROM KFWTMPLSTA WHERE 
 TEMPLATE = 'zk55.RSP_obj_status' AND NAME = 'Unknown';
DELETE FROM KFWTMPL WHERE NAME     =
 'zk55.RSP_obj_status';


INSERT INTO KFWQUERY
( ID,
  APPL,
  AFFINITIES,
  PROD_PROV,
  NAME,
  TEXT,
  LASTUSER,
  MODIFIED,
  QUERY
)
  VALUES 
( 'zk55.RSP_obj_status',
  'K55',
  '%IBM.K55RSP             0000000001000000000',
  'D',
  'K55:K551017',
  'K55:K551005',
  'SYSADMIN',
  '1190312133908000',
'at=$THRUNODE$@table1.name=K55RSPPOS@table1.column1.name=ORIGINNODE@table1.column2.name=TIMESTAMP@table1.column3.name=ATTRGRP@table1.column4.name=OBJNAME@table1.column5.name=OBJTYPE@table1.column6.name=OBJSTTS@table1.column7.name=ERRCODE@table1.column8.name=COLSTRT@table1.column9.name=COLFINI@table1.column10.name=COLDURA@table1.column11.name=COLAVGD@table1.column12.name=REFRINT@table1.column13.name=NUMCOLL@table1.column14.name=CACHEHT@table1.column15.name=CACHEMS@table1.column16.name=CACHPCT@table1.column17.name=INTSKIP@table1.columnCount=17@tableCount=1@filter1.connector=AND@filter1.column=ORIGINNODE@filter1.operator=EQ@filter1.value=$NODE$@filterCount=1@parma1.value="TIMEOUT","600",3@parmaCount=1@readonly=T@property1.name=-1021A@property1.value=kfw.TableRow@propertyCount=1@history=F@');


DELETE FROM KFWPARMA WHERE TABLENAME = 'K55.K55RSPPOS';

INSERT INTO KFWPARMA ( TABLENAME, PARMA) VALUES ('K55.K55RSPPOS',
'SYSTEM.PARMA("TIMEOUT","600",3)');


INSERT INTO KFWTMPL
(  AFFINITIES ,
   AREA ,
   ATTRIBS ,
   LSTDATE ,
   LSTUSRPRF ,
   NAME ,
   TEXT
)
VALUES
(  '%IBM.K55RSP             0000000001000000000',
   32,
   259,
   '1190312133908000',
   '_ KCJ',
   'zk55.RSP_obj_status',
   'K55:K551017'
);

INSERT INTO KFWTMPLSTA
(  TEMPLATE ,
   NAME ,
   SEVERITY ,
   ATTRIBS ,
   TEXT
)
VALUES
(  'zk55.RSP_obj_status',
   'OK',
   -1,
   65795,
   'Normal and Available State'
);

INSERT INTO KFWTMPLSTA
(  TEMPLATE ,
   NAME ,
   SEVERITY ,
   ATTRIBS ,
   TEXT
)
VALUES
(  'zk55.RSP_obj_status',
   'Critical',
   90,
   259,
   'Critical State'
);

INSERT INTO KFWTMPLSTA
(  TEMPLATE ,
   NAME ,
   SEVERITY ,
   ATTRIBS ,
   TEXT
)
VALUES
(  'zk55.RSP_obj_status',
   'Warning',
   30,
   259,
   'Warning State'
);

INSERT INTO KFWTMPLSTA
(  TEMPLATE ,
   NAME ,
   SEVERITY ,
   ATTRIBS ,
   TEXT
)
VALUES
(  'zk55.RSP_obj_status',
   'Informational',
   25,
   259,
   'Informational State'
);

INSERT INTO KFWTMPLSTA
(  TEMPLATE ,
   NAME ,
   SEVERITY ,
   ATTRIBS ,
   TEXT
)
VALUES
(  'zk55.RSP_obj_status',
   'Unavailable',
   95,
   259,
   'Unavailable State'
);

INSERT INTO KFWTMPLSTA
(  TEMPLATE ,
   NAME ,
   SEVERITY ,
   ATTRIBS ,
   TEXT
)
VALUES
(  'zk55.RSP_obj_status',
   'Fatal',
   100,
   259,
   'Fatal State'
);

INSERT INTO KFWTMPLSTA
(  TEMPLATE ,
   NAME ,
   SEVERITY ,
   ATTRIBS ,
   TEXT
)
VALUES
(  'zk55.RSP_obj_status',
   'Minor',
   40,
   259,
   'Minor State'
);

INSERT INTO KFWTMPLSTA
(  TEMPLATE ,
   NAME ,
   SEVERITY ,
   ATTRIBS ,
   TEXT
)
VALUES
(  'zk55.RSP_obj_status',
   'Harmless',
   27,
   259,
   'Harmless State'
);

INSERT INTO KFWTMPLSTA
(  TEMPLATE ,
   NAME ,
   SEVERITY ,
   ATTRIBS ,
   TEXT
)
VALUES
(  'zk55.RSP_obj_status',
   'Unknown',
   15,
   259,
   'Unknown State'
);

INSERT INTO KFWTMPLSIT
(  NAME ,
   STATE ,
   TEMPLATE ,
   TYPE
)
VALUES
(  '*Critical',
   'Critical',
   'zk55.RSP_obj_status',
   256
);

INSERT INTO KFWTMPLSIT
(  NAME ,
   STATE ,
   TEMPLATE ,
   TYPE
)
VALUES
(  '*Warning',
   'Warning',
   'zk55.RSP_obj_status',
   256
);

INSERT INTO KFWTMPLSIT
(  NAME ,
   STATE ,
   TEMPLATE ,
   TYPE
)
VALUES
(  '*Informational',
   'Informational',
   'zk55.RSP_obj_status',
   256
);

INSERT INTO KFWTMPLSIT
(  NAME ,
   STATE ,
   TEMPLATE ,
   TYPE
)
VALUES
(  '*STATUS_UNKNOWN',
   'Unavailable',
   'zk55.RSP_obj_status',
   256
);

INSERT INTO KFWTMPLSIT
(  NAME ,
   STATE ,
   TEMPLATE ,
   TYPE
)
VALUES
(  '*Fatal',
   'Fatal',
   'zk55.RSP_obj_status',
   256
);

INSERT INTO KFWTMPLSIT
(  NAME ,
   STATE ,
   TEMPLATE ,
   TYPE
)
VALUES
(  '*Minor',
   'Minor',
   'zk55.RSP_obj_status',
   256
);

INSERT INTO KFWTMPLSIT
(  NAME ,
   STATE ,
   TEMPLATE ,
   TYPE
)
VALUES
(  '*Harmless',
   'Harmless',
   'zk55.RSP_obj_status',
   256
);

INSERT INTO KFWTMPLSIT
(  NAME ,
   STATE ,
   TEMPLATE ,
   TYPE
)
VALUES
(  '*Unknown',
   'Unknown',
   'zk55.RSP_obj_status',
   256
);

