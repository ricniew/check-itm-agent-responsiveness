/* ---------------------------------------------------------- */
/* @(#) K55.SQL V100                */
/* ---------------------------------------------------------- */
/* Product Provided Situations and Templates for              */
/* Agent Responsiveness Monitoring Agent  */
/*                                                            */
/* Licensed Materials - Property of IBM                       */
/* Copyright IBM Corp. 2005, 2019 All Rights Reserved               */
/* US Government Users Restricted Rights - Use, duplication or*/
/* disclosure restricted by GSA ADP Schedule Contract with    */
/* IBM Corp.                                                  */
/*                                                            */
/* Warning: this file contains ascii binary data that cannot  */
/*          be ftp'ed as TEXT between ascii and ebcdic hosts. */
/* ---------------------------------------------------------- */


/* Tasks */

/* Situations */
