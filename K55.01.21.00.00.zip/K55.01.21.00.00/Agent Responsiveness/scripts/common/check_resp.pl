#!/usr/bin/perl
# R. Niewolik IBM AVP Team EMEA
# This procedure checks agent responsiveness by accessing local time stamp data.

use LWP::UserAgent;
use XML::Simple;
use Getopt::Long;
use Data::Dumper;
use File::Basename;
use Time::Local;
use Sys::Hostname;
use strict;
use warnings;	

################################################# Main #############################################################
my $version = "V3.5"; 

#exit;
#print "-s https://temsprod.test.com -p 3661 -u user -w pass -t lz nt lou x";
# GLOBAL variable definition. 
my $GLB_MSGLOG; # used in sub ras1
my $GLB_PRINT; # used in sub ras1

# Local variable definition 
my ($rc, $soapstring, $response, $tems, $msl, $ms, $pref, $i, $pc, $temp, $cmd, $ignored);
my (%hparms, %htmp, %h2, %hOK, %mslist, %hpc, %htemses);
my (@atmp, @arc, @temslst);
my $lastlog;

%hparms = SubCheckParam();
#print Dumper (\%hparms);

if ( defined $hparms{singletems} ) {
	$GLB_MSGLOG = $hparms{loghome}. "checkresp_" . $hparms{singletems} . "_messages-0.log";
	$lastlog = $hparms{loghome}. "checkresp_" . $hparms{singletems} . "_messages-1.log";
        $hparms{summarylog} = $hparms{loghome} . "checkresp_" . $hparms{singletems} . "_summary.log";
        $hparms{responsivelog} = $hparms{loghome} . "checkresp_" . $hparms{singletems} . "_responsive.log";
        $hparms{notresponsivelog} = $hparms{loghome} . "checkresp_" . $hparms{singletems} . "_notresponsive.log";
} else {
	$GLB_MSGLOG = $hparms{loghome}. "checkresp.messages-0.log";
	$lastlog = $hparms{loghome}. "checkresp.messages-1.log";
        $hparms{summarylog} = $hparms{loghome} . "checkresp.summary.log";
        $hparms{responsivelog} = $hparms{loghome} . "checkresp.responsive.log";
        $hparms{notresponsivelog} = $hparms{loghome} . "checkresp.notresponsive.log";
}
#if (-e $hparms{summarylog} ) { unlink ($hparms{summarylog}); }
#if (-e $hparms{notresponsivelog} ) { unlink ($hparms{notresponsivelog}); }
#if (-e $hparms{responsivelog} ) { unlink ($hparms{responsivelog}); }
if ( open(OUTSUM, ">", $hparms{summarylog} ) ) { }
else { ras1("ERROR: Sub_AnalyseOutputs - Could not open file for writing: " .  $hparms{summarylog} . "."); return 1; }
if ( open(OUTNOK, ">", $hparms{notresponsivelog} ) ) {}
else {ras1("ERROR: Sub_AnalyseOutputs - Could not open file for writing: " .  $hparms{notresponsivelog} . "."); return 1; }
if ( open(OUTOK, ">", $hparms{responsivelog} ) ) {}
else {ras1("ERROR: Sub_AnalyseOutputs - Could not open file for writing: " .  $hparms{responsivelog} . "."); return 1; }

#print "$^O\n";
if (-e $GLB_MSGLOG) {
	if ( $^O =~ m/^MSWin/ ) { 
		$GLB_MSGLOG =~ tr{/}{\\};
		$lastlog =~ tr{/}{\\};
		$cmd = "copy /Y " . $GLB_MSGLOG. " " . $lastlog . "> nul";
	} else { 
		$cmd = "cp " . $GLB_MSGLOG. " " . $lastlog. "> /dev/null";
	}
	#print "$cmd"; 
	$rc = system($cmd); 
}  else {}
$GLB_PRINT = $hparms{out};
$cmd = "echo " . Sub_GetTime() . ": INFO: New log created > $GLB_MSGLOG " ;  
$rc = system($cmd); 
if  ( $rc != 0 ) {   # exit 
	print "ERROR: - Main - cannot write to log file $GLB_MSGLOG. Check permissions, RC=$rc"; 
	exit 1; 
}

ras1 ("INFO: Procedure \"$0\" Version $version started. LOG Home is $hparms{loghome}");


$pref = $hparms{pc};
%hpc = %$pref;
#print Dumper (\%hpc);
$i=0 ;
($rc, $pref) = Sub_AgentMslist (%hparms); exit 1 if $rc == 1;
%htmp = %$pref;
%mslist = ();
foreach $pc ( keys %hpc ) {  
	#print " $pc \n";
	$i = 0;
	foreach $msl ( keys %htmp ) { 
		if ( $pc eq $htmp{$msl} ) { $mslist{$msl} = "$htmp{$msl}" ;  $i = 1; last;}
	}
	if ( $i == 1 ) {} else { ras1( "WARNING: Main - Agents MSL of type \"$pc\" not existing - never have been on line in this TEMS."); }
}
if (!keys %mslist) { ras1( "INFO: Main - Procedure \"$0\" ended. No agents to check. There is no MSL existing for the given product code"); exit; } 

($rc, @temslst) = Sub_Get_TEMSes(%hparms); exit 1 if $rc == 1;
@htemses{@temslst} = undef ;
#print Dumper (\%htemses);
# checking if "-n" parameter was set. In this case only agents connected to a specific TEMS are going to be checked
if ( defined $hparms{singletems} ) {
	if ( exists $htemses{$hparms{singletems}} ) { ras1("INFO: Main - $hparms{singletems} exists and ON-LINE");  }
	else { ras1( "ERROR: Main - $hparms{singletems} does NOT exists or OFF-LINE"); exit 1; }
	%htemses = (); @temslst = ();
	$htemses{$hparms{singletems}} = undef;
	@temslst = ($hparms{singletems});
} else { ras1("INFO: Main - Argument \"-n\" not set. Selected agents on all TEMS will be checked."); }

# get agent status before asking those to provide data (Sub_CreatePaylaodGetDataFromTEMA...)
($rc, $hparms{StaBefore}, $hparms{OFFLineStatus})= Sub_AgentStatus(\%hparms, \%htemses); exit 1 if $rc == 1;
if (!keys %{ $hparms{StaBefore} }) { 
	ras1( "WARNING: No agents ON-LINE"); 
	Sub_NothingToAnalyse(\%hparms);
	if  ( close(OUTSUM) ) {} else { ras1("ERROR: Sub_NothingToAnalyse - Could not close file:  " . $hparms{summarylog} . "."); return 1; }
} else { 
	# request data from agents and save resposne
	foreach $msl ( sort keys %mslist ) { 
		ras1( "INFO: Main - Get data for all agents of type \"$msl\" , product code = $mslist{$msl}");
		foreach $tems ( sort @temslst ) { 
			ras1( "INFO: Main - On $tems");
			($rc, $soapstring) = Sub_CreatePaylaodGetDataFromTEMA(\%hparms, $msl, $tems); exit 1 if $rc == 1; 
			($rc, $response) = Sub_SoapExecute(\%hparms, $soapstring); exit 1 if $rc == 1;
			#@arc= (); @arc = Sub_GetContent($response, "System_Name, Timestamp");
			@arc= (); @arc = Sub_GetContent($response, "System_Name");
			@atmp=(); @atmp = split (",", $arc[0] );
			if ( $arc[0] eq "nodata" or $atmp[0] eq "no value set") {
				# actually should not happen if there is any agent online for the given pc
				ras1( "WARNING: Main -  Sub_CreatePaylaodGetDataFromTEMA did not returned any data for $tems");
			} else { 
				foreach $ms ( @arc ) {
					@atmp=split(",", $ms);
					if ( $atmp[0] =~ /([^\s]+)/  ) { $atmp[0] = $1 ;} 
					$hOK{$atmp[0]} = "ok";
					#print "  DEBUG Main - $atmp[0] ------  $atmp[1] \n";
				}
			}
		}	
	}
	#print Dumper(\%hOK); exit;

	# get agent status after they ware asked to proved data, because sometimes an agent can become offline after data was requested.
	($rc, $hparms{StaAfter},  $hparms{OFFLineStatus}) = Sub_AgentStatus(\%hparms,\%htemses); exit 1 if $rc == 1;
	if (!keys %{ $hparms{StaAfter} }) { ras1( "WARNING: Procedure \"$0\" ended. No agents ON-LINE after SOAP call."); }
	
	# Analyse which agent did not return any data
	($rc, $ignored) = Sub_AnalyseOutputs(\%hparms, \%hOK); 
	if ( $rc == 1 ) { ras1( "INFO: Main -  No responsive agents detected");}  
	if ( $ignored != 0 ) { ras1( "INFO: Main - $ignored agents ignored, THRUNODE != TEMS. These agents, instancies, do not need to be checked.");}

	if  ( close(OUTSUM) ) {} else { ras1("ERROR: Sub_AnalyseOutputs - Could not close file:  " . $hparms{summarylog} . "."); return 1; }
	if  ( close(OUTNOK) ) {} else { ras1("ERROR: Sub_AnalyseOutputs - Could not close file:  " . $hparms{notresponsivelog} . "."); return 1; }
	if  ( close(OUTOK) ) {} else { ras1("ERROR: Sub_AnalyseOutputs - Could not close file:  " . $hparms{responsivelog} . "."); return 1; }
}


ras1("INFO: Message log created:");
ras1("INFO:   $GLB_MSGLOG ");
ras1("INFO: Procedure \"$0\" end");

exit;

# Main END #################################################################################### Main END
#-------------------------------------
# Sub routines
#-------------------------------------
sub ras1 {
	my ($cmd, $msglog, $par, $rc, $temp, $home);
	
	$par = $_[0]; 
	$rc = 0;

	if ( $GLB_PRINT eq "yes" ) { print Sub_GetTime() . " $par\n"; }
	$cmd = "echo " . Sub_GetTime() . ": $par >> $GLB_MSGLOG " ;  

	system($cmd); 
	if  ( $rc != 0 ) {   # exit 
		print "ERROR: ras1 - cannot write to log file. Check permissions, RC=$rc"; 
		exit 1; 
	}
	
	return $rc;
}
#-------------------------------------
sub Sub_NothingToAnalyse{
	# Called: Sub_NothingToAnalyse(\%hparms);
	ras1("INFO: Sub_NothingToAnalyse - create outputfiles");

	my %hp = %{(shift)}; 
	#print Dumper (\%hp);

	if ( defined $hp{singletems} ) { 
		print OUTSUM "$hp{singletems};0;0;0\n";
		my %hpc= %{ $hp{pc} };
		my $pcs=""; #print " --- $pcs\n";
		foreach ( keys %hpc ) {  $pcs = $pcs . " " . $_ };
		print "no Agents ON-LINE :$pcs; ; ; ; ; ; ;\n";

	} else {
		print OUTSUM "0;0;0\n";
	}


	return 0
}
#-------------------------------------
sub Sub_AnalyseOutputs{
	# Called: Sub_AnalyseOutputs(\%hparms, \%hOK);
	ras1("INFO: Sub_AnalyseOutputs - Start analysis.. ");
	
	# LOCAL variable definition. 
	my ($rc, $pref1, $pref2, $key, $cresp, $coffline, $cnotresp, $cign, $pc, $statusb, $statusa, $tems, $size, $host);
	my (@a, @atmp, @tmpmshost);
	my (%hp, %hStaBefore, %hStaAfter, %hOFFLineStatus, %hok, %hrcok, %hrcnok, %hrcnotresp, %hrcoffline);
	
	$rc = $cresp = $coffline = $cnotresp = $cign = 0; 
	%hStaBefore = %hStaAfter = %hrcnok = %hrcnotresp = %hrcoffline = %hok = (); 
	
	%hp = %{(shift)};; 
	%hok = %{(shift)}; 
	
	%hStaBefore = %{ $hp{StaBefore} }; 
	%hStaAfter = %{ $hp{StaAfter} }; 
	%hOFFLineStatus = %{ $hp{OFFLineStatus} };
	#print Dumper(\%hok); print Dumper(\%hStaBefore); print Dumper(\%hStaAfter); print Dumper(\%hOFFLineStatus); exit;
	
	ras1("INFO: Sub_AnalyseOutputs - Analysing responsive agents... ");
	if (!%hok) { 
		ras1("ERROR: Sub_AnalyseOutputs - No agents responded");
		return 1;
	} else {
		foreach  $key ( sort keys %hok ) {
			next if $hok{$key} eq "";
			#next if $key eq "ADMINIB-2L6UA6P:NT"; #test only
			if ( not exists $hOFFLineStatus{$key} )  {
				if (not exists $hStaBefore{$key}) { 
					#ras1("WARNING: Sub_AnalyseOutputs - Agent \"$key\" with no TEMS thrunode. Not supported.");  
					# Sub_AgentStatus SOAP SQL call may return agents not having a TEMS thrunode (when subnodes). These agents are 
					# ignored in the Sub_AgentStatus process. The indication for such agents is that there will be no entry in the hash
					# "$hStaBefore{$key}" which is created by the Sub_AgentStatus routine.
					$cign = $cign + 1;
					next;
				}
				$cresp = $cresp + 1;
				#print "-----$key-----$hStaBefore{$key}\n";
				@atmp = split (",", $hStaBefore{$key});
				$pc = $atmp[1];
				$statusb = $atmp[0];
				@atmp = split (",", $hStaAfter{$key});
				$statusa = $atmp[0];
				$tems = $atmp[2];
				$hrcok{$key} =  "$pc:$statusb:Responsive:$statusa:$tems" ;
				printf OUTOK ("%-34s;%-2s;%-1s;%-14s;%-1s;%-32s\n", 
					$key, $pc, $statusb, "Responsive", $statusa, $tems);
				#printf  ("%-34s;%-2s;%-1s;%-14s;%-1s;%-32s\n", 
				#	$key, $pc, $statusb, "Responsive", $statusa, $tems);
			} else {
				# This case was seen once during the tests.
				# It appears that sometimes native SQL returns a value even the Status is OFF-LINE. For example
				# in an ITM Gateway environment in case of a GW switch. Ignoring it...
				delete $hrcok{$key} ;
			}
		}
	}

	ras1("INFO: Sub_AnalyseOutputs - Analysing if NOT responsive... ");
	if (keys  %hStaBefore) { 
		foreach $key ( keys %hStaBefore ) { # hash contains list of online agents before agent data request
			if ( not exists $hrcok{$key} ) { 
				# agent not responsive or did not answer in time
				$cnotresp = $cnotresp + 1;
				@atmp = split (",", $hStaBefore{$key});
				$pc = $atmp[1];
				$statusb = $atmp[0]; # saving status before data request. Sometimes not responsive agents went offline after data request.
				$tems = $atmp[2];
				if ( not exists $hStaAfter{$key} ) {
					if ( not exists $hOFFLineStatus{$key} ) { 
						# should not happen, would mean agent is removed in the meantime
						$statusa = "X"; 
					} else {
						@atmp = split (",", $hOFFLineStatus{$key});
						$statusa = $atmp[0];
					}
				} else {
					@atmp = split (",", $hStaAfter{$key});
					$statusa = $atmp[0];
				}
				$hrcnotresp{$key} = "$pc;$statusb;NO Response;$statusa;$tems" ; 				
				
			}
		}
	} else { ras1("ERROR: Sub_AnalyseOutputs - Something went wrong (hStaBefore). "); exit; }

	foreach $key ( keys %hrcnotresp) {
		@atmp = split (";", $hrcnotresp{$key});
		$pc = $atmp[0];
		$statusb = $atmp[1];
		$statusa = $atmp[3];	
		printf OUTNOK ("%-34s;%-2s;%-1s;%-14s;%-1s;%-32s\n", 
			$key, $pc, $statusb, "NO Response", $statusa, $tems );
		# Added hostname to be printed to STDOUT (usefull when using as AB Agent, e.g. as a value for EIF slots)
		@tmpmshost = split (":",$key);
		$size = @tmpmshost;
		$host = $tmpmshost[$size-2];
		printf  ("%-34s;%-2s;%-1s;%-14s;%-1s;%-32s;%-34s\n", 
			$key, $pc, $statusb, "NO Response", $statusa, $tems, $host );
	}

	# for tests only
	#print "itaipu0001:LZ                  ;LZ;Y;NO Response   ;Y;HUB_TEMSLAB;itaipu0001\n";
	#print "krakow1111:LZ                  ;LZ;Y;NO Response   ;Y;HUB_TEMSLAB;krakow1111\n";
	#print "niagara012:LZ                  ;LZ;Y;NO Response   ;Y;HUB_TEMSLAB;niagara012\n";
	#print "wisla01223:LZ                  ;LZ;Y;NO Response   ;Y;REMOTE_LAB;wisla01223\n";
	#print "odra001122:LZ                  ;LZ;Y;NO Response   ;Y;REMOTE_LAB;odra001122\n";
	#print "iguazu1246:LZ                  ;LZ;Y;NO Response   ;N;REMOTE_LAB;iguazu1246\n";

	ras1("INFO: Sub_AnalyseOutputs - Counting offline... ");
	#print Dumper(\%hOFFLineStatus);
	if (keys  %hOFFLineStatus) { 
		foreach  $key ( keys %hOFFLineStatus ) { 
			$coffline = $coffline + 1;
			@atmp = split (",", $hOFFLineStatus{$key});
			$pc = $atmp[1];
			$statusa = $atmp[3];
			$hrcoffline{$key} = "$pc:-:OFF-LINE:-:$tems" ; # hash not used, saved just to have in case 
		}
	}
	if ( $cnotresp eq 0) {
		my %hpc= %{ $hp{pc} };
		my $pcs="";
		foreach ( keys %hpc ) { $pcs = $pcs . " " . $_ };
		print "Response status OK:$pcs; ; ; ; ; ; ;\n";
	}

	if ( defined $hp{singletems} ) { 
		print OUTSUM "$hp{singletems};$cnotresp;$coffline;$cresp\n";
	} else {
		print OUTSUM "$cnotresp;$coffline;$cresp\n";
	}
	ras1("INFO: Sub_AnalyseOutputs - Result NOT Responsive = $cnotresp");
	ras1("INFO: Sub_AnalyseOutputs - Result OFF-LINE       = $coffline");
	ras1("INFO: Sub_AnalyseOutputs - Result Responsive     = $cresp");
	

	ras1("INFO: Logs created:");
	ras1("INFO:    $GLB_MSGLOG ");
	ras1("INFO:    $hp{summarylog} ");
	ras1("INFO:    $hp{responsivelog} ");
	ras1("INFO:    $hp{notresponsivelog} ");
	ras1("INFO: Sub_AnalyseOutputs - Finished analysing... $rc, $cign ");
	return ($rc, $cign);
}
#--------------------------------
sub Sub_CheckPerAgent{
	# NOT USED
	# Called: Sub_CheckPerAgent (\%hparms, $ms); NOT USED
	# LOCAL variable definition. 
	my ($rc, $soapstring, $response, $sql, $pref, $ms, $tems);
	my ( %hp );
	my (@a, @aa);
	
	$rc = 0; 
	($pref, $ms) = @_; 
	%hp = %$pref;
	
	$sql = "SELECT THRUNODE FROM O4SRV.INODESTS WHERE NODE='$ms'"; 
	$soapstring ='<CT_Get> <userid>' . $hp{soapuser} . '</userid><password>' . $hp{soapuserpw} . '</password> <table>O4SRV.UTCTIME</table><sql>' . $sql . ' ;</sql> </CT_Get>';
	($rc, $response) = Sub_SoapExecute(\%hp, $soapstring); return 2 if $rc == 1;
	@a = Sub_GetContent($response, "THRUNODE");
	#print @a; print"\n";
	foreach ( @a ) { 
		@aa = split(",", $_);   #print "Line= $_ = 1=$aa[0] -> 2=$aa[1]\n";  
		if ( $aa[0] eq "nodata" ) {
		} else { $tems= $aa[0] ; }
	}
	
	$sql = "SELECT ORIGINNODE FROM O4SRV.LOCALTIME AT ('$tems') WHERE SYSTEM.PARMA('NODE','$ms', 32) AND SYSTEM.PARMA('TIMEOUT','$hp{timeout}',3)";
	$soapstring ='<CT_Get><userid>' . $hp{soapuser} . '</userid><password>' . $hp{soapuserpw} . '</password><table>O4SRV.UTCTIME</table><sql><![CDATA[' . $sql . ']]></sql></CT_Get>';
	($rc, $response) = Sub_SoapExecute(\%hp, $soapstring); return 2 if $rc == 1;
	@a = Sub_GetContent($response, "System_Name");
	#print @a; print"-----\n"; exit;
	foreach ( @a ) {
		@aa = split(",", $_);   #print "Line= $_ = 1=$aa[0] -> 2=$aa[1]\n";  
		if ( $aa[0] eq "nodata" ) { $rc = 1; 
		} else { $rc = 0;  }
	}
	#print "----- rc=$rc\n";
	return $rc;
}
#--------------------------------
sub Sub_AgentStatus{
	# Called: Sub_AgentStatus(\%hparms, \%htemses)

	# LOCAL variable definition. 
	my ($rc, $soapstring, $response, $sql, $status, $pref, $pref1, $pref2, $i);
	my ( %hp, %hrc1_status, %hrc2_OFFline, %hpc, %htemses );
	my (@a, @aa);

	%hp = %{(shift)};; 
	%htemses = %{(shift)};
	%hpc= %{ $hp{pc} };

	$i = $rc = 0; 
	
	ras1( "INFO: Sub_AgentStatus - Get Agents status");
	$sql = "SELECT NODE, PRODUCT, O4ONLINE, THRUNODE FROM O4SRV.INODESTS"; 
	$soapstring ='<CT_Get> <userid>' . $hp{soapuser} . '</userid><password>' . $hp{soapuserpw} . '</password> <table>O4SRV.UTCTIME</table><sql>' . $sql . ' ;</sql> </CT_Get>';
	($rc, $response) = Sub_SoapExecute(\%hp, $soapstring); return 1 if $rc == 1;
	@a = Sub_GetContent($response, "NODE,O4ONLINE,PRODUCT,THRUNODE");

	foreach ( @a ) { 
		@aa = split(",", $_);   #print "Line= $_ = 1=$aa[0] -> 2=$aa[1]\n";  
		if ( $aa[0] eq "nodata" ) {  
		} elsif ( $aa[2] eq "EM" or  $aa[2] eq "CQ" or  $aa[2] eq "MS") { next;
		} elsif ( not exists $htemses{$aa[3]} ) { 
			# Ignore agents not having a TEMS as THRUNODE
			next; 
		} elsif (exists $hpc{$aa[2]}) {
			if ( $aa[1] eq "Y" ) { # save online agents
				$hrc1_status{$aa[0]} = "$aa[1],$aa[2],$aa[3]"; 
			} elsif ( $aa[1] eq "N" ) { # save offline agents
				$hrc2_OFFline{$aa[0]} = "$aa[1],$aa[2],$aa[3]";
			}
		} else { }
	}
	
	#foreach ( keys %hrc1_status ) {  print " $_ > '$hrc1_status{$_}'\n" ; } # %hrc_status contains NODE,-> "NODETYPE|O4ONLINE"
	#foreach ( keys %hrc2_OFFline) {  print " OFFLine= $_ > '$hrc2_OFFline{$_}'\n"; } ; # %hrc_status contains NODE,-> "NODETYPE|O4ONLINE"
	#print Dumper (\%hrc1_status); print Dumper (\%hrc2_OFFline);
	return ($rc, \%hrc1_status, \%hrc2_OFFline); 
	
}
#--------------------------------
sub Sub_AgentMslist {
	# Called: Sub_AgentMslist (%hparms)
	# LOCAL variable definition. 
	my ($rc, $soapstring, $response, $sql, $temp, $pref, $key, $type);
	my ( %hp, %hmslist, %hrc_mslist);
	my (@a, @aa);
	
	$rc = 0; $temp = ""; 
	%hp = @_; 
	
	ras1("INFO: Sub_AgentMslist - Get existing MSLs");
	$sql = "SELECT NODELIST, NODE FROM O4SRV.TNODELST WHERE SUBSTR(NODELIST,0,1) = '*' AND NODETYPE='M'"; 
	$soapstring ='<CT_Get> <userid>' . $hp{soapuser} . '</userid><password>' . $hp{soapuserpw} . '</password> <table>O4SRV.UTCTIME</table><sql>' . $sql . ' ;</sql> </CT_Get>';
	($rc, $response) = Sub_SoapExecute(\%hp, $soapstring); return 1 if $rc == 1;
	@a = Sub_GetContent($response, "NODELIST, NODE");
	foreach ( @a ) { 
		@aa = split(",", $_);  # print "Line= $_ = 1=$aa[0] -> 2=$aa[1]\n";  
		if ( $aa[0] eq "nodata" ) { } 
		elsif ( 
			$aa[0] eq "*ALL_CMS" or  
			$aa[0] eq "*HUB" or  
			$aa[0] eq "*TEPS"  or  
			$aa[0] eq "*IBM_KLOpro" or 
			$aa[0] eq "*IBM_KNTLog" )
			{ next; }	
		else { $hmslist{$aa[0]} = "$aa[1]"; }
	}
	
	foreach $key ( sort keys %hmslist ) {
		$sql = "SELECT PRODUCT FROM O4SRV.INODESTS WHERE NODE = '$hmslist{$key}'"; 
		$soapstring ='<CT_Get> <userid>' . $hp{soapuser} . '</userid><password>' . $hp{soapuserpw} . '</password> <table>O4SRV.UTCTIME</table><sql>' . $sql . ' ;</sql> </CT_Get>';
		($rc, $response) = Sub_SoapExecute(\%hp, $soapstring); return 1 if $rc == 1;
		@a = Sub_GetContent($response, "PRODUCT");
		$type = $a[0];
		$hrc_mslist{$key} = "$type";
	}
	
	#print Dumper (\%hrc_mslist);exit;
	return ($rc, \%hrc_mslist); 
	
}

#--------------------------------------------------------
sub Sub_CreatePaylaodGetDataFromTEMA {
	# Called: Sub_CreatePaylaodGetDataFromTEMA(\%hparms, $msl, $tems)

	# LOCAL variable definition. 
	my ($rc, $sql, $tems, $where, $pref, $key, $msl);
	my (%hp, %hOFFline);
	my (@a);
	
	$rc = 0;

	%hp = %{(shift)};
	$msl = shift;
	$tems = shift;
	#print " tems:$tems , msl:$msl"; print Dumper (\%hp);exit;
	
	#ras1( "INFO: Sub_GetDataFromTEMA - Create agents  soap request string. ");
	#$sql = "SELECT SYSTIME, ORIGINNODE FROM O4SRV.LOCALTIME AT ('$tems') WHERE SYSTEM.PARMA('NODELIST', '$msl', 32)  AND SYSTEM.PARMA('TIMEOUT','$hp{timeout}',3)";
	$sql = "SELECT ORIGINNODE FROM O4SRV.LOCALTIME AT ('$tems') WHERE SYSTEM.PARMA('NODELIST', '$msl', 32)  AND SYSTEM.PARMA('TIMEOUT','$hp{timeout}',3)";
	$soapstring ='<CT_Get><userid>' . $hp{soapuser} . '</userid><password>' . $hp{soapuserpw} . '</password><table>O4SRV.UTCTIME</table><sql><![CDATA[' . $sql . ']]></sql></CT_Get>';
	
	#print "DEBUG Sub_GetDataFromTEMA- $soapstring \n";
	return ($rc, $soapstring);
}

#---------------------------------
sub Sub_SoapExecute {
	# Called: Sub_SoapExecute(\%hparms, $soapstring)

	# LOCAL variable definition
	$ENV{'PERL_LWP_SSL_VERIFY_HOSTNAME'} = 0; # Disable SSL certificate verification 
	my ($ua, $request, $response, $soapdata, $faultm, $soapstring, $soaphub, $pref, $rc);
	my (%hp);
	
	$rc = 0;

	%hp = %{(shift)};
	$soapstring = shift;

	#print "test --- $soapstring\n"; 
	$ua = LWP::UserAgent->new;
	$ua->protocols_allowed( [ 'http','https'] );
	$request = HTTP::Request->new( POST =>  $hp{soaphub}  );	
	$request->content_type( 'application/xml', 'charset=utf-8' );
	$request->content($soapstring );
	$response = $ua->request( $request );
	
	if ( $hp{debug} eq "yes" ) { print "DEBUG Sub_SoapExecute : $_[1] \n ..." . Dumper($response) . "\n"; }
	if ( $response->status_line( )  eq "200 Assumed OK" ) { 
		ras1( "ERROR: Cannot connect to a soap server at addresses $hp{soaphub}");
		$rc = 1; }
	elsif ( $response->is_success ) {
		$soapdata = XMLin( $response->content, NoAttr => 1);
		#ras1( "Error code:" . $response->status_line . "!|");
	} else {
		$rc = 1;
		ras1("ERROR: Sub_SoapExecute - Error executing " . $hp{soaphub} . "!");
		ras1("ERROR: Sub_SoapExecute - ... error code:" . $response->status_line . "!");
		return 1; # if error during Soap request procedure is ending abnormaly 
	}
	if  ( defined  $soapdata->{'SOAP-ENV:Body'}->{'SOAP-ENV:Fault'}->{'faultstring'} ) {
		$rc = 1;
		ras1("ERROR: Sub_SoapExecute - Soap Request error !!!: '$soapdata->{'SOAP-ENV:Body'}->{'SOAP-ENV:Fault'}->{'faultstring'}'"); 
		ras1("ERROR ... on: $hp{soaphub}");  
		ras1("ERROR: ... request: $soapstring ");
		return 1; # if error during Soap request procedure is ending abnormaly 
	}

	return ($rc, $soapdata);
}
#------------------------------
sub Sub_GetContent {	
	# Called: Sub_GetContent($response, "[colname, ..]") e.g. Sub_GetContent($response, "System_Name")

	# LOCAL variable definition
	my (@rc, $response, @temp, $tmp, $key, $i, $row);
	$tmp = $_[1], $tmp =~ s/ //g;
	@temp=split(",",$tmp);
	$response = $_[0];

	if ( ref($response->{'SOAP-ENV:Body'}->{'SOAP-CHK:Success'}->{'TABLE'}->{'DATA'}->{'ROW'}) eq "HASH" ) {
		$tmp='';
		foreach $row (@temp) {
			if ( ref( $response->{'SOAP-ENV:Body'}->{'SOAP-CHK:Success'}->{'TABLE'}->{'DATA'}->{'ROW'}->{$row} ) ne "HASH" ) {
				$tmp = $tmp  .  "," . "$response->{'SOAP-ENV:Body'}->{'SOAP-CHK:Success'}->{'TABLE'}->{'DATA'}->{'ROW'}->{$row}";
			} else { $tmp = $tmp  .  "," . "no value set"; 
			}
		}
		$tmp =~ s/^,//;  push (@rc, $tmp);
	}
	elsif ( ref($response->{'SOAP-ENV:Body'}->{'SOAP-CHK:Success'}->{'TABLE'}->{'DATA'}->{'ROW'}) eq "ARRAY" ) {
		foreach $key ( @{$response->{'SOAP-ENV:Body'}->{'SOAP-CHK:Success'}->{'TABLE'}->{'DATA'}->{'ROW'}} ) {
			$tmp=''; $i = 0;
			foreach $row (@temp) {
				if ( ref($key->{$row} ) ne "HASH") {
					if ($i != 0) { $tmp = $tmp  .  "," . "$key->{$row}"; 
					} else { $tmp = "$key->{$row}"; }
				} else { 
					if ($i != 0) { $tmp = $tmp  .  "," . "no value set for '$row'"; 
					} else { $tmp = "no value set for '$row'"; }
				}
				$i++;
			}
			$tmp =~ s/^,//; push (@rc, $tmp);
		}
	}
	elsif ( not defined $response->{'SOAP-ENV:Body'}->{'SOAP-CHK:Success'}->{'TABLE'}->{'DATA'}->{'ROW'} ) {
		push(@rc, "nodata");
	} else { }
	# @rc contains output for each row and selected columns seperated by ","
	#foreach ( @rc ) { print "DEBUG Sub_GetContent $_ \n";}; 

	return @rc;
}
#---------------------------------
sub Sub_Get_TEMSes {
	# Called: Sub_Get_TEMSes(%hparms)

	# LOCAL variable definition
	my ($soapstring, $rc, $response);
	my (@temslist);
	my (%hp);

	$rc = 0;
	%hp = @_; 

	ras1("INFO: Sub_Get_TEMSes - Get list of TEMS servers");
	$soapstring ='<CT_Get><userid>' . $hp{soapuser} . '</userid><password>' . $hp{soapuserpw} . '</password><table>O4SRV.UTCTIME</table><sql><![CDATA[SELECT NODE FROM O4SRV.INODESTS WHERE PRODUCT = "EM" AND O4ONLINE = "Y" ]]></sql></CT_Get>';
	($rc, $response) = Sub_SoapExecute(\%hp, $soapstring); return 1 if $rc == 1;
	@temslist = Sub_GetContent($response, "NODE");
	
	#foreach ( @temslist ) { print "$_ \n"; }; exit ;
	return ($rc, @temslist);	
}
#----------------------------
sub Sub_GetTime {
	# Called: Sub_GetTime()

	# LOCAL variable definition. 
	my ($rc, $sec, $min, $hour, $mday, $mon, $year); 

	($sec,$min,$hour,$mday,$mon,$year) = localtime(time); 
	$mon = $mon + 1; $year = $year + 1900;
	if (length($mon) == 1) { $mon = "0" . $mon;}
	if (length($mday) == 1) { $mday = "0" . $mday;}
 	if (length($hour) == 1) { $hour = "0" . $hour;}
	if (length($min) == 1) { $min = "0" . $min;}
	if (length($sec) == 1) { $sec = "0" . $sec;}
	
	#print "$year-$mon-$mday.$hour$min$sec"; exit;
	$rc = "$year-$mon-$mday.$hour$min$sec";
	return $rc;
}

#-------------------------------
sub SubCheckParam {
	# Called: SubCheckParam();

	# LOCAL variable definition. 
	my ($rc, $user, $pass, $hub, $port, $pc, $timeout, $debug, $tmp, $help, $out, $loghome,$singletems); 
	my (%hrc, %htmp, %pcodes);
	my (@a, @apc);
	
	@a = @apc = ();
	%hrc = ();
	
	GetOptions (
		"s=s"         => \$hub,
		"t=s{1,}"  => \@apc,
		"p=s"         => \$port,
		"u=s"         => \$user,
		"w=s"         => \$pass,
		"n=s"         => \$singletems,
		"l=s"         => \$loghome,
		"o=s"         => \$timeout,
		"d=s"         => \$debug,
		"pr!"         => \$out,
		"h!"	         => \$help
	) or die Sub_disSyntax();
	#print Dumper(\%ENV);
	
	if ( exists $ENV{K55_HUBHOST}) { $hub = $ENV{K55_HUBHOST}; }
	if ( exists $ENV{K55_SOAPPORT}) { $port = $ENV{K55_SOAPPORT}; }
	if ( exists $ENV{K55_USER}) { $user = $ENV{K55_USER}; }
	if ( exists $ENV{K55_PASSWORD}) { $pass = $ENV{K55_PASSWORD}; }
	if ( exists $ENV{K55_LOGDIR}) { $loghome = $ENV{K55_LOGDIR}; }
	if ( exists $ENV{K55_AGENT_TYPE}) { @apc = split(" ",$ENV{K55_AGENT_TYPE}); }
	if ( exists $ENV{K55_TEMS_NAME}) { $singletems = $ENV{K55_TEMS_NAME}; }
	
	if ( defined $help ) { Sub_disSyntax($help); }
	
	if ( not defined $hub ) { $hub = ""; print "\nERROR: Argument -s \"$hub\" not set.\n"; Sub_disSyntax() }
	else {$hub =~ tr/A-Z/a-z/;}
	if ( $hub =~ /^(http:\/\/|https:\/\/)[^\/].*$/) { } 
	else { 
		if ( $hub =~  m/^.*\/\/.*$/ ) { print "\nERROR: Argument -s \"$hub\" not correct.\n"; Sub_disSyntax() ; }
		else { $hub = "http://" . $hub; }
	}
	
	if ( not defined $loghome ) { $loghome = ""; }
	else { $loghome =~ s|/$||; $loghome =~ s|\$||; $loghome =~ s!/*$!/!; }
	
	if ( not defined $port ) { $port = "1920"; }
	if ( $port =~ /^[0-90-9]./) { } else { print "\nERROR: Argument -p \"$port\" not numeric.\n"; Sub_disSyntax() }
	
	if ( not defined $user ) { $user = ""; print "\nERROR: Argument -u \"$user\" not set.\n"; Sub_disSyntax() }
	
	if ( not defined $pass ) {  
		if ( $pass eq "") { print "\nERROR: Argument -w user password not set.\n"; Sub_disSyntax() ; }
	}
	
	if ( @apc ) {
		foreach ( @apc ) { 
			$_ =~ tr/a-z/A-Z/; 
			$pcodes{$_} = ""; 
		}
	} else {
		#$pcodes{NT}= ""; $pcodes{LZ}= ""; $pcodes{UX}= "";
		print "\nERROR: Argument -t agent typed not set.\n"; Sub_disSyntax() ;
	}
	
	if ( defined $out ) { $out = "yes"; } else { $out = "no"; }
	if ( not defined $timeout ) { $timeout = 70; } # DEFAULT
	if ( $timeout=~ /^[0-90-9]./) { } else { print "\nERROR: Argument -o \"$timeout\" not numeric.\n"; Sub_disSyntax() }
	
	if ( not defined $debug ) { $debug = "no";  # DEFAULT
	} else { 
		$debug =~ tr/A-Z/a-z/; 
		if ( $debug =~ /(no|yes)/ ) {} else { print "\nERROR: Debug set incorrectly (no/yes).\n"; Sub_disSyntax() } 
	}

	$hrc{pc} = \%pcodes; 
	$hrc{soapuser} = $user; 
	$hrc{soapuserpw} = $pass; 
	$hrc{soaphub} = "$hub:$port///cms/soap"; 
	$hrc{soapport} = $port;
	$hrc{loghome} = $loghome;
	$hrc{singletems} = $singletems;
	$hrc{timeout} = $timeout;
	$hrc{out} = $out;
	$hrc{debug} = $debug; # if set to yes you will get soap response dumped to stdout
	
	if ( $hrc{loghome} eq "") { 
		if ( $^O =~ m/MSWin/) {  
			if ( exists $ENV{CANDLE_HOME} ) { $hrc{"loghome"} = $ENV{'CANDLE_HOME'} . "/logs/"; }
			else { print "ERROR: CANDLE_HOME does not exist. Create ENV variable and restart.\n"; $hrc{"loghome"} = ""; Sub_disSyntax() }
		} else { 
			if ( exists $ENV{CANDLEHOME} ) { $hrc{"loghome"} = $ENV{'CANDLEHOME'} . "/logs/"; }
			else { print "ERROR: CANDLEHOME does not exist. Create ENV variable and restart.\n"; $hrc{"loghome"} = ""; Sub_disSyntax() }
		}
	} else {}
	
	#print Dumper(\%hrc); exit;
	return %hrc; 
}
#------------------------------
sub Sub_disSyntax {
	my ($help, $pn);
		
	$pn = basename($0);
	print "\nSYNTAX: \n";
	print "\n   $pn {-s host} [-p port] {-u username} {-w userpass} {-n temsname} {-t agt type} [-l dir] [-o timeout] [-pr] [-h]\n\n";
	print "  -s  Protocol and Hostname or IP address of the SOAP HUB\n";
	print "      (e.g. HTTP://host, HTTP://10.12.33.123). Only HTTP and HTTPS are supported..\n";
	print "  -p  Port of the SOAP HUB. (default is 1920)\n";
	print "  -u  Soap user\n";
	print "  -w  Soap user pw\n";
	print "  -n  TEMS name you want to chek agents on (RTEMS_01). If not set, selected agent type on all running TEMS is checked\n";
	print "      (by default all agents defined by the \"-t\" paramter are check on all existing TEMS)\n";
	print "  -t  Agent type (e.g \"ux lz\" (no default set)";
	print "  -l  Log file home directory (Default is ITMHOME/logs) \n";
	print "  -o  SQL Timeout value (default is 60 = 1min)\n";
	print "  -pr Print results to STDOUT (not set by default)\n";
	print "  -h  Display help\n";
	print " \n";
	print " Examples: \n";
	print "     $pn -s http://hubtems -p 1920 -u sysadmin -t nt ux lz \n";
	print "     $pn -s localhost -p 1920 -u sysadmin -t nt ux lz -pr\n";
	print "     $pn -s localhost -u sysadmin -w sysadpw -t nt ux lz -pr -n REMOTE_TEMS01 \n";
	print "     $pn -s localhost -u sysadmin -w sysadpw -t nt ux lz -l D:\\IBM\\scripts \n";
	print "     $pn -s https://10.23.144.213 -p 3661 -u sysadmin -w sysadpw -t ux lz -o 30\n";		
	print " \n";	
	exit 1;
}
#-------------------------------------
# Sub Procedures END
#-------------------------------------
